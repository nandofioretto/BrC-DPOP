#ifndef _ULISSE_VAR_INT_HH_
#define _ULISSE_VAR_INT_HH_

#include "globals.hh"
#include "search-domain.hh"
#include "constraint.hh"
#include <rapidxml.hpp>

class Constraint;
class Agent;
class TrailVariable;
class IntHardConstraint;
class ExtSoftConstraint;


class var_int 
{
public:
  /**
   * Default constructor
   */
  var_int (rapidxml::xml_node<>* var);

  /**
   * Copy constructor
   */
  var_int( const var_int& other );
  
  /**
   * Operator=
   */
  var_int& operator=( const var_int& other );

  /**
   * Default Distructor
   */
  ~var_int();

  /**
   * Relational operators
   */
  bool operator== ( const var_int& other )
  { 
    return varID == other.varID; 
  }
  bool operator!= ( const var_int& other )
  { 
    return varID != other.varID; 
  }
  bool operator< ( const var_int& other ) 
  { 
    return varID < other.varID; 
  }

  /**
   * Return the agent owner name.
   */
  Agent& getOwner() const
  { 
    return *g_agents[ varOwner ]; 
  }

  /**
   * Return the variable name
   */
  std::string getName() const
  {
    return varName; 
  }

  /**
   * Returns the variable id.
   */
  size_t getID() const
  {
    return varID;
  }

  /**
   * Returns the domain of the variable.
   */
  SearchDomain& getDomain()
  {
    return domain;
  }

  /**
   * Check whether the domain of the variable is empty.
   */
  bool isFailed() const;
  
  /**
   * Set the variable as assigned.
   * @todo: check wheter assignment functions are needed or 
   * event notion will suffice.
   * Complexity: O(1)
   */
  void setAssigned()
  {
    assigned = true;
    // Set domain of this variable as singletons (only acting on bounds) 
    domain.copy_singleton( label );
  }

  /**
   * Reset the assignment condition
   */
  void unsetAssigned()
  {
    assigned = false;
  }

  /**
   * Retunrs whether the variable is assigned, i.e., it's domain is singleton.
   */
  bool isAssigned() const
  {
    return assigned;
  }
  
  /**
   * Returns whether the domain associated to current variable has been 
   * modified by the action of constraint propagation.
   */ 
  bool isChanged() const
  {
    return (domain.event() > NB_STATIC_EVENTS);
  }

  /**
   * Reset variable state.
   */
  void reset();

  /**
   * Returns the value currently held by this variable.
   */
  int getValue()
  {
    if( label != -1 )
      return domain[ label ];
    return -1;
  }

  /**
   * Set Label to the i-th domain element position.
   */
  void setLabel( int i )
  {
    label = i;
  }

  /**
   * Get Label
   */
  int getLabel() const
  {
    return label;
  }

  /**
   * Performs a labeling step, iterating over the valid elements of the variable
   * domain
   */
  bool labeling();
  
  /**
   * Add c in the "constraint" vector.
   * Sorts the constraints so that they appear in the following order:
   * 1. intensional hard constraints
   * 2. intensional soft constraints
   * 3. extensional hard constraints
   * 4. extensional soft constraints
   */
  void addConstraint( Constraint& c );


  std::vector<Constraint*> getConstraints()
  {
    return constraints;
  }

  /**
   * Get the i-th constraint of "constraints"
   */
  Constraint& getConstraint( int idx )
  {
    return *constraints[ idx ];
  }

  /**
   * Returns the number of constraints having this variable in their scope.
   */
  size_t numofConstraints() const
  {
    return constraints.size();
  }

  /**
   * idx ranges in [0, nExtSoft_c-1]
   */
  ExtSoftConstraint& getExtSoftConstraint( int idx )
  {
    return (ExtSoftConstraint&)
      (*constraints[ nIntHard_c + nIntSoft_c + nExtHard_c + idx ]);
  }

  /**
   * Returns the number of extensional soft constraints 
   * having this variable in their scope.
   */
  size_t numofExtSoftConstraints() const
  {
    return nExtSoft_c;
  }

  /**
   * idx ranges in [0, nIntHard_c-1]
   */
  IntHardConstraint& getIntHardConstraint( int idx )
  {
    return (IntHardConstraint&)(*constraints[ idx ]);
  }

  /**
   * Returns the number of intensional hard constraints 
   * having this variable in their scope.
   */
  size_t numofIntHardConstraints() const
  {
    return nIntHard_c;
  }

  /**
   * Trail back current variable
   */
  void trailBack( TrailVariable& tv );
  
  /**
   *  Dump on screen
   */
  void dump() const;

  void resetJustChangedFlag( ) { justChaned = false; }
  void setJustChangedFlag( ) { justChaned = true; }
  bool isJustChanged( ) { return justChaned; }


 private:
  size_t varID;

  /// The name of the variable, which is a unique id
  std::string varName;
  
  /// The name (id) of the agent owning this variable
  std::string varOwner;

  /// The current labeling position ref. to the associated 
  int label;
  
  /// Flag if the variable has been assigned
  bool assigned;

  /// List of constraints to be checked after variable is changed
  std::vector < Constraint* > constraints;

  /// nHard
  size_t nIntHard_c;
  size_t nIntSoft_c;
  size_t nExtHard_c;
  size_t nExtSoft_c;

  /// The domain associated to this variable, public for efficiency 
  SearchDomain domain;

  // mark whether some changes happened due to last AC propagation results.
  bool justChaned;

};//-

#endif
