#include "store.hh"

using namespace std;

// template <class T>
// void Store<T>::init( vector<T> elems )
// {
//   store = elems;
//   capacity = elems.size();

//   inStore.resize( capacity, false );
//   size = 0;

//   ID2storePos.reserve( capacity );
//   for( int i=0; i<capacity; i++ )
//     ID2storePos[ elems[ i ] ] = i;
// }
