#include "trail-variable.hh"
#include "var_int.hh"
#include "domain.hh"

using namespace std;

// @hack: EFFICIENCY 
// if only bounds are used to modify a domain, then no need of
// copying the wholse state.
TrailVariable::TrailVariable ( var_int& v, size_t cont ) :
  varLink ( &v ), continuation ( cont ) 
{
  // dom_state  = v.getDomain().state(); // comment this out
  dom_lowerBound = v.getDomain().lb_pos();
  dom_upperBound = v.getDomain().ub_pos();
  dom_event      = v.getDomain().event(); 
  dom_nActive    = v.getDomain().n_active();
}


TrailVariable::~TrailVariable()
{
  // nothing
}


TrailVariable::TrailVariable ( const TrailVariable& other ) 
{
  continuation  = other.continuation;
  varLink       = other.varLink;
  dom_lowerBound = other.dom_lowerBound;
  dom_upperBound = other.dom_upperBound;
  //dom_state      = other.dom_state; // comment this out
  dom_event      = other.dom_event;
  dom_nActive    = other.dom_nActive;
}


TrailVariable& 
TrailVariable::operator= ( const TrailVariable& other ) 
{
  if ( this != &other ) {
  continuation  = other.continuation;
  varLink       = other.varLink;
  dom_lowerBound = other.dom_lowerBound;
  dom_upperBound = other.dom_upperBound;
  //dom_state      = other.dom_state; // comment this out
  dom_event      = other.dom_event;
  dom_nActive    = other.dom_nActive;
  }
  return *this;
}
 
void
TrailVariable::dump()
{
  cout << "TrailVar: " << varLink->getName();
  cout << " Old bounds[ " << dom_lowerBound << ", "
       << dom_upperBound << "] old event: " << dom_event 
       << " - old N.act: " <<dom_nActive << endl;
}
