#include "constraint-store.hh"
#include "var_int.hh"
#include "constraint.hh"
#include "int-hard-constraint.hh"
#include "store.hh"
#include "propagator.hh"
#include "cvm-propagator.hh"

using namespace std;

//#define DBG

ConstraintStore::ConstraintStore()
{
  // nothing
}


void ConstraintStore::initialize
( vector<IntHardConstraint*> cons, vector<var_int*> vars, TrailStack* t )
{
  propagator.initialize( t, this );
  // TEMP---
  cvm_propagator.initialize( t, this );
  // ----
  constraintQueue.init( cons );
  varchangedQueue.init( vars );
}


ConstraintStore::~ConstraintStore() 
{
  // nothing
}


void ConstraintStore::addConstraintsToQueue( var_int& v )
{
  for( int i=0; i < v.numofIntHardConstraints(); i++ )
  {
    IntHardConstraint& hc = v.getIntHardConstraint( i );    
    if( not hc.isAtFixpoint() ) {
      constraintQueue.push( &hc );
    }
  }
}


void ConstraintStore::flush()
{
  varchangedQueue.flush();
  constraintQueue.flush();
  // reset AC fixpoints
  for( int i=0; i<constraintQueue.getCapacity(); i++ )
    constraintQueue.at( i )->unsetFixpoint();
}


// Check if needed.
void ConstraintStore::reset()
{
  // flush();
}


// @todo: check on backtrack
bool ConstraintStore::iSolveFix()
{
  // Fill the constraint-store with the variable changed 
  while( varchangedQueue.getSize() > 0 )
  {
    addConstraintsToQueue( *varchangedQueue.ttop() );
  }

  // note: queue contains only constraints that have not reached fixpt yet 
  while( constraintQueue.getSize() > 0 )
  {
    while( constraintQueue.getSize() > 0 )
    {
      IntHardConstraint& r = *constraintQueue.ttop();

      if( not propagator.propagate( r ) )
      { 
	flush(); 
	return false; 
      }
    }
    
    // check the consistency of all the variables involved in some 
    // constraint propagation, and add related constraints to constraint queue.
    while( varchangedQueue.getSize() > 0 )
    {
      var_int& v = *varchangedQueue.ttop();
      if( not propagator.consistency( v ) )
      {
	flush();
	return false; 
      }
      // Fill the constraint-store with the variable changed  
      addConstraintsToQueue( v );
    }
  }

  // Reset Local constraint AC Fixpoints before returning
  for( int i=0; i<constraintQueue.getCapacity(); i++ )
    constraintQueue.at( i )->unsetFixpoint();

  return true;
}


// pass the propagator as input of the AC call
bool ConstraintStore::AC4_CVM ()
{
  // Fill the constraint-store with the variable changed 
  while( varchangedQueue.getSize() > 0 )
  {
    addConstraintsToQueue( *varchangedQueue.ttop() );
  }
  
  /// cout << "constraint queue propagating\n: ";
  // note: queue contains only constraints that have not reached fixpt yet 
  while( constraintQueue.getSize() > 0 )
  {
    while( constraintQueue.getSize() > 0 )
    {
      IntHardConstraint& r = *constraintQueue.ttop();
      ////cout << r.getName() << endl;

      if( not cvm_propagator.propagate( r ) )
      { 
	flush(); 
	return false; 
      }
    }
    
    // check the consistency of all the variables involved in some 
    // constraint propagation, and add related constraints to constraint queue.
    while( varchangedQueue.getSize() > 0 )
    {
      var_int& v = *varchangedQueue.ttop();
      if( not cvm_propagator.consistency( v ) )
      {
	flush();
	return false; 
      }
      // Fill the constraint-store with the variable changed  
      addConstraintsToQueue( v );
    }
  }

  // Reset Local constraint AC Fixpoints before returning
  for( int i=0; i<constraintQueue.getCapacity(); i++ )
    constraintQueue.at( i )->unsetFixpoint();

  return true;
}
