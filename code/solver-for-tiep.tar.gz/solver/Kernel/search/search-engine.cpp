#include "globals.hh"
#include "search-engine.hh"
#include "var_int.hh"

using namespace std;

SearchEngine::SearchEngine() :
  searchEnded( false ), varID2scopePos( 0 ), scopePos2varID( 0 )
{
  
}


SearchEngine::~SearchEngine()
{
  if(varID2scopePos) delete[] varID2scopePos;
  if(scopePos2varID) delete[] scopePos2varID;
}

void SearchEngine::initMapScope2Vars()
{
  // find maximum var-ID in scope
  size_t maxID = g_variables.size();
  for( int s=0; s<scope.size(); s++ )
  {
    if( scope[ s ]->getID() > maxID )
      maxID = scope[ s ]->getID();
  }
  // Init maps var scope position to varID
  varID2scopePos = new int[ maxID+1 ];
  scopePos2varID = new int[ scope.size() ];
  
  for( int s=0; s<scope.size(); s++ )
  {
    scopePos2varID[ s ] = scope[ s ]->getID();
    varID2scopePos[ scope[ s ]->getID() ] = s;
  }

  

}
