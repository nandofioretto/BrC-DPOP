#ifndef _ULISSE_SEARCH_SOLUTION_HH_
#define _ULISSE_SEARCH_SOLUTION_HH_

#include "globals.hh"

class Solution
{
public:
  /**
   *
   */
  Solution();

  /**
   *
   */
  ~Solution();

  /**
   *
   */
  Solution( const Solution& other );

  /**
   *
   */
  Solution& operator=( const Solution& other ); 

  /**
   *
   */
  int operator []( size_t pos ) const
  {  
    return values[ pos ];
  }

  /**
   *
   */
  int& operator[]( size_t pos )
  {  
    return values[ pos ];
  }

  /**
   *
   */
  void initialize( int size );

  /**
   *
   */
  void reset()
  {
    cost = NA_VALUE;
  }

  /**
   *
   */
  cost_type getCost() const
  {
    return cost;  
  }

  /**
   *
   */
  void setCost( cost_type val )
  {
    cost = val;
  }

  /**
   *
   */
  void incrCost( cost_type val )
  {
    cost += val;
  }

  /**
   *
   */
  void decrCost( cost_type val )
  {
    cost -= val;
  }

  /**
   *
   */
  std::vector<int>& getValues()
  {
    return values;
  }

  /**
   *
   */
  size_t size() const
  {
    return values.size();
  }

  /**
   * Dump solution on screen.
   */
  void dump() const;

private:
  // solution state
  std::vector<int> values;

  // cost associated to the value assignment
  cost_type cost;
};


#endif
