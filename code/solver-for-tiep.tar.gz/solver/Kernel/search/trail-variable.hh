/*********************************************************************
 * Trail Stack implementation
 *********************************************************************/
#ifndef _ULISSE_SEARCH_TRAILVARIABLE_H_
#define _ULISSE_SEARCH_TRAILVARIABLE_H_

#include "globals.hh"
#include "search-domain.hh"

class TrailVariable;
class var_int;

/**
 * The element to be trailed back in the trail stack---restored to its state
 * at the moment of its insertion in the trailstack (specified via the 
 * continuation).
 *
 * !!!!@todo: allocate MAXDIM*NVARS in the trail stack once, that is the maximum 
 *   number of variables which are going to be assigned in the trailstack. 
 *   This will avoid creating and freeing at every time trail and backtrack a 
 *   new state.
 */
class TrailVariable 
{
public:
  /**
   * Construct a trail element (variable, continuation).
   */
  TrailVariable( var_int& v, size_t cont );

  /**
   * Distructor.
   */
  ~TrailVariable();
  
  /**
   * Copy Constructor.
   */
  TrailVariable (const TrailVariable& other);

  /**
   * Assignment Operator.
   */
  TrailVariable& operator= (const TrailVariable& other);
  
  /**
   * Returns the continuation index.
   */
  size_t getContinuation() const
  {
    return continuation;
  }
  
  /**
   * Sets the continuation index.
   */
  void setContinuation( size_t cont ) 
  { 
    continuation = cont; 
  }

  /**
   * Returns the variable associated to this object.
   */
  var_int& getVarLink()
  {
    return *varLink;
  }

  /**
   * get state
   */
  // std::vector<bool> getState()
  // {
  //   return dom_state;
  // }

  int getLowerBound()
  {
    return dom_lowerBound;
  }

  int getUpperBound()
  {
    return dom_upperBound;
  }

  event_type getEvent()
  {
    return dom_event;
  }

  int getNactive()
  {
    return dom_nActive;
  }

  void dump();
  
private:
  // the continuation index.
  size_t continuation;
  
  // link to the variable being stored.
  var_int* varLink;

  // the state of variable's domain.
  //std::vector<bool> dom_state;
  
  // variable upper bound.
  int dom_lowerBound;
  
  // variable lower bound.
  int dom_upperBound;

  // domain event type
  event_type dom_event;
  
  // number of active elements
  int dom_nActive;
};

#endif
