#include "trailstack.hh"
#include "trail-variable.hh"
#include "var_int.hh"

using namespace std;

TrailStack::TrailStack( )
{
  // nothing
}

TrailStack::~TrailStack()
{
  // nothing
}

void TrailStack::backtrack( size_t continuation ) 
{
  while( varStack.size() > continuation )
  {
    TrailVariable &tv = varStack.top();
    tv.getVarLink().trailBack( tv );     
    varStack.pop();
  }

  /// Reset Constraint Fixpoints
  /// @todo: check this part

  // for( int i = 0; i < g_constraints.size(); i++)
  //   if ( gh_params.constraint_fixpoint[ i ] >= continuation )
  //     gh_params.constraint_fixpoint[ i ] = -1;
}


void TrailStack::reset() 
{
  while ( !varStack.empty() )
    varStack.pop();
}


//@note: inefficient! - at least create the element and store the pointer
//    in the trailstack -- to be freed at backtrack.
void TrailStack::trailVariable ( var_int& v ) 
{
  size_t ttop = varStack.size();
  TrailVariable te ( v, ttop );
  varStack.push ( te );
}
