#include "ext-soft-constraint.hh"
#include "var_int.hh"
#include <rapidxml.hpp>

using namespace std;
using namespace rapidxml;

ExtSoftConstraint::ExtSoftConstraint() 
{ 
  // nothing
}



void ExtSoftConstraint::initialize( xml_node<>* relation, ExtSoftConstraint* Rptr ) 
{
  // constraint parameters:
  type = extSoft;

  // Read Relation Properties
  constraintName  = relation->first_attribute("name")->value();
  arity = atoi( relation->first_attribute("arity")->value() );
  nb_tuples = atoi( relation->first_attribute("nbTuples")->value() );
  
  string p_scope = relation->first_attribute("scope")->value();
  scope.resize( arity );
  stringstream ss( p_scope);
  int c = 0; string var;
  while( c < arity )
  {
    ss >> var;
    scope[ c++ ] = g_variables[ var ];
    g_variables[ var ]->addConstraint( *this );
  }
 
  if( relation->first_attribute("defaultCost") )
  {
    std::string cost = relation->first_attribute("defaultCost")->value();
    if( cost.compare("infinity") == 0 )
      defaultCost = INFTY;
    else if( cost.compare("-infinity") == 0 )
      defaultCost = -INFTY;
    else 
      defaultCost = atof( cost.c_str() ); 
  }
  else  defaultCost = 0;

  // check infinity
  string content = relation->value();
  
  size_t lhs, rhs;
  lhs = 0;
  size_t count = 0;  
  // replace all the occurrences of 'infinity' with a 'INFTY'
  while( true )
  {
    rhs = content.find("infinity", lhs);
    if ( rhs != string::npos ) content.replace(rhs, 8, INFTY_STR);
    else break;
  };
  
  // replace all the occurrences of ':' with a '\b'
  cost_type m_cost; bool multiple_cost;
  int* tuple = new int[ arity ];  
  int trim_s, trim_e;
  string str_tuples;
  lhs = 0;
  while( count < nb_tuples )
  {
    //multiple_cost = true;
    rhs = content.find(":", lhs);
    if ( rhs < content.find("|", lhs) ) 
    {
      if ( rhs != string::npos ) 
      {
	m_cost = atof ( content.substr( lhs,  rhs ).c_str() );
	lhs = rhs + 1;
      }
    }

    rhs = content.find("|", lhs);
    trim_s = lhs, trim_e = rhs;
    lhs = trim_e+1;
	
    if (trim_e == string::npos) trim_e = content.size();
    else while (content[ trim_e-1 ] == ' ') trim_e--;
    
    str_tuples = content.substr( trim_s, trim_e - trim_s );
    str_tuples = rtrim(str_tuples);
    stringstream ss( str_tuples );
	
    int tmp;
    while( ss.good() )
    {
      for (int i = 0; i < arity; i++) {
	ss >> tmp;
	tuple[ i ] = scope[ i ]->getDomain().get_pos( tmp );
	//	ss >> tuple[ i ];
      }
      Rptr->setCost( tuple, m_cost );
      count++;
    }
  }
 
  //g_constraints[ constraintName ] = this;
  delete[] tuple;
}


ExtSoftConstraint::ExtSoftConstraint (const ExtSoftConstraint& other)
{
  constrID   = other.constrID;
  constraintName   = other.constraintName; 
  type  = other.type;
  arity = other.arity;
  scope = other.scope;

  nb_tuples = other.nb_tuples;
  defaultCost = other.defaultCost;
}

ExtSoftConstraint& ExtSoftConstraint::operator= (const ExtSoftConstraint& other)
{
  if( this != &other )
  {
    constrID   = other.constrID;
    constraintName   = other.constraintName; 
    type  = other.type;
    arity = other.arity;
    scope = other.scope;
    
    nb_tuples = other.nb_tuples;
    defaultCost = other.defaultCost;
  }
  return *this;
}

ExtSoftConstraint::~ExtSoftConstraint()
{
  //nothing
}


void ExtSoftConstraint::dump() 
{
  std::cout << "ExtSoftConstraint: " << constraintName << " arity: " << arity 
	    << " ntuples: " << nb_tuples << " def cost: " 
	    << defaultCost << std::endl;
  cout<< "\tscope: ";
  for( int i=0; i<arity; i++ )
    cout << scope[ i ]->getName() << " ";
  cout << endl;
}
