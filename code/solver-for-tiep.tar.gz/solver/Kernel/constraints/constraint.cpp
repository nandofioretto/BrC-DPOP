#include "constraint.hh"
#include "var_int.hh"
#include <rapidxml.hpp>

using namespace std;
using namespace rapidxml;


Constraint::Constraint()
  : constraintName( "" ), arity( 0 ), scope( 0 )
{
  static size_t g_CONSTRAINT_COUNTER = 0;
  constrID = g_CONSTRAINT_COUNTER++;
}


Constraint::Constraint (const Constraint& other)
{
  constrID   = other.constrID;
  constraintName   = other.constraintName; 
  type  = other.type;
  arity = other.arity;
  scope = other.scope;
}


Constraint& Constraint::operator= (const Constraint& other)
{
  if( this != &other )
  {
    constrID   = other.constrID;
    constraintName   = other.constraintName; 
    type  = other.type;
    arity = other.arity;
    scope = other.scope;
  }
  return *this;
}


Constraint::~Constraint()
{
  // nothing
}


vector<int> Constraint::getVars() const 
{
  vector<int> ret( arity );
  for( int i = 0; i < arity; i++ )
    ret[ i ] = scope[ i ]->getID();
  return ret;
}


bool Constraint::hasInScope( const var_int& v) 
{
  for( int i = 0; i < arity; i++ )
    if( *scope[ i ] == v )
      return true;
  return false;
}


void Constraint::dump() const 
{
  std::cout << "Constraint: " << constraintName << " arity: " << arity << " scope: ";
  for (int i = 0; i < arity; i++ ) {
    std::cout << scope[ i ]->getName() << ", ";
  }
  std::cout << std::endl;
}
