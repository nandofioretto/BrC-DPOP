#ifndef _ULISSE_PROPAGATOR_HH_
#define _ULISSE_PROPAGATOR_HH_

#include "globals.hh"

class var_int;
class IntHardConstraint;
class TrailStack;
class ConstraintStore;

class Propagator
{
public:
  Propagator();
  ~Propagator();

  /* typedef to a function pointer which 
     returns bool and takes in input int. */
  // typedef bool( Propagator::*propagator )( IntHardConstraint& ); 

  void initialize(TrailStack* t, ConstraintStore* s);

  // propagator select( IntHardConstraint &r );
  bool consistency( var_int& v );
  bool propagate( IntHardConstraint &r );
  
  bool c_int_EQ( IntHardConstraint &r );
  bool c_int_NE( IntHardConstraint &r );
  bool c_int_LT( IntHardConstraint &r );
  bool c_int_LEQ( IntHardConstraint &r );
  bool c_int_GT( IntHardConstraint &r );
  bool c_int_GEQ( IntHardConstraint &r );
  bool c_int_PlusEQconst( IntHardConstraint &r );
  bool c_int_lin_LEQ( IntHardConstraint& r );
  bool c_int_lin_GEQ( IntHardConstraint& r );
  bool c_int_lin_EQ( IntHardConstraint& r );
  bool c_int_within_iff( IntHardConstraint& r );


private:
  // Link to the trailstack used in search associated to this propagator.
  TrailStack* trailstack;
  // Link to the constraint-store used in the search associated to this
  // propagator 
  ConstraintStore* constraintStore;


};

#endif
