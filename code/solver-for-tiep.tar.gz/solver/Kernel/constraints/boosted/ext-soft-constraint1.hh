#ifndef _ULISSE_EXT_SOFT_CONSTRAINT_1_HH_
#define _ULISSE_EXT_SOFT_CONSTRAINT_1_HH_

#include "globals.hh"
#include "ext-soft-constraint.hh"
#include <rapidxml.hpp>
#include <boost/functional/hash.hpp>

using namespace rapidxml;


class ExtSoftConstraint1 : public ExtSoftConstraint 
{
 public:
 
  ExtSoftConstraint1( xml_node<>* relation )
  {
    initialize( relation, this );
  }

  void setCost( int* K, cost_type cost )
  {
    utilities[ {K[0]} ] = cost;
    // std::cout << constraintName << " seting cost: " << K[0] 
    // 	      << " : " << cost << std::endl;
  }
  
  /**
   * Return the cost associated to the tuple.
   * K *must* have size 1
   */
  cost_type getCost ( int* K )
  {
    // std::cout << constraintName << " getting cost: " << K[0] 
    // 	      << " : " << utilities[ {K[0]} ] << std::endl;
    got = utilities.find ({K[0]});
    if( got == utilities.end() ) return defaultCost;

    return utilities[ {K[0]} ];
  }
  
  void dump()
  {
    std::cout << "Ext Soft Constraint (1) " << constraintName
	      << " arity: " << arity 
	      << " ntuples: " << nb_tuples << " def cost: " 
	      << defaultCost << std::endl;
    std::cout<< "\tscope: ";
    for( int i=0; i<arity; i++ )
      std::cout << scope[ i ]->getName() << " ";
    std::cout << std::endl;
  }

 private:

  struct Key
  {
    int a;
    
    bool operator==(const Key &other) const
    { return (a == other.a); }
  };
  
  struct KeyHasher
  {
    std::size_t operator()(const Key& k) const
    {
      using boost::hash_value;
      using boost::hash_combine;
      std::size_t seed = 0;
      
      hash_combine(seed,hash_value(k.a));
      
      return seed;
    }
  };
  
  // The list of utilities
  std::unordered_map<Key,cost_type,KeyHasher> utilities;
  std::unordered_map<Key,cost_type,KeyHasher>::const_iterator got;

};


#endif
