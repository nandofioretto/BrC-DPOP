#include "relation.hh"

using namespace std;

Relation::Relation()
  : relationName( "" ), arity( 0 ), semantics( "" )
{  
  static size_t _g_RELATION_COUNTER = 0;
  relID = _g_RELATION_COUNTER++;
}

Relation::~Relation()
{  
  // nothing
}

Relation& Relation::operator= (const Relation& other)
{
  if( this != &other )
  {
    relID     = other.relID;
    arity  = other.arity;
    semantics = other.semantics;
    scope = other.scope;
  }
  return *this;
}
