#ifndef _ULISSE_RELATION_HH_
#define _ULISSE_RELATION_HH_

#include "globals.hh"
#include <rapidxml.hpp>

using namespace rapidxml;


class Relation 
{
 public:
  /**
   * Default Constructor.
   */
  Relation (rapidxml::xml_node<>* relation);

  /**
   * Copy Constructor.
   */
  Relation (const Relation& other);

  /**
   * Default Distructor.
   */
  ~Relation();

  /**
   * Operators
   */
  Relation& operator= (const Relation& other);

  bool operator== (const Relation& other);  // used by search functions

  bool operator< (const Relation& other)
  {
    return relID < other.relID;
  }
    
  bool operator() (Relation& ci, Relation& cj);
  
  /**
   * Returns the relation name.
   */
  std::string getName()
  {
    return relationName;
  }

  /**
   * Returns the realtion ID.
   */
  size_t getID()
  {
    return relID; 
  }
  
  /**
   * Returns the arity of the constraint associated with this relation.
   */
  int getArity()
  {
    return arity; 
  }
    
  /**
   * Returns the number of tuples expressed extensionally in the relation.
   */
  size_t getNumofTuples()
  {
    return nb_tuples;
  }

  /**
   * Retunrs the default cost of the relation
   */
  long int getDefaultCost()
  {
    return defaultCost;
  }

  /**
   * The total number of elements (tuples * arity)
   */
  size_t numofElements()
  {
    return nb_tuples*arity;
  }

  /**
   * The number of Costs elements
   */
  size_t sizeofCosts()
  {
    return nb_tuples;
  }

  /**
   * Return the cost associated to the tuple.
   */
  long int getCost ( std::vector<int>& tuple );

  /**
   * 
   */
  std::vector<int> getNextTuple( )
  {
    return _uit->first;
  }

  /**
   *
   */
  std::vector<int> getTuple( size_t pos );

  /**
   *
   */
  void set_uit_on_map_begin()
  {
    _uit = _utilities.begin();
  }

  /**
   *
   */
  bool is_uit_on_map_end()
  {
    return ( _uit == _utilities.end() );
  }

  /* int* get_costs(); */
  /* int* get_tuples(); */

  /**
   *
   */
  void dump();

 private:
  // The relation ID.
  size_t relID;
  
  // The relation name
  std::string relationName;
  
  // The arity of the relation
  int arity;

  // The number of value combinations in the relation
  size_t nb_tuples;

  // Semantic of relation 
  std::string semantics;
  
  // Default cost, that is the cost associated to any value combination
  // that is not present in _uit
  long int defaultCost;

  // The list of utilities
  std::map< std::vector<int>, long int > _utilities;

  // 
  std::map< std::vector<int>, long int >::iterator _uit;

  // at the beginning we trasnlate all the domain elments so that min(D) = 0.
  // _shift is the magnitude of the translation
  int _shift; 
};


#endif
