#include "domain.hh"
#include "var_int.hh"
#include <rapidxml.hpp>

using namespace std;
using namespace rapidxml;

Domain::Domain() 
  : domainName(""), values(0), numofValues(0) 
{ }


Domain::Domain(xml_node<>* dom) 
  : domainName(""), values(0), numofValues(0) 
{
  static size_t _g_CP_DOMAINS_COUNTER = 0;
  domID = _g_CP_DOMAINS_COUNTER++;
  domainName  = dom->first_attribute("name")->value();
  numofValues  = atoi( dom->first_attribute("nbValues")->value() );
  
  g_maxDomainSize = max( numofValues, g_maxDomainSize );

  values.resize( numofValues );
  
  string content = dom->value();
  size_t ival = content.find("..");
  if (ival != std::string::npos)
  {
    values[ 0 ] = atoi( content.substr(0, ival).c_str() ); 
    for (int i=1; i<numofValues; i++)
    {
      values[ i ] = values[ i - 1 ] + 1;
    }
  }
  else
  {
    stringstream ss( content );
    int i = 0;
    while( i < numofValues )
    {
      ss >> values[ i++ ];
    }
  }

  //g_domains[ domainName ] = this;
}


Domain::Domain( const Domain& other ) 
{
  numofValues = other.numofValues;
  values = other.values;
}


Domain::~Domain () 
{
  // nothing
}


Domain& Domain::operator= (const Domain& other) 
{
  if( this != &other )
  { 
    values = other.values;
  }
  return *this;
}
