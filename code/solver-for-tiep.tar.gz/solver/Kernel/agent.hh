#ifndef _UILSSE_AGENT_HH_
#define _UILSSE_AGENT_HH_

#include <vector>
#include <string>

#include "rapidxml.hpp"
#include "protocol.hh"

class var_int;
class Constraint;
class VariableOrdering;
class Protocol;
class SearchEngine;
class ExternalSearchEngine;
class InternalSearchEngine;

/* 
 * The abstract Agent class.
 * Each agent should derive from this class and implement all its 
 * communication functions
 */
class Agent
{
public:
  /** 
   * Agent default constructor.
   */
  Agent(rapidxml::xml_node<>* agent);
  
  /** 
   * Agent destructor - no actions performed.
   */ 
  ~Agent();
  
  bool operator== ( const Agent& other )
  {
    return agentID == other.agentID;
  }

  bool operator!= ( const Agent& other )
  {
    return agentID != other.agentID;
  }

  /**
   * Returns the agent ID.
   */
  size_t getID() const
  {
    return agentID; 
  }

  /**
   * Returns the Agent Name.
   */
  std::string getName() const
  {
    return agentName;
  }

  /**
   * Returns the optimization type being persuied by this agent.
   */
  optimization_type getOptimizationType() const
  {
    return optimization;
  }

  /**
   * Sets the optimization type being persuied by this agent.
   */
  void setOptimizationType(optimization_type opt)
  {
    optimization = opt;
  }

  /**
   * Sets the agent local constraint graph.
   */
  void setLocalConstraints();
  
  /**
   * Returns the agent local constraint graph (all constraints involving 
   * local variables only).
   */
  std::vector<Constraint*> getLocalConstraints() const
  {
    return localConstraints;
  }

  /**
   * Returns the i-th agent local constraint. 
   */
  Constraint& getLocalConstraint( int i ) const
  {
    return *localConstraints[ i ];
  }

  /**
   * Returns the number of local constraints.
   */
  size_t numofLocalConstraints() const
  {
    return localConstraints.size();
  }

  /**
   * Returns the agent local constraint graph restricted to those constraints
   * whose scope has not exclusively boundary variables.
   */
  // std::vector<Constraint*> getLocalNonBoundaryConstraints() const;
  // removed for efficiency - if needed - convert the localConstraint to a 
  // std.array and return simply the suffix here

  /**
   * Returns the i-th agent local constraint, where constraints involving 
   * exclusively boundary variables are not considered.  
   */
  Constraint& getNonBoundaryConstraint( int i ) const
  {
    return *localConstraints[ nBoundaryConstraints + i ];
  }

  /**
   * Returns the number of local constraints except the one involving exclusively
   * boundary variables.
   */
  size_t numofNonBoundaryConstraints() const
  {
    return localConstraints.size() - nBoundaryConstraints;
  }

  /**
   * Returns the i-th agent boundary constraint: the constraint which involves
   * exclusively boundary variables.
   */
  Constraint& getBoundaryConstraint( int i ) const
  {
    return *localConstraints[ i ];
  }

  /**
   * Returns the number of boundary constraints.
   */
  size_t numofBoundaryConstraints() const
  {
    return nBoundaryConstraints;
  }

  /**
   * Returns the set of boundary constraints.
   */
  std::vector< Constraint* > getBoundaryConstraints() const
  {
    std::vector<Constraint*> V( localConstraints.begin(),
	 localConstraints.begin() + nBoundaryConstraints );
    return V;
  }

  /**
   * Returns the set of local non-boundary constraints.
   */
  std::vector< Constraint* > getNonBoundaryConstraints() const
  {
    std::vector<Constraint*> V( localConstraints.begin() + nBoundaryConstraints,
				localConstraints.end() );
    return V;
  }

  /**
   * Sets the constraint involving the boundary variables of the agent
   * witht the its ancestor's boundary variables, in the given ordering
   * specified by the VariableOrdering adopted.
   */
  void setAncestorsConstraints( std::vector<Agent*> anc );
 
  /**
   * Returns the i-th ancestor constraints.
   *
   */
  Constraint& getAncestorsConstraint( int i ) const
  {
    return *ancestorsConstraints[ i ];
  }

  std::vector< Constraint* > getAncestorsConstraints() const
  {
    return ancestorsConstraints;
  }
  
  /** Returns the number of ancestors constraints.
   *
   */
  size_t numofAncestorsConstraints() const
  {
    return ancestorsConstraints.size();
  }

  /**
   * Returns the the i-th agent local variable.
   */
  var_int& getLocalVariable(int i) const
  {
    return *localVariables[ i ];
  }

  /**
   * Returns the number of local variables.
   */
  size_t numofLocalVariables() const
  {
    return localVariables.size();
  }

  /**
   * Returns the vector of local variables.
   */
  std::vector<var_int*> getLocalVariables()
  {
    return localVariables;
  }

  /**
   * Returns the i-th local-non-boundary variable.
   */
  var_int& getNonBoundaryVariable( int i ) const
  {
    return *localVariables[ nBoundaryVars + i ];
  }

  /**
   * Returns the number of local variables - non boundary.
   */
  size_t numofNonBoundaryVariables() const
  {
    return nNonBoundaryVars;
  }

  /**
   * Returns the vector of local variables.
   */
  std::vector<var_int*> getNonBoundaryVariables()
  {
    std::vector<var_int*> V( localVariables.begin() + nBoundaryVars,
				    localVariables.end() );
    return V;
  }

  /**
   * Returns the the i-th agent boundary variable.
   */
  var_int& getBoundaryVariable(int i) const
  {
    return *localVariables[ i ];
  }

  /**
   * Returns the number of boundary variables.
   */
  size_t numofBoundaryVariables() const
  {
    return nBoundaryVars;
  }

  /**
   * Returns the vector of boundary variables.
   */
  std::vector<var_int*> getBoundaryVariables()
  {
    std::vector<var_int*> V( localVariables.begin(),
				    localVariables.begin() + nBoundaryVars );
    return V;
  }

  /**
   * Check whether the variable 'v' is in the scope of this agent.
   * Complexity: O(lg nLocalVars)
   */
  bool hasInLocalVariables(var_int& v) const;

  /**
   * Check whether the variable 'v' is in the scope of this agent.
   * Complexity: O(nBoundaryVars)
   */
  bool hasInBoundaryVariables(var_int& v) const;

  /**
   * Returns the list of all boundary variables involved in 
   * the scope of the constraint 'con'
   * @todo: remove from here -- this should not be in Agent.
   */
  // deprecated??
  // std::vector< var_int* > getBoundaryVariablesIn(std::vector< Constraint* > con); 

  /**
   * Add a variable in the scope of the agents local variables.
   * @todo: move out! this function does not belong to the agent properties.
   */
  void addLocalVariable(var_int& v);

  /**
   * Add boundary variables.
   * @todo: This function conflicts with the logic of distributed agents,
   *  change the way it is called.
   */
  void addBoundaryVariables();

  /**
   * Initializes the external search engine for the agent's boundary variables.
   */
  void setExternalSearchEngine( SearchEngine* se );
  
  /**
   * Get the External search Engine;
   */ 
  ExternalSearchEngine& getExternalSearchEngine()
  {
    return (ExternalSearchEngine&)(*extSearchEngine);
  }

  /**
   * Initializes the agent search engine for local variables.
   */
  void setInternalSearchEngine( SearchEngine* se );

  /**
   * Get the Agent internal search engine.
   */
  InternalSearchEngine& getInternalSearchEngine()
  {
    return (InternalSearchEngine&)(*intSearchEngine);
  }

  /**
   * Initializes the agent behavior.
   */
  void setProtocol( Protocol* p, VariableOrdering& O );

  /**
   * Executes the agent protocol.
   */
  void runProtocol()
  {
    behavior->run();
  }

  /**
   * Returns the agent mailbox.
   */
  MailboxSystem& openMailbox(std::string type )
  {
    return behavior->openMailbox( type );
  }

  /**
   * Outputs some Agent specifics.
   */
  void dump();


private:
  // the agent id (starting from 0...nAgents)
  size_t agentID;

  // The agent name, which is a unique id
  std::string agentName;

  // The agent scope
  std::vector< var_int* > localVariables;

  // numof boundary variables
  size_t nBoundaryVars;

  // numof non-boundary variables
  size_t nNonBoundaryVars;

  // The local constraint graph: the constraints whose scope involves
  // only local variables (includes boundary variables as well)
  // @note: local_constraints is organized so that the boundary constraints,
  //        i.e., those constraints whose scope includes exclusively 
  //        boundary variable, are listed first.
  std::vector<Constraint*> localConstraints;

  int nBoundaryConstraints;

  // The constraints involving the boundary variables of the agent 
  // and the boundary variables of the agent's ancestors. We consider
  // only those ancestors whose variables have been assigned already.
  // The order depends on the protocol (and variable ordering) adopted.
  std::vector<Constraint*> ancestorsConstraints;
  
  // The type of optimization problem (maixmize or minimize)
  optimization_type optimization;

  // The search engine acting only on the boundary variables
  SearchEngine* extSearchEngine;

  // The search engine acting on the local variables only, fixing a
  // (combination of) value(s) for the boundary variable(s)
  SearchEngine* intSearchEngine;

  // The behavior specific to each agent.
  Protocol* behavior;

};


#endif
