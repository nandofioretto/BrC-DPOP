/*********************************************************************
 * var_int 
 *********************************************************************/
#ifndef CP_VAR_INT_H
#define CP_VAR_INT_H

#include "cpff_globals.h"
#include "variable.h"
#include "domain.h"


class TrailVariable;

class var_int : public Variable {
private:
  bool already_assigned;
  int dom_size;
  std::vector< int > dom_values;
  
public:
  Domain domain;
  
  var_int ();
  var_int ( std::vector< int > dom );
  var_int ( const var_int& other );

  ~var_int ();

  int get_domain_size();
  bool is_already_assigned();
  void set_already_assigned();
  void unset_already_assigned();
  void unset_singleton ( size_t idx );
  void print_value();
  int get_value();
  int count_active_elements();

  virtual void set_unique_singleton();
  virtual void set_singleton (size_t idx);
  virtual bool is_singleton();
  virtual bool labeling ();
  
  /* Bounds management */
  virtual int get_lower_bound();
  virtual int get_upper_bound();
  
  virtual void reset_bounds();
  virtual void set_bounds( int lb, int ub, bool check_assigned=true );
  virtual void set_lower_bound( int v );
  virtual void set_upper_bound( int v );
   
  virtual unsigned int* get_dom_state();
  virtual void  set_dom_state( unsigned int* other_state  );
  virtual void trail_back ( TrailVariable& tv );

  virtual void dump ();  
};//-

#endif
