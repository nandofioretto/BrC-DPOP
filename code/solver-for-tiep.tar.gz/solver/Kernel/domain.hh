#ifndef _ULISSE_DOMAIN_HH_
#define _ULISSE_DOMAIN_HH_

#include "globals.hh"
#include <rapidxml.hpp>

/*
 * Domain of integers
 */
class Domain 
{
public:
  /**
   * Default constructor
   */
  Domain();

  /**
   * Construct domain by parsing the xml file
   */
  Domain( rapidxml::xml_node<>* dom );

  /**
   * Copy constructor
   */
  Domain( const Domain& other );
  
  /**
   * Desctructor - frees the values and state
   */
  ~Domain();

  /**
   * Assignment operator
   */
  Domain& operator= (const Domain& other);

  /**
   * Get domain ID
   */
  size_t getID() const
  {
    return domID;
  }
  
  /**
   * Get domain Name
   */
  std::string getName() const
  {
    return domainName;
  }

  /**
   * Get all values
   */
  std::vector<int> getValues() const
  {
    return values;
  }

  /*
   * Returns the number of elements in the domain
   */
  size_t size() const
  {
    return numofValues;
  }

  /*
   * Dump domain content
   */
  void dump ();

private:
  size_t domID;
  
  /// The domain name, which is a unique id
  std::string domainName;
  
  /// The domain content - its values in ascending order
  std::vector<int> values;

  /// The number of elements in the domain
  size_t numofValues;
  
};

#endif
