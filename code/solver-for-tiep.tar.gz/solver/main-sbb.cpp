#include "globals.hh"
#include "parser.hh"
#include "agent.hh"
#include "statistics.hh"

#include "linear-ordering.hh"
#include "pseudo-tree.hh"
#include "constraint.hh"
#include "scheduler.hh"

// SynchBB
#include "sbb-search.hh"
#include "sbb-protocol.hh"
// Simple DFS
#include "dfs-search.hh"


using namespace std;

//#define INT_HARD_CONSTR

int main (int argc, char* argv[])
{
  string _input;
  double _timeout;
  string local_search="CP_DFS";
  string dcop_protocol="DPOP";

  if (argc > 7) 
    { Parser::dumpHelp(); return -1; }
  
  for (int i=0; i< argc; i++) 
  {
    if( !strcmp("-h", argv[i]) )  { Parser::dumpHelp(); return -1; }
    if( !strcmp("-i", argv[i]) )   _input = argv[++i];
    if( !strcmp("-ls", argv[i]) )  local_search = argv[++i];
    if( !strcmp("-es", argv[i]) )  dcop_protocol = argv[++i];
    //else { Parser::dumpHelp(); return -1; }
  }
  
  // Initialize statistics 
  g_stats.initialize( argc, argv );
  g_stats.setTimer( t_WALL_CLOCK, 0 );
  g_stats.setTimer( t_init, 0 );

  // Initialize Scheduler
  g_scheduler = new Scheduler();

  // Parse the xml file
  Parser::parseXML( _input );
  Parser::postParseInitializations(); 

  // Establish a communication schema:
  PseudoTree PT;
  LinearOrdering LO; // Linear ordering schema (for SBB)

  for ( auto ai : g_agents)
  {
    if( dcop_protocol == "DPOP" ) 
    {
      // ai.second->setProtocol( new DPOP::DPOPprotocol(), PT );
      // ai.second->setDcopSearchEngine( new DPOP::DPOPsearch( ) );
    }
    else if( dcop_protocol == "SBB" )
    { 
      ai.second->setProtocol( new SynchBB::SynchBBProtocol(), LO );
      ai.second->setDcopSearchEngine( new SynchBB::SynchBBserch( ) );
    }

    if( local_search == "DFS" )
    {
      ai.second->setAgentSearchEngine( new Search::DFSsearch() );
    }
    else if( local_search == "CP_DFS" )
    {
      // ai.second->setAgentSearchEngine( new CPBased::DFSsearch() );
    }
    //ai.second->dump();
  }
  g_stats.stopwatch( t_init, 0 );

  std::vector<Agent*> starting_agents; 

  // Extract the agents starting the protocol
  if( dcop_protocol == "DPOP" ) 
  {
    // for( auto n : PT.getLeaves() ) {
    //   starting_agents.push_back( &n->getContent() );  
    // }
  }
  else if( dcop_protocol == "SBB" )
  {
    starting_agents.push_back( &LO.getHead().getContent() );
  }

  // Start the protocol
  g_scheduler->start( starting_agents );


  g_stats.stopwatch( t_WALL_CLOCK, 0 );

  // Report Statistics
  g_stats.dump();
  cout << "Num of sol: " << g_numof_solutions << endl;
  cout << "Num of nodes explored: " << g_numof_nodes_explored << endl;

  return 0;
}
