/* Permutations 
 * This class is used to generate the describe the possible node 
 * permutation of K nodes for a network of N nodes.
 */

#ifndef PERMUTATIONS_H
#define PERMUTATIONS_H

#include "globals.h"

class Permutations {
 private:
  int n, k;
  cost_type* permutations;
  int _size;
  cost_type* T;
  void generate();
  int level;
  int perm_counter;

 public:
  Permutations(int n, int k);
  ~Permutations();

  cost_type* get_permutations();
  size_t size() const;
  int get_k() const;
  int get_n() const;
  void dump();
};

#endif
