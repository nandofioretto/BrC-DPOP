#ifndef _ULISSE_STATISTICS_HH_
#define _ULISSE_STATISTICS_HH_

#include "globals.hh"

enum t_stats { t_search_boundary, t_search_local, 
	       t_init, t_comm, t_statistics, t_wasted, 
	       t_WALL_CLOCK, t_stat_size };

enum m_stats { m_bcdpop_UTILrows_bp=0, m_bcdpop_UTILrows_ap, 
	       m_bcdpop_UTILentries_bp, m_bcdpop_UTILentries_ap, 
	       m_dpop_UTILrows_bp, m_dpop_UTILrows_ap, 
	       m_dpop_UTILentries_bp, m_dpop_UTILentries_ap,
	       m_bcdpop_AC, m_bcdpop_BC,
	       m_stats_size };

class Statistics
{
 private:
  timeval** time_stats;//[ t_stat_size ][ 150 ];  
  double t_limit;
  double t_total_limit;
  double** time_start;//[ t_stat_size ][ 150 ];
  double** time;//[ t_stat_size ][ 150 ];
  double** total_time;//[ t_stat_size ][ 150 ];
  cost_type best_cost;

  std::map< m_stats, std::map<int, size_t> > messageSize;

 public:
  Statistics();
  void initialize(int argc, char* argv[]);
  ~Statistics();

  void reset(); 
  void setTimeout (double sec)
  {
    t_limit = sec;
  }

  void setTotalTimeout (double sec)
  {
    t_total_limit = sec;
  }

  void setTimer (t_stats t, int a=0)
  {
    gettimeofday( &time_stats[ t ][ a ], NULL );
    time_start[ t ][ a ] = time_stats[ t ][ a ].tv_sec 
      + ( time_stats[ t ][ a ].tv_usec / 1000000.0);
  }

  void forceSetTime(t_stats t, int a=0)
  {
    time[ t ][ a ] = t;
  }

  double getTimer (t_stats t, int a=0)
  {
    return time[ t ][ a ]; 
  }
    
  double getTotalTimer (t_stats t, int a=0)
  { 
    if( t != t_statistics )
      return( total_time[ t ][ a ] - total_time[ t_statistics ][ a ] );
    else
      return total_time[ t ][ a ];
  }

  void stopwatch (t_stats t, int a=0)
  {
    gettimeofday( &time_stats[ t ][ a ], NULL );
    time[ t ][ a ] = time_stats[ t ][ a ].tv_sec 
      + ( time_stats[ t ][ a ].tv_usec / 1000000.0 ) 
      - time_start[ t ][ a ];
    
    total_time[ t ][ a ] += time[ t ][ a ];
  }

  bool timeout (int a)
  {
    if( ! t_limit ) return false;
    stopwatch( t_search_boundary, a );
    stopwatch( t_search_local, a );
    if( (total_time[ t_search_boundary ][ a ] + 
	total_time[ t_search_local ][ a ] )>= t_limit )
      return true;
    return false;
  }

  void setMsgSize( m_stats m, int aID, size_t msg_size )
  {
    // if( messageSize[ m ].find( aID ) == messageSize[ m ].end() )
    //   messageSize[ m ][ aID ] = 0;

    messageSize[ m ][ aID ] = msg_size;
  }

  size_t getMsgSize( m_stats m, int aID )
  {
    return messageSize[ m ][ aID ];
  }

  void setBestCost( cost_type u )
  {
    best_cost = u;//std::max(best_cost, u);
  }

  int getBestCost( )
  {
    return best_cost;
  }

  size_t getMaxRSS() const; 
  void dump( std::ostream &os=std::cout );
  void dump_csv (std::ostream &os=std::cout);

};

#endif
