#include "statistics.hh"
#include "globals.hh"

Statistics::Statistics()
  : t_limit( 0 ), t_total_limit( 0 )
{
  // nothing
}

void Statistics::initialize(int argc, char* argv[]) 
{  
  /* Process the input parameters */
  for (int narg = 0 ; narg < argc  ; narg++) {
    if (!strcmp( "-t", argv[ narg ] ) )
    {
      t_limit = atof( argv[ narg + 1 ] );      
    }//-
  }

  time_stats = (timeval**) new timeval*[ t_stat_size ];
  time_start = (double**) new double*[ t_stat_size ];
  time       = (double**) new double*[ t_stat_size ];
  total_time = (double**) new double*[ t_stat_size ];

  for(int t=0; t<t_stat_size; t++)
  {
    time_stats[ t ] = new timeval[ g_agents.size() ];
    time_start[ t ] = new double[ g_agents.size() ];
    time[ t ] = new double[ g_agents.size() ];
    total_time[ t ] = new double[ g_agents.size() ];
  }

  reset();

}//-  

 
Statistics::~Statistics() 
{ 
  for(int t=0; t<t_stat_size; t++)
  {
    delete[] time_stats[ t ];
    delete[] time_start[ t ];
    delete[] time[ t ];
    delete[] total_time[ t ];
  } 
  delete[] time_stats;
  delete[] time_start;
  delete[] time;
  delete[] total_time;
}//-

void 
Statistics::reset () 
{

  for( int i = 0; i < t_stat_size; i++) 
  {
    for(int a=0; a<g_agents.size(); a++)
    {
      time_start[ i ][ a ] = 0;
      time[ i ][ a ] = 0;
      total_time[ i ][ a ] = 0;
    }
  }
  best_cost = NA_VALUE;
}//-


size_t
Statistics::getMaxRSS() const {
  int len = 0; 
  int srtn = 0;
  char procf[257] = { "" };
  FILE *fp = NULL;
  char line[2001] = { "" };
  char crap[2001] = { "" };
  char units[2001] = { "" };
  size_t maxrss = 0L;
  size_t maxrsskb = 0L;

  sprintf(procf,"/proc/%d/status",getpid());
  
  fp = fopen(procf, "r");
  if(fp == NULL){
    return -1;
  }
  
  while(fgets(line, 2000, fp) != NULL){
    if(strncasecmp(line,"VmPeak:",7) == 0){
      len = (int)strlen(line);
      line[len-1] = '\0';
      srtn = sscanf(line,"%s%ld%s",crap,&maxrss,units);
      if(srtn == 2){
        maxrsskb = maxrss / 1024L;
      }else if(srtn == 3){
        if( (strcasecmp(units,"B") == 0) || (strcasecmp(units,"BYTES") == 0) ){
          maxrsskb = maxrss / 1024L;
        }else if( (strcasecmp(units,"k") == 0) || (strcasecmp(units,"kB") == 0) ){
          maxrsskb = maxrss * 1L;
        }else if( (strcasecmp(units,"m") == 0) || (strcasecmp(units,"mB") == 0) ){
          maxrsskb = maxrss * 1024L;
        }else if( (strcasecmp(units,"g") == 0) || (strcasecmp(units,"gB") == 0) ){
          maxrsskb = maxrss * 1024L * 1024L;
        }else{
          maxrsskb = maxrss * 1L;
        }
      }
      break;
    }
  }
  
  fclose(fp);
  
  return maxrsskb;
}


void 
Statistics::dump (std::ostream &os) 
{
  os << "\t============ ULISSE statistics ============\n";
  double tot_init = 0;
  double tot_search_b = 0;
  double tot_search_l = 0;
  double tot_search = 0;
  double tot_search_a = 0;
  double tot_comm = 0;
  double max_search = 0;
  double max_comm   = 0;
  double tot_waste = 0;
  double tot_stats = 0;
  
  std::map< int, size_t > totMsgSize; 
  std::map< int, size_t > maxMsgSize; 

  for (int i = 0; i < m_stats_size; i++ )
    {
      totMsgSize[ i ] = 0;
      maxMsgSize[ i ] = 0;
    }

  for (int a = 0; a < g_agents.size(); a++ )
    {
      tot_init     += getTotalTimer( t_init, a );
      tot_search_b += getTotalTimer( t_search_boundary, a );
      tot_search_l += getTotalTimer( t_search_local, a );
      tot_comm     += getTotalTimer( t_comm, a );
      tot_waste    += getTotalTimer( t_wasted, a );
      tot_stats    += getTotalTimer( t_statistics, a );
      
      tot_search_a = getTotalTimer( t_search_boundary, a ) 
	+ getTotalTimer( t_search_local, a );
      
      tot_search  += tot_search_a;
      
      if( tot_search_a > max_search )  {
	max_search = tot_search_a;
	max_comm   = getTotalTimer( t_comm, a );
      }

      for ( int m = 0; m < m_stats_size; m++ )
	{
	  maxMsgSize[ m ] = std::max( maxMsgSize[ m ], 
				      getMsgSize( (m_stats)(m) , a ) );
	  totMsgSize[ m ] += getMsgSize( (m_stats)(m), a );
	}
    }

  double wall_clock_time = getTotalTimer( t_WALL_CLOCK, 0 );
  double used_time = (tot_comm - tot_waste);

  os << "  Init Time                   :  " << tot_init << " s.\n"
     << "  w.c. time Search on Boundary:  " << tot_search_b << " s.\n" 
     << "  w.c. time Search on Local   :  " << tot_search_l << " s.\n" 
     << "  w.c. time Search            :  " << tot_search   << " s.\n" 
     << "  Communication Time          :  " << tot_comm << " s.\n" 
     << "  Simulated time              :  " << max_comm + max_search << " s.\n"
     << "  Wall clock time             :  " << wall_clock_time - tot_init - tot_stats << " s.\n"
     << "  Best Cost                   :  " << best_cost << "\n"
     << "  ----------------------------\n"
     << "  DPOP UTIL msgSize #rows Before Proj       (lrg / tot) :  " 
     << maxMsgSize[ m_dpop_UTILrows_bp ] << " / " << totMsgSize[ m_dpop_UTILrows_bp ] << "\n"
     << "  DPOP UTIL msgSize #rows After  Porj       (lrg / tot) :  " 
     << maxMsgSize[ m_dpop_UTILrows_ap ] << " / " <<  totMsgSize[ m_dpop_UTILrows_ap ] << "\n"
     << "  BC-DPOP UTIL msgSize #rows Before Proj    (lrg / tot) :  " 
     << maxMsgSize[ m_bcdpop_UTILrows_bp ] <<  " / " << totMsgSize[ m_bcdpop_UTILrows_bp ] << "\n"
     << "  BC-DPOP UTIL msgSize #rows After Proj     (lrg / tot) :  " 
     << maxMsgSize[ m_bcdpop_UTILrows_ap ] <<  " / " << totMsgSize[ m_bcdpop_UTILrows_ap ] << "\n"
     << "  BC-DPOP UTIL msgSize #entries Before Proj (lrg / tot) :  "
     <<maxMsgSize[ m_bcdpop_UTILentries_bp ] <<  " / " << totMsgSize[ m_bcdpop_UTILentries_bp ] << "\n"
     << "  BC-DPOP UTIL msgSize #entries After Proj  (lrg / tot) :  "
     <<maxMsgSize[ m_bcdpop_UTILentries_ap ] <<  " / " << totMsgSize[ m_bcdpop_UTILentries_ap ] << "\n"
     << "  BC-DPOP AC msgSize  (tot) :  " << totMsgSize[ m_bcdpop_AC ] << "\n"
     << "  BC-DPOP BC msgSize  (tot) :  " << totMsgSize[ m_bcdpop_BC ] << " \n";
	
}//-

void 
Statistics::dump_csv (std::ostream &os)
{
}//-
