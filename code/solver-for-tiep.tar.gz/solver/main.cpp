#include "globals.hh"
#include "parser.hh"
#include "agent.hh"
#include "domain.hh"
#include "var_int.hh"
#include "statistics.hh"

#include "linear-ordering.hh"
#include "pseudo-tree.hh"
#include "constraint.hh"
#include "scheduler.hh"

// SynchBB
#include "sbb-protocol.hh"
// DPOP
#include "dpop-protocol.hh"
// RDPOP
#include "rdpop-protocol.hh"
#include "rdpop-AC.hh"

// External search engines
#include "prop-rdfs.hh"
#include "dfs.hh"
// Internal search engines
#include "prop-idfs.hh"

#include "cv-matrix.hh"


using namespace std;

//#define INT_HARD_CONSTR

int main (int argc, char* argv[])
{
  string _input;
  double _timeout;
  string local_search="CP_DFS";
  string dcop_protocol="RDPOP";

  if (argc > 7) 
    { Parser::dumpHelp(); return -1; }
  
  for (int i=0; i< argc; i++) 
  {
    if( !strcmp("-h", argv[i]) )  { Parser::dumpHelp(); return -1; }
    if( !strcmp("-i", argv[i]) )   _input = argv[++i];
    if( !strcmp("-ls", argv[i]) )  local_search = argv[++i];
    if( !strcmp("-es", argv[i]) )  dcop_protocol = argv[++i];
    //else { Parser::dumpHelp(); return -1; }
  }
  
  // Parse the xml file
  Parser::parseXML( _input );	// HACK to count time as well in satats
  Parser::postParseInitializations(); 

  // Initialize statistics 
  g_stats.initialize( argc, argv );
  g_stats.setTimer( t_WALL_CLOCK, 0 );
  g_stats.setTimer( t_init, 0 );

  // Initialize Scheduler
  g_scheduler = new Scheduler();

  // // Establish a communication schema:
  PseudoTree PT;
  LinearOrdering LO; // Linear ordering schema (for SBB)
  PT.dump();

  for ( auto ai : g_agents)
  {
    if( dcop_protocol == "DPOP" ) 
    {
      ai.second->setProtocol( new DPOP::DPOPprotocol(), PT );
      ai.second->setExternalSearchEngine( new ExtSearch::PropDFS() );
      // unsets the propagation flag as external constraints are
      // solved via the dynamic programming approach.
      ai.second->getExternalSearchEngine().unsetPropagationFlag();
    }
    else if( dcop_protocol == "SBB" )
    { 
      ai.second->setProtocol( new SynchBB::SynchBBProtocol(), LO );
      ai.second->setExternalSearchEngine( new ExtSearch::PropDFS( ) );
      ai.second->getExternalSearchEngine().setPropagationFlag();
    }
    else if( dcop_protocol == "RDPOP" )
    {
      // include the following in the procedure below: 
      for( auto kv_c : g_constraints ) {
	CVMatrix *cvm = new CVMatrix();
	cvm->initialize( *(kv_c.second) );
      }
      ai.second->setProtocol( new DPOP::RDPOPprotocol(), PT );

      ai.second->setExternalSearchEngine( new ExtSearch::RDPOPsearch() );
      // sets the propagation flag as external
      ai.second->getExternalSearchEngine().setPropagationFlag();
    }

    if( local_search == "DFS" )
    {
      ai.second->setInternalSearchEngine( new IntSearch::DFS() );
    }
    else if( local_search == "CP_DFS" )
    {
      ai.second->setInternalSearchEngine( new IntSearch::PropDFS() );
    }
    //ai.second->dump();
  }
  g_stats.stopwatch( t_init, 0 );

  std::vector<Agent*> starting_agents; 
  // Extract the agents starting the protocol
  if( dcop_protocol == "DPOP" ) 
  {
    for( auto n : PT.getLeaves() ) {
      starting_agents.push_back( &n->getContent() );  
    }
  }
  else if( dcop_protocol == "RDPOP" ) 
  {
    for( auto n : PT.getLeaves() ) {
      starting_agents.push_back( &n->getContent() );  
    }
  }
  else if( dcop_protocol == "SBB" )
  {
    starting_agents.push_back( &LO.getHead().getContent() );
  }

  // Start the protocol
  g_scheduler->start( starting_agents );

  g_stats.stopwatch( t_WALL_CLOCK, 0 );

  // // Report Statistics
  g_stats.dump();
  cout << "Num of sol: " << g_numof_solutions << endl;
  cout << "Num of nodes explored: " << g_numof_nodes_explored << endl;

  for( auto kv : g_agents ) delete kv.second;
  for( auto kv : g_domains ) delete kv.second;
  for( auto kv : g_variables ) delete kv.second;
  for( auto kv : g_constraints ) delete kv.second;
  delete g_scheduler;

  return 0;
}
