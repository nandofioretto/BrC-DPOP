#include <iostream>
#include <vector>

using namespace std;

class var
{
public:
  var() {
    static int AAA=0;
    id = AAA++;
  }
  int id;
};


int main()
{
  std::vector<var*> V;
  V.push_back( new var() );
  V.push_back( new var() );

  std::vector<var*> V2;

  V.insert(V.end(), V2.begin(), V2.end());
  for( auto v : V ) cout << "var " << v->id << endl;

}
