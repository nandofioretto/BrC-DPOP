#include <iostream>
#include <vector>

using namespace std;

class Agent
{
public:
  Agent(): id( 0 ) {};
  
private:
  int id;
  std::vector<int> aa;
};

int main(){
  vector<int> A;
  for(int i=0; i<10; i++ ) A.push_back( i );

  vector<int> B( A.begin() + 5, A.end() );
  
  for( auto b : B ) cout << b << ", ";
  cout << endl;
  
  return 0;

}
