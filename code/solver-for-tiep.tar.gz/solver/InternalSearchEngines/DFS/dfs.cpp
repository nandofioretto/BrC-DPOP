#include "dfs.hh"
#include "agent.hh"
#include "var_int.hh"
#include "constraint.hh"
#include "ext-soft-constraint.hh"

using namespace std;
using namespace IntSearch;

//#define DBG

DFS::DFS( ) : currLevel( 0 )
{ }


DFS::~DFS( )
{ }

//@incomplete
void DFS::initialize( Agent& a )
{ 
  owner = &a;
  // Initializes the scope and solutions of the search
  initSearchSettings();
  // popolate the SoftConstraint vector
  initSoftConstraints();
  // popolate the HardConstraint vector
  //initHardConstraints();
  
  if( not hardConstraints.empty() ) {
    printWarningMessage( "Internal-Search-Engine::DFS cannot tackle hard constraints" );
  }
  
  // Init current level and continuation
  zeroLevel = a.numofBoundaryVariables();
  currLevel = zeroLevel;
  
}


// @incomplete
bool DFS::nextSolution()
{
  printWarningMessage( "DPOPsearch::bestSolution()" );
  return false;
}


bool DFS::bestSolution() 
{
  searchEnded = false;
  // check wheter the scope of the search is empty
  if( scope.size() == zeroLevel ) { searchEnded = true; return true; } 

  for( int i=0; i<zeroLevel; i++)
  {
    curr_solution[ i ] = getVariable( i ).getLabel();
    best_solution[ i ] = getVariable( i ).getLabel();
    // curr_solution[ i ] = getVariable( i ).getValue();
    // best_solution[ i ] = getVariable( i ).getValue();
  }

  currLevel = zeroLevel;
  best_solution.reset();
  
  // Search Best Solution
  search();
  searchEnded = true;		// Flag search termination
  cost_type u = best_solution.getCost();
  return ( isNotNA( u ) and isFinite( u ) );
}


bool DFS::allSolutions()
{
  printWarningMessage( "DPOPsearch::bestSolution()" );
  return false;
}


bool DFS::search( )
{
  if( currLevel == scope.size() ) {
    copySolution();
    return processSolution();
  }
  while( labeling() )
  {
    nextLevel();
    search();
    prevLevel();
  }
  searchEnded = true;		// Flag search termination
  return true; 		     
}


bool DFS::labeling()
{
  var_int& v = getVariable( currLevel );

  if( v.labeling() ) 
  {
    g_numof_nodes_explored++;
    return true;
  } 
  return false;
}


void DFS::copySolution( )
{
  for( int i=zeroLevel; i<scope.size(); i++ )
  {
    //curr_solution[ i ] = getVariable( i ).getValue();
    curr_solution[ i ] = getVariable( i ).getLabel();
  }
}



void DFS::dump() const
{
  cout << "Internal-DFS::scope of the Search: "
       << " scope size: " << scope.size() << endl;
  for( auto i : scope )
  {
    i->dump();
  }
}
