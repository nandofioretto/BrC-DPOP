#ifndef _ULISSE_DFS_INT_SEARCH_HH_
#define _ULISSE_DFS_INT_SEARCH_HH_

#include "globals.hh"
#include "internal-search-engine.hh"

class Agent;
class ExtSoftConstraint;

namespace IntSearch {

  /**
   * A DFS search engine.
   * Implements a DFS on the local (non boundary) variables
   * of each agent.
   */
  class DFS : public InternalSearchEngine
  {
  public:
    /**
     * Default constructor.
     */
    DFS( );
    
    /**
     * Default distructor.
     */
    ~DFS( );
    
    /**
     * Initializes the agent associated to this search engine, 
     * the variables over which perform the search 
     */
    void initialize( Agent& a );

    /**
     * Reset search state.
     */
    void reset()
    {
      searchEnded = false;
      currLevel = 0;
    }
    
    /**
     * Finds the next satisfiable solution in the given enumeration 
     * of the solution space.
     */
    bool nextSolution();
    
    /**
     * Finds the assignment to the variables in scope which optimizes
     * the local cost.
     */
    bool bestSolution();
    
    /**
     * Finds all possible satisfiable solutions.
     */
    bool allSolutions();
    
    
    virtual void dump() const;

  private:
    /**
     * @aux A recursive search exploring the whole search tree.
     */
    bool search();
    
    /**
     * @aux Performs a labeling on variable associated to currLevel 
     */
    bool labeling();
    
    /**
     * @aux Used to navigate through the recursive search. 
     */
    void nextLevel()
    {
      currLevel++;
    }
    
    void prevLevel()
    {
      currLevel--;
    }
    
    /**
     * Returns the pointer to the variable associated to the i-th
     * element of the SearchEngine::scope
     */
    var_int& getVariable( int i ) const
    {
      return *scope[ i ];
    }
    
    /**
     * Updates the current solution with the current assignment.
     */
    void copySolution();
    
  private:
    // The current depth-level in the search tree exploration. 
    int currLevel;

    // The starting level of the search - it holds the size of the boundary
    // variables (already assigned by the Dcop search engine).
    int zeroLevel;

  };
  
};

#endif
