#include "parser.hh"
#include "agent.hh"
#include "domain.hh"
#include "var_int.hh"
#include "constraint.hh"
#include "rapidxml.hpp"
#include "ext-soft-constraint.hh"
#include "boosted/ext-soft-constraint1.hh"
#include "boosted/ext-soft-constraint2.hh"
#include "boosted/ext-soft-constraint3.hh"
#include "boosted/ext-soft-constraint4.hh"
#include "boosted/ext-soft-constraint5.hh"
#include "boosted/ext-soft-constraint6.hh"
#include "boosted/ext-soft-constraint7.hh"
#include "boosted/ext-soft-constraint8.hh"
#include "boosted/ext-soft-constraint9.hh"

#include "int-hard-constraint.hh"

using namespace std;
using namespace rapidxml;

//#define DBG_IO

void Parser::parseXML ( std::string xml_file ) 
{
  int size = 0;
  string input_xml;
  string line;
  ifstream in( xml_file.c_str() );
  while( getline( in, line) )
    input_xml += line;

  // make a safe-to-modify copy of input_xml
  vector<char> xml_copy(input_xml.begin(), input_xml.end());
  xml_copy.push_back('\0');
  xml_document<> doc;
  doc.parse<parse_declaration_node | parse_no_data_nodes>( &xml_copy[ 0 ] );
  xml_node<>* root = doc.first_node("instance");
  xml_node<>* xpre = root->first_node("presentation");
  optimization_type opt;
  if( xpre->first_attribute("maximize") )
  { 
    std::string optMax = xpre->first_attribute("maximize")->value();
    if ( optMax.compare("true") == 0 )
      opt = maximize;
    else 
      opt = minimize;
  }
  g_optimizationType = opt;


  // Parse Agents 
  xml_node<>* xagents = root->first_node("agents");
  xml_node<>* xagent   = xagents->first_node("agent");
  do
  {
    Agent *agent = new Agent( xagent );
    agent->setOptimizationType ( opt );
    // safe agent in the global map
    g_agents[ agent->getName() ] = agent;
    g_Agents[ agent->getID() ] = agent;

    xagent = xagent->next_sibling();
  } while ( xagent );


  // Parse and create domains
  xml_node<>* xdoms = root->first_node("domains");
  xml_node<>* xdom = xdoms->first_node("domain");
  do
  {
    Domain *dom = new Domain( xdom );
    // safe domain in the global map
    g_domains[ dom->getName() ] = dom;

    xdom = xdom->next_sibling();
  } while ( xdom );


  // Parse and create variables
  xml_node<>* xvars = root->first_node("variables");
  xml_node<>* xvar = xvars->first_node("variable");
  do 
  {
    var_int *var = new var_int( xvar );
    // safe domain in the global map
    g_variables[ var->getName() ] = var;
    g_Variables[ var->getID() ] = var;

#ifdef DBG_IO
    var->dump();
#endif
    xvar = xvar->next_sibling();
  } while ( xvar );


  // Parse and create Extensional Soft Constraints
  xml_node<>* xrels = root->first_node("relations");
  size = atoi( xrels->first_attribute("nbRelations")->value() );
  if( size > 0 )
  {
    xml_node<>* xrel = xrels->first_node("relation");
    do
    {
      int arity = atoi( xrel->first_attribute("arity")->value() );
      switch( arity )
      {
      case 1: {
	ExtSoftConstraint1* rel = new ExtSoftConstraint1( xrel );
	g_constraints[ rel->getName() ] = rel;
	g_Constraints[ rel->getID() ] = rel;
	break;
      }
      case 2: {
	ExtSoftConstraint2* rel = new ExtSoftConstraint2( xrel );
	g_constraints[ rel->getName() ] = rel;
	g_Constraints[ rel->getID() ] = rel;
	break;
      }
      case 3: {
	ExtSoftConstraint3* rel = new ExtSoftConstraint3( xrel );
	g_constraints[ rel->getName() ] = rel;
	g_Constraints[ rel->getID() ] = rel;
	break;
      }
      case 4: {
	ExtSoftConstraint4* rel = new ExtSoftConstraint4( xrel );
	g_constraints[ rel->getName() ] = rel;
	g_Constraints[ rel->getID() ] = rel;
	break;
      }
      case 5: {
	ExtSoftConstraint5* rel = new ExtSoftConstraint5( xrel );
	g_constraints[ rel->getName() ] = rel;
	g_Constraints[ rel->getID() ] = rel;
	break;
      }
      case 6: {
	ExtSoftConstraint6* rel = new ExtSoftConstraint6( xrel );
	g_constraints[ rel->getName() ] = rel;
	g_Constraints[ rel->getID() ] = rel;
	break;
      }
      case 7: {
	ExtSoftConstraint7* rel = new ExtSoftConstraint7( xrel );
	g_constraints[ rel->getName() ] = rel;
	g_Constraints[ rel->getID() ] = rel;
	break;
      }
      case 8: {
	ExtSoftConstraint8* rel = new ExtSoftConstraint8( xrel );
	g_constraints[ rel->getName() ] = rel;
	g_Constraints[ rel->getID() ] = rel;
	break;
      }
      case 9: {
	ExtSoftConstraint9* rel = new ExtSoftConstraint9( xrel );
	g_constraints[ rel->getName() ] = rel;
	g_Constraints[ rel->getID() ] = rel;
	break;
      }
      default: {
	printWarningMessage("Ext soft relation > 9 are not allowed as today");
	break;
      }
      }
#ifdef DBG_IO
	rel->dump();
#endif
      xrel = xrel->next_sibling();
    } while ( xrel); 
  }


  // Parse and create intensional hard constraints
  xml_node<>* xihcons = root->first_node("hard-constraints");
  if( xihcons )
  {
    size = atoi( xihcons->first_attribute("nbHardConstraints")->value() );
    if( size > 0 ) 
    {
      xml_node<>* xhirel  = xihcons->first_node("constraint");
      do
      {
	IntHardConstraint* rel = new IntHardConstraint( xhirel );
	g_constraints[ rel->getName() ] = rel;

#ifdef DBG_IO
	rel->dump();
#endif
	xhirel = xhirel->next_sibling();
      } while ( xhirel );
    }
  }

  // Parse and create constraints
//   xml_node<>* xcons = root->first_node("constraints");
//   size = atoi( xcons->first_attribute("nbConstraints")->value() );
//   if( size > 0 )
//   {
//     xml_node<>* xcon  = xcons->first_node("constraint");
//     do
//     {
//       if (size == 0 ) break;
//       Constraint *con = new Constraint( xcon );
// #ifdef DBG_IO
//       con->dump();
// #endif
//       xcon = xcon->next_sibling();
//     } while ( xcon );
//   }

}

void Parser::postParseInitializations()
{
  // @todo: This bit of code need to be handled somewherelse as 
  //        it breaks the logic of distribuited agents

  // Initialize Agents variables:
  // - boundary variables
  // - local constraints
  // - ...
  for (auto kv : g_agents) 
  {
    kv.second->addBoundaryVariables();
    kv.second->setLocalConstraints();
#ifdef DBG_IO
    kv.second->dump();
#endif
  }

}

void Parser::dumpHelp()
{
  std::cout << "ULISSE Execution Instructions:\n";
  std::cout << "ulisse -i <input_file> [-es <local-search> -lx <external-search> ]\n"
	    << "\n"
	    << " -es options:\n"
	    << "    <protocol>:  SBB | DPOP (external search and communication schema) \n"
	    << " -ls options:\n"
	    << "    <algorithm>: CP_DFS | DFS (internal search engine) \n";
  exit(1);
}
