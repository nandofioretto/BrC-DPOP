#ifndef _ULISSE_PROP_DFS_EXT_SEARCH_HH_
#define _ULISSE_PROP_DFS_EXT_SEARCH_HH_

#include "globals.hh"
#include "external-search-engine.hh"
#include "trailstack.hh"
#include "constraint-store.hh"

class Agent;
class ExtSoftConstraint;

namespace ExtSearch
{

  /**
   * Implements an iterative-DFS with propagation on the boundary variables
   * of the agent.
   */
  class PropDFS : public ExternalSearchEngine
  {
  public:
    /**
     * Default constructor.
     */
    PropDFS( );
    
    /**
     * Default distructor.
     */
    ~PropDFS( );
    
    /**
     * Initializes the agent associated to this search engine
     * and the variables over which perform the search.
     */
    void initialize( Agent& a );
    
    /**
     * Reset search state.
     */
    void reset()
    {
      searchEnded = false;
      currLevel = 0;
    }
    
    /**
     * Finds the next satisfiable solution in the given enumeration 
     * of the solution space.
     */
    bool nextSolution();
    
    /**
     * Finds the assignment to the variables in scope which optimizes
     * the local cost.
     */
    bool bestSolution();
    
    /**
     * Finds all possible satisfiable solutions.
     */
    bool allSolutions();
    
    
    void dump() const;

  private:
    /**
     * @aux An iterative DFS step
     */
    bool searchStep();
        
    /**
     * @aux Performs a labeling on variable associated to currLevel 
     */
    bool labeling();
    
    /**
     * Returns the variable associated to the i-th element of the SearchEngine::scope
     */
    var_int& getVariable( int i ) const
    {
      return *scope[ i ];
    }

    /**
     * Updates the current solution with the current assignment.
     */
    void copySolution();

    
  private:
    // The current depth-level in the search tree exploration. 
    int currLevel;
    
    // Used to backtrack at the appropriate trailstack size.
    // continuation[ i ] contains the trailstack size at the moment
    // when the search for level i started.
    std::vector<int> continuation;
    
    TrailStack trailstack;

    ConstraintStore constraintStore;
  };

  
};

#endif
