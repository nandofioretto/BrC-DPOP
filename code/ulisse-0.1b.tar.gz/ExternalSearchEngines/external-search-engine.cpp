#include "external-search-engine.hh"
#include "search-solution.hh"
#include "agent.hh"
#include "var_int.hh"
#include "constraint.hh"
#include "ext-soft-constraint.hh"
#include "int-hard-constraint.hh"

using namespace std;

//#define DBG

ExternalSearchEngine::ExternalSearchEngine( )
  : propagateBeforeSearch( false )
{
  query = new int[ g_variables.size() ]; // max arity
}


ExternalSearchEngine::~ExternalSearchEngine( )
{ 
  delete[] query;
}


void ExternalSearchEngine::initSearchSettings( )
{
  // Init Scope (boundary variables)
  for( int i=0; i<owner->numofBoundaryVariables(); i++ )
    scope.push_back( &owner->getBoundaryVariable( i ) );

  // Init current and best solutions
  curr_solution.initialize( scope.size() );
  best_solution.initialize( scope.size() );

  // Init maps var scope position to varID
  initMapScope2Vars();
}


// Initializes the Intensional HARD Constraints involved in the search: 
// only constraints involving boundary variables with ancestors
// and exclusively boundary variables
void ExternalSearchEngine::initHardConstraints()
{
  set< IntHardConstraint* > ihc_set;
  set< var_int* > ihv_set;
  for( auto c : owner->getAncestorsConstraints() )
  {
    switch( c->getType() )
    {
    case intHard:
      ihc_set.insert( (IntHardConstraint*)(c) );      
      for( int s=0; s<c->getArity(); s++ )
	ihv_set.insert( &c->getScopeVar( s ) );
      break;
    case extHard:
      // nothing as today...
      break;
    default: 
      break;
    }
  }

  // Populate the set of ancestor variables to be used to propagate constraints
  // before the search starts.
  for( auto v : ihv_set )
  {
    if( v->getOwner() != *owner )
      varsIn_ancestorsHardConstraints.push_back( v );
  }

  // Boundary Variables' only constraints
  for( auto c : owner->getBoundaryConstraints() )
  {
    switch( c->getType() )
    {
    case intHard:
      ihc_set.insert( (IntHardConstraint*)(c) );
      for( int s=0; s<c->getArity(); s++ )
	ihv_set.insert( &c->getScopeVar( s ) );
      break;
    case extHard:
      // nothing as today...
      break;
    default: 
      break;
    }
  }

  for( auto c : ihc_set ) hardConstraints.push_back( c );
  for( auto v : ihv_set ) varsIn_hardConstraints.push_back( v );   
}


// Include the soft constraints invoving exclusively Boundary Variables
void ExternalSearchEngine::initSoftConstraints()
{
  for( auto c : owner->getBoundaryConstraints() )
  {
    switch( c->getType() )
    {
    case intSoft:
      // nothing as today...
      break;
    case extSoft:
      softConstraints.push_back( (ExtSoftConstraint*)(c) );
    default: break;
    }
  }

}


bool ExternalSearchEngine::processSolution( )
{
  // sum up the costs derived from agent local constraints
  cost_type cost = 0;
  size_t nconstr = softConstraints.size();
  for( int i = 0; i < nconstr; i++ )
  {
    cost_type u = getCost( *softConstraints[ i ] );
    if( !isFinite( u ) )
    {
      curr_solution.setCost( u );
      return false;
    }
    cost += u;
  }
  curr_solution.setCost( cost );
  
#ifdef DBG
  curr_solution.dump();
  getchar();
#endif

  return true;
}


cost_type ExternalSearchEngine::getCost( ExtSoftConstraint& Ci )
{
  // project agent scope to current constraint scope
  int sidx;
  for( int a=0; a<Ci.getArity(); a++ )
  {
    // get the scope id from var id referenced from constraint
    sidx = varID2scopePos[ Ci.getScopeVar( a ).getID() ];
    query[ a ] = curr_solution[ sidx ];
  }
  return Ci.getCost( query );
}
