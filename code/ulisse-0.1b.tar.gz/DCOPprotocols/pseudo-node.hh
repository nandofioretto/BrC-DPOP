#ifndef _ULISSE_PSEUDO_NODE_HH_
#define _ULISSE_PSEUDO_NODE_HH_

#include "globals.hh"
#include "agent.hh"

class Agent;
class Constraint;
class PseudoNode;

typedef std::pair<PseudoNode*, std::vector<Constraint*> > causal_node;
typedef std::vector< causal_node > causal_nodes;


class PseudoNode
{

 public:
  /**
   * Default Constructor.
   */
  PseudoNode();

  /**
   * Constructor.
   */
  PseudoNode( Agent& a, causal_node p );

  /**
   * Copy Constructor.
   */
  PseudoNode( const PseudoNode& other );

  /**
   * Default Destructor.
   */
  ~PseudoNode();

  /**
   * Opearators
   */
  PseudoNode& operator= ( const PseudoNode& other );

  /**
   * Opearator==
   */
  bool operator== ( const PseudoNode& other )
  {
    return content->getID() == other.content->getID();
  }

  /**
   * Used by sorting.
   */
  bool operator< ( const PseudoNode& other )
  {
    return content->getID() < other.content->getID();
  }
  
  /**
   * Retunrs the agent associated with this pesudo-node.
   */
  Agent& getContent() const
  {
    return *content;
  }

  /**
   * Check wheter this pseudo-node is the pseudo-tree root
   */
  bool isRoot() const
  {
    return ( parent.first == 0 );
  }
  
  /**
   * Check wheter this pseudo-node is a pseudo-tree leaf
   */
  bool isLeaf() const
  {
    return children.empty();
  }
  
  /**
   * Wheter this node is an ancestor of p.
   */ 
  bool isAncestorOf( PseudoNode& p );

  /**
   * Set the parent of this pseudonode. 
   * @note: p can be NULL
   */
  void setParent( PseudoNode& p, std::vector<Constraint*> C );

  /**
   * Add a children to current pseudo-node.
   */
  void addChild( PseudoNode& c, std::vector<Constraint*> C );

  /**
   * Add an ancestor to current node. It does not include the parent.
   */
  void addAncestor( PseudoNode& a, std::vector<Constraint*> C );

  /**
   * Returns the parent .
   */
  PseudoNode& getParent()
  {
    return *parent.first;
  }
  
  /**
   * Returns the i-th ancestor.
   */
  PseudoNode& getAncestor( int i )
  {
    return *ancestors[ i ].first;
  }
  
  /**
   * Returns the i-th children.
   */
  PseudoNode& getChild(int i)
  {
    return *children[ i ].first;
  }
  
  /**
   * Return the causal node of the parent.
   */
  causal_node& getParentCausal()
  {
    return parent;
  }
  
  /**
   * Returns the i-th causal node ancestor.
   */
  causal_node& getAncestorCausal( int i )
  {
    return ancestors[ i ];
  }
  
  /**
   * Return the i-th causal-node child.
   */
  causal_node& getChildCausal( int i )
  {
    return children[ i ];
  }
  
  /**
   * The number of ancestor.
   */
  size_t numofAncestors() const
  {
    return ancestors.size();
  }
  
  /**
   * The number of children.
   */
  size_t numofChildren() const
  {
    return children.size();
  }
  
  /**
   * Returns the size of the subtree rooted at this node.
   */
  size_t subTreeSize( );

  /**
   * Return the set of nodes in the subtree rooted at this node.
   */
  std::vector< PseudoNode* > getSubTree();

  /// check if required
  void lock() 
  {
    locked = true;
  }
  
  void unlock()
  {
    locked = false;
  }
  
  bool isLocked() const
  {
    return locked;
  }

  void dump() const;

 private:
  // The agent associated to this pseudo-node
  Agent* content;

  // The agent ancestors, excluding its the parent, in the pseudo-tree
  causal_nodes ancestors;

  // The agent children in the pseudo-tree
  causal_nodes children;

  // The agent parent
  causal_node parent;

  // Whether the node is loked by the operation of some other node. 
  bool locked;

};

#endif
