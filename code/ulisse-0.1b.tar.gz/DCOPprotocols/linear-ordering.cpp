#include "linear-ordering.hh"
#include "agent.hh"
#include "pseudo-tree.hh"
#include "pseudo-node.hh"

using namespace std;


LinearOrdering::LinearOrdering() 
{
  // Construct a pseudo-tree
  PseudoTree T; 
  // S is the set of all nodes with no incoming edges
  std::stack<PseudoNode*> S;
  S.push( &T.getRoot() );

  while( !S.empty() ) 
  {
    PseudoNode* v = S.top(); 
    S.pop();
    L.push_back( *v );
    for( int i = 0; i < v->numofChildren(); i++ )
    {
      PseudoNode& u = v->getChild( i );
      // since u is a pseudo-node in a pseudo-tree it has no incoming edges
      // other than the one coming from v. Push u in S
      S.push( &u );
    }
  }
  //std::reverse( L.begin(), L.end() );
 
  // initialize agents position vector
  for( int i=0; i<L.size(); i++ )
  {
    position[ L[ i ].getContent().getID() ] = i;
  }
}


LinearOrdering::~LinearOrdering() 
{
  // nothing
}

vector<Agent*> LinearOrdering::getAncestors( Agent& a )
{
  vector<Agent*> A;
  int pos = getAgentPosition( a );
  for( int i=0; i<pos; i++) {
    Agent* pred = &getNode( i ).getContent();
    A.push_back( pred );
  }
  return A;
}

vector<Agent*> LinearOrdering::getSeparator( Agent& a )
{
  vector<Agent*> A;
  int pos = getAgentPosition( a );
  A.push_back( &getPredecessor( getNode( pos ) ).getContent() );
  A.push_back( &getSuccessor( getNode( pos ) ).getContent() );
  return A;
}

PseudoNode& LinearOrdering::getSuccessor( PseudoNode& n )
{
  int i = position[ n.getContent().getID() ];
  if( i < L.size()-1 ) 
  {
    return L[ i+1 ];
  }
  return n;
}


PseudoNode& LinearOrdering::getPredecessor( PseudoNode& n )
{
  int i = position[ n.getContent().getID() ];
  if( i > 0 ) 
  {
    return L[ i-1 ];
  }
  return n;
}

void LinearOrdering::dump()
{
  for( int i=0; i<L.size(); i++ )
  {
    cout << "#"<<i<<": "<< L[ i ].getContent().getName() << endl;
  }
}
