#include "dpop-protocol.hh"
#include "pseudo-tree.hh"
#include "pseudo-node.hh"
#include "agent.hh"
#include "var_int.hh"
#include "ext-soft-constraint.hh"
#include "int-hard-constraint.hh"
#include "search-solution.hh"
#include "mailbox-system.hh"
#include "prop-rdfs.hh"
#include "scheduler.hh"
#include "external-search-engine.hh"
#include "internal-search-engine.hh"

using namespace std;
using namespace DPOP;

// #define DBG_MSG
// #define DBG_RUN
//#define DBG_COST


DPOPprotocol::DPOPprotocol()
  : isRoot(false), isLeaf(false), numofChildren(0),
    utilTableQuery( 0 )
{
  // nothing
  query = new int[10];
}


DPOPprotocol::~DPOPprotocol()
{
  delete[] utilTableQuery;
  delete[] recvMsgQuery;
  delete[] query;
  for( auto kv : mailbox )
    delete kv.second;
}


void DPOPprotocol::initMailboxes()
{
  mailbox[ "VALUE" ] = new MailboxSystem();
  mailbox[ "VALUE" ]->initialize( *owner );
  mailbox[ "UTIL" ]  = new MailboxSystem();
  mailbox[ "UTIL" ]->initialize( *owner );
}


void DPOPprotocol::initDPOP( Agent& a, const VariableOrdering& O )
{
  // Retrieve the information node leaf or root
  PseudoNode& curr_node = ((PseudoTree&)O).seekNode( a );
  isRoot = curr_node.isRoot();
  numofChildren = curr_node.numofChildren();
  isLeaf = curr_node.isLeaf();

  // Initialize:
  // "softConstrainedAncestorVars" and "ancestorSoftConstraints"
  set<var_int*> aSoftV_set;
  set<var_int*> aHardV_set;
  set<ExtSoftConstraint*> aSoftC_set;
  for( auto c : a.getAncestorsConstraints() )
  {
    if( c->getType() == extSoft or c->getType() == intSoft )
    {
      aSoftC_set.insert( (ExtSoftConstraint*)c );
      for( auto v : c->getScope() )
	if( v->getOwner() != a )
	  aSoftV_set.insert( v );
    }
    else if( c->getType() == intHard or c->getType() == extHard)
    {
      for( auto v : c->getScope() )
	if( v->getOwner() != a )
	  aHardV_set.insert( v );
    }
  }

  for( auto v : aSoftV_set ) {
    softConstrainedAncestorVars.push_back( v );
  }
  for( auto v : aHardV_set ) {
    hardConstrainedAncestorVars.push_back( v );
  }

  ancestorSoftConstraints.resize( softConstrainedAncestorVars.size() );

  for( int i=0; i<softConstrainedAncestorVars.size(); i++ )
  {
    var_int& va = *softConstrainedAncestorVars[ i ];
    for( auto sc : aSoftC_set )
    {
      if( sc->hasInScope( va ) )
	ancestorSoftConstraints[ i ].push_back( sc );
    }
  }

  // 1. include the direct parent and pseudo paent of each boundary
  //     variable in this agent.
  set<var_int*> v_set;
  for( auto c : a.getAncestorsConstraints() )
    for( auto v : c->getScope() )
      if( v->getOwner() != a )
	v_set.insert( v );

  vector< var_int* > var_in_separator(v_set.begin(), v_set.end());

  // 2. For each node nc in the subtree of this node n:
  //    get variables in nc which have constraints with some variables
  //    in a node \in ancestor( n ) but not n itself. 
  v_set.clear();
  std::vector< PseudoNode* > sub_tree = curr_node.getSubTree();

  for( int i=0; i< sub_tree.size(); i++ )
  {
    Agent& na = sub_tree[ i ]->getContent();
    for( auto vb : na.getBoundaryVariables() ) {
      for( auto c : vb->getConstraints() ) {
	for( auto v : c->getScope() )
	{
	  Agent& agent_v = v->getOwner();
	  PseudoNode& node_of_v = ((PseudoTree&)O).seekNode( agent_v );
	  if( node_of_v.isAncestorOf( curr_node ) ) {
	    v_set.insert( v );
	  }
	}
      }
    }
  }

  for( auto v : v_set ) {
    if( find( var_in_separator.begin(), var_in_separator.end(), v ) == 
	var_in_separator.end() )
      var_in_separator.push_back( v );
  }

  // Initialize UTIL Msg
  // if( not g_BCDPOP ) 
  // {
  //   msgUtil.setSource( a );
  //   if( not isRoot ) {
  //     msgUtil.setDestination( curr_node.getParent().getContent() );
  //   }
  
  //   msgUtil.initialize( var_in_separator );
  //   utilTableVars = var_in_separator;
  // }

  // Initialize VALUE Msg
  // @todo

  // Initialize Auxiliary Structures
  size_t max_q_size = var_in_separator.size() + a.numofBoundaryVariables();
  utilTableQuery = new int[ max_q_size ];
  recvMsgQuery   = new int[ max_q_size ]; 

  // Initialize Map var_id <-> query_table_idx (UTQ)
  // it includes the separators variables as well as the boundary variables 
  varID2UtilQueryPos.reserve( max_q_size );
  for( int i=0; i<var_in_separator.size(); i++ )
    varID2UtilQueryPos[ var_in_separator[ i ]->getID() ] = i;
  for( int i=0; i<a.numofBoundaryVariables(); i++ )
    varID2UtilQueryPos[ a.getBoundaryVariable( i ).getID() ] = i+var_in_separator.size();

}


void DPOPprotocol::initialize( Agent& a, const VariableOrdering& O )
{
  owner = &a;

  initMailboxes();
 
  initDPOP( a, O );

}


// The order of variables in msgUtil is:
// 1. variables with direct link to current agent and
// 2. separator variables not in ancestor variables (link coming
//    from children and pseudochildren
void DPOPprotocol::updateUtilMsgCost( Solution& bVarSol, Solution& lVarSol, 
				      vector<UtilMessage*> utilMsgRecv )
{ 
  bool cost_set = false;
  // Include boundary solution in the query to efficently retrieve costs
  // from the incoming messages
  for( int i=0; i<bVarSol.size(); i++ )
    utilTableQuery[ utilTableVars.size() + i ] = bVarSol[ i ];

  for( int u=0; u<msgUtil.utilTableCapacity(); u++ )
  {
    msgUtil.tablePos2Query( utilTableQuery, u ); // got the query
    bool goback = false;
    cost_type cost = 0;

    // Check hard constraints 
    for( int h=0; h<hardConstrainedAncestorVars.size(); h++ )
    {
      var_int& vh = *hardConstrainedAncestorVars[ h ];
      int q_col = varID2UtilQueryPos[ vh.getID() ];
      int d = utilTableQuery[ q_col ];
      if( d < vh.getDomain().lb_pos() ) 
      {
	u += msgUtil.getOffsetLB( u, q_col, vh.getDomain().lb_pos() ) - 1;
	goback = true; break; 
      }
      else if( d > vh.getDomain().ub_pos() ) 
      {
	u += msgUtil.getOffsetUB( u, q_col, vh.getDomain().ub_pos() ) - 1;
	goback = true; break; 
      }
      else if( not vh.getDomain().is_valid( d ) )
      {
	u += msgUtil.getOffsetPos( q_col ) - 1;
	goback = true; break; 
      }
    }
    if(goback) continue;

    // Check Soft Constraints and include Cost of ancestors with boundary variables
    for( int s=0; s<softConstrainedAncestorVars.size(); s++ )
    {
      for( auto c : ancestorSoftConstraints[ s ] )
      {
	cost_type lc = l_getCost( *c );
	if( !isFinite( lc ) ) { goback = true; break; }
	cost += lc;
      }
    }
    if(goback) continue;

    // Join Incoming Messages into cost:
    int k;
    for( int m=0; m<numofChildren; m++ )
    {
      UtilMessage& msg = *utilMsgRecv[ m ];
      for( int i=0; i<msg.numofUtilTableVars(); i++ ) {
	// link each position of variables in the message received to 
	// a position in the utilTableQuery (which includes boundary varialbes
	// at the end).
	k = recvMsgVarPos2UtilQueryPos[ m ][ i ];
	//printf("| position[%d][%d] = %d \n", m, i, k );
	recvMsgQuery[ i ] = utilTableQuery[ k ];
	//printf("| recvMsgQuery[%d]=%d\n", recvMsgQuery[ i ]);
      } 
      cost_type lc = msg[ msg.query2TablePos( recvMsgQuery ) ];

      if( !isFinite( lc ) ) { goback = true; break; }
      cost += lc;
    }
    if(goback) continue;

    // integrate boundary cost
    if( bVarSol.getCost() != NA_VALUE )
      cost += bVarSol.getCost();

    // integrate local cost
    if( lVarSol.getCost() != NA_VALUE )
      cost += lVarSol.getCost();


    // !! Cost 0 or cost satisfied if no soft constraint exists??      
    msgUtil[ u ] = getBestValue( cost, msgUtil[ u ] );
    //msgUtil.incrTableSize();
  }
}


bool DPOPprotocol::allMsgUtilReceived()
{
  if( isLeaf ) return true;
  else if( openMailbox( "UTIL" ).size() < numofChildren )
    return false;
  return true;
}


vector<UtilMessage*> DPOPprotocol::initUtilMessageHandler()
{
  vector<UtilMessage*> utilMsgRecv;
  UtilMessage* msg = ((UtilMessage*)openMailbox( "UTIL" ).read());
  while( msg )
  {
    utilMsgRecv.push_back( msg );
    msg = ((UtilMessage*)openMailbox( "UTIL" ).read());
  }
   
  // Initialize Map datastructures
  recvMsgVarPos2UtilQueryPos.resize( numofChildren );

  for( int m=0; m<numofChildren; m++ )
  {
    UtilMessage& u_msg = *utilMsgRecv[ m ];
    recvMsgVarPos2UtilQueryPos[ m ].resize( u_msg.numofUtilTableVars() );

    for( int i=0; i<u_msg.numofUtilTableVars(); i++ )
    {
      var_int& v = u_msg.getUtilTableVar( i );
      // find variable: 
      int idx = -1;
      for( int j=0; j<utilTableVars.size(); j++) {
	if( *utilTableVars[ j ] == v )
	  {idx = j; break; }
      }

      if( idx == -1 ) {
	for( int j=0; j<owner->numofBoundaryVariables(); j++ ) {   
	  if( v == owner->getBoundaryVariable( j ) )
	    {idx = utilTableVars.size() + j; break; }
	}
      }
      
      assert( idx != -1 );
      
      recvMsgVarPos2UtilQueryPos[ m ][ i ] = idx; 
    }
  }
  return utilMsgRecv;
}


void DPOPprotocol::run()
{
  size_t aID = owner->getID();

  if( allMsgUtilReceived() )
  {
    // Get the Util messages and Init Auxiliary data structures to 
    // join and project util messages
    vector<UtilMessage*> utilMsgRecv = initUtilMessageHandler();
    // Find all feasible assignments
    while( not owner->getExternalSearchEngine().isTerminated() )
    {
      g_stats.setTimer( t_search_boundary, aID );
      bool exists_solB = owner->getExternalSearchEngine().nextSolution();
      g_stats.stopwatch( t_search_boundary, aID );

      if( exists_solB )
      {
	Solution& sol_b = owner->getExternalSearchEngine().getSolution(); 

	g_stats.setTimer( t_search_local, aID );
	bool exists_solL = owner->getInternalSearchEngine().bestSolution();
	g_stats.stopwatch( t_search_local, aID );

	if( exists_solL )
	{
	  Solution& sol_l = owner->getInternalSearchEngine().getBestSolution(); 

	  // Include solution/cost in Util message
	  g_stats.setTimer( t_comm, aID );
	  updateUtilMsgCost( sol_b, sol_l, utilMsgRecv );
	  g_stats.stopwatch( t_comm, aID );
	}
      }
    }

    if( isRoot )
    {
      g_stats.setBestCost( l_chooseBestCost() );
      return;
      // terminate();
    }
    else
    {
      // update statistics
      g_stats.setTimer( t_statistics, aID );
      g_stats.setMsgSize( m_dpop_UTILrows_bp, aID, msgUtil.utilTableCapacity() );
      g_stats.setMsgSize( m_dpop_UTILrows_ap, aID, msgUtil.utilTableSize() );
      g_stats.stopwatch( t_statistics, aID );

      g_stats.setTimer( t_comm, aID );
      openMailbox( "UTIL" ).send( ((Message&)msgUtil) );
      g_stats.stopwatch( t_comm, aID );

      g_scheduler->aQueue.push( msgUtil.getDestination() );

      return;
      // terminate();
    }
  }
  else 
  {
    // insert this agent back in the queue, and wait its turn.
    // g_scheduler->aQueue.push( *owner );
  }

}


void DPOPprotocol::terminate()
{
  // @todo
}


cost_type DPOPprotocol::l_chooseBestCost()
{
  cost_type b = worstValue();
  for( int u=0; u<msgUtil.utilTableCapacity(); u++ )
    b = getBestValue( msgUtil[ u ], b );

  return b;
}


cost_type DPOPprotocol::l_getCost( ExtSoftConstraint& c )
{
  int sidx;
  for( int a=0; a<c.getArity(); a++ )
  {
    sidx = varID2UtilQueryPos[ c.getScopeVar( a ).getID() ];
    query[ a ] = utilTableQuery[ sidx ];
  }
  return c.getCost( query );
}
