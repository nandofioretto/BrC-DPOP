#ifndef _ULISSE_DPOP_PROTOCOL_HH_
#define _ULISSE_DPOP_PROTOCOL_HH_

#include "globals.hh"
#include "protocol.hh"
#include "agent.hh"
#include "dpop-util-message.hh"
//#include "dcop-value-message.hh"

class Agent;
class PseudoNode;
class VariableOrdering;
class Solution;
class ExtSoftConstraint;

namespace DPOP {

  /**
   * Implements the DPOP algorithm.
   */
  class DPOPprotocol : public Protocol
  {
  public:
    
    /**
     * Default constructor.
     */
    DPOPprotocol();
    
    /**
     * Default constructor.
     */
    
    ~DPOPprotocol();
    
    /**
     * Links the Agent governing this protocol and initialize the messages 
     * source and destinations according to the VariableOrdering.
     * Retrieve the set of variables to be transmitted in a Util Message, i.e.
     *
     *     \Cup_{x_i \in Boundary( a )} sep( x_i )
     *  where
     *  sep( x ) = { y | y \in Sncestor( x ) and \exists c( y, z ) s.t. 
     *                   Owner( z ) = Owner( x ) or 
     *                   Onwer( z ) \in Successor( x ) }
     */
    virtual void initialize( Agent& a, const VariableOrdering& O );

    /**
     * Initializes the data structures local to DPOP
     */
    void initDPOP( Agent& a, const VariableOrdering& O );

    /**
     * Initializes the mailboxes of the protocol.
     */
    virtual void initMailboxes( );

    /**
     * Executes the protocol.
     */
    virtual void run();
    
    /**
     * Terminates the protocol.
     */
    virtual void terminate();

        
  private:
 
    // This function will associate costs to each value combination in the
    // Util MSG table.
    // We need to take into account 4 factors:
    // 1. costs derived by this particular choice of the boundary variables 
    //     [which by the whay won't change during the whole function]
    // 2. costs derived by the best solution found in the local variables,
    //    given the boundary variable choice.
    // 3. The cost derived by solving the constraints of the agent's ancestor
    //    with current local variables (both hard and soft)
    // 4  and the costs of the other messages.
    // 
    // The points 1 and 2, are done at this function call, and encoded into the 
    // solution structures.
    // Point 3, will be done below, by (a) checking the value consistency of the
    // hard constraints and (b) integrating the cost of soft constraint. Point (a) is
    // actualy done during the boundary variable search - where the value choices of
    // the boundary variables are propagated to the ancestor's variable domains.
    // In order to do point (b) efficiently we have a map which stores all the
    // constraints to be checked for each boundary variable in ancestors's agent,
    // sharing a constraint with this agent.
    // The last point 
    // to check 
    // In order to do so efficiently, we need to aggregate message 
    void updateUtilMsgCost( Solution& sol_b, Solution& sol_l, 
			    std::vector<UtilMessage*> util_messages_recv );

    /**
     * Returns wheter the UTIL messages from all the agent children have been 
     * received. 
     */
    bool allMsgUtilReceived();

    /**
     * Receive the actual messages and initialize auxiliary data structures
     * for joint and project operations.
     */
    std::vector<UtilMessage*> initUtilMessageHandler();

    /**
     * Auxiliary function to compute cost of a constraint.
     */
    cost_type l_getCost( ExtSoftConstraint& Ci );
        
    cost_type l_chooseBestCost();

  protected:
    // UTIL Message
    UtilMessage msgUtil;

    // The number of msgUtil expected before the search could start.
    size_t numofChildren;
    
    // VALUE Message
    //ValueMessage msgValue;
    
    // true if it is the head of the linear ordering
    bool isRoot;

    // true if it is the tail of the linear ordering
    bool isLeaf;

    // A (temporary) array used to efficiently retrieve costs of 
    // Binary soft Constraints.
    int* query;

    // An array which is used to retrieve values from the util Table 
    int* utilTableQuery; // table positions (dom indexes)
    int* recvMsgQuery;	 // table positions (dom indexes) for recv msgs
    std::vector< var_int* > utilTableVars;
    // Map
    std::unordered_map<int,int> varID2UtilQueryPos; // it includes the boundary vars.

    // Auxiliary Map for Efficient Join and Projection operations
    std::vector< std::vector<int> > recvMsgVarPos2UtilQueryPos;

    // ancestorSoftConstraints[ j ] containst the list of soft constraints
    // which involves the variable "softConstrainedAncestorVars[ j ]" 
    // to be checked during cost computation in the Util Message update phase.
    std::vector< std::vector<ExtSoftConstraint*> > ancestorSoftConstraints;

    // The variables of some ancestor agent having a direct link of 
    // type soft constraint with some variable of the agent running 
    // this protocol.  
    std::vector< var_int* > softConstrainedAncestorVars;
    std::vector< var_int* > hardConstrainedAncestorVars;

  };
  
};

#endif
