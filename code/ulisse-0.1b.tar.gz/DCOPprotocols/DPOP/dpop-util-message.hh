#ifndef _ULISSE_DPOP_UTIL_MESSAGE_HH_
#define _ULISSE_DPOP_UTIL_MESSAGE_HH_

#include "globals.hh"
#include "message.hh"

class Solution;

namespace DPOP {
  
  class UtilMessage : public Message
  {
  public:
    /**
     * Default Constructor
     */
    UtilMessage();
    
    /**
     * Copy Constructor
     */
    UtilMessage( const UtilMessage& other );
    
    /**
     * Default Destructor
     */
    ~UtilMessage();
    
    /*
     * Operation= on curr_state
     */
    UtilMessage& operator=( const UtilMessage& other );

    /**
     * The message type.
     */
    virtual std::string getType() const
    {
      return "UTIL";
    }

    /**
     * Reset message content (no touch header).
     */
    virtual void reset();

    /**
     * Prints Util message on screen.
     */
    virtual void dump();

    /**
     * Initialize the UTIL message by allocating the UTIL tables
     * based on the separator variables.
     */
    void initialize( std::vector<var_int*> separator );


    /**
     * Set the cost related to the 'table_pos' position in the Value Table
     * to sol_cost 
     */
    void include( size_t table_pos, cost_type sol_cost );

    /*
     * Operations on curr_state
     */
    cost_type operator[] (size_t pos) const
    {
      return utilTable[ pos ];
    }
    
    cost_type& operator[] (size_t pos)
    {
      return utilTable[ pos ];
    }

    size_t numofUtilTableVars() 
    {
      return utilTableVars.size();
    }

    var_int& getUtilTableVar( int pos ) 
    {
      return *utilTableVars[ pos ];
    }

    // count only active
    size_t utilTableSize()
    {
      size_t count = 0;
      for( int i=0; i<utilTable.size(); i++ )
	count += isFinite( utilTable[ i ] ); 
      return count;
    }

    void incrTableSize( int incr=1 )
    {
      _utilTableSize+=incr;
    }

    size_t utilTableCapacity() 
    {
      return utilTable.size();
    }
    
      
    // }

    // it is assumed that query is of correct size.
    // @note: IMPORTANT:
    // query does not represent the element of the domain
    // but the position of the element in the domain 
    // Complexity: O(k) - wiht k = number of variables in table
    void tablePos2Query( int* query, size_t pos )
    {
      for( int i=0; i<utilTableVars.size(); i++ )
      {
	query[ i ] = (int)( pos / domAuxRetrival[ i ] ) %
	  domAuxSize[ i ];
      }
    }

    // it is assumed that query is of correct size
    // @note: IMPORTANT:
    // query does not represent the element of the domain
    // but the position of the element in the domain 
    // Complexity: O(k) - wiht k = number of variables in table
    size_t query2TablePos( int* query )
    {
      size_t pos = 0;
      for( int i=0; i<utilTableVars.size(); i++ )
      {
	pos += (query[ i ] * domAuxRetrival[ i ]);
      }
      return pos;
    }

    // it is assumed that query is of correct size
    // @note: IMPORTANT:
    // query does not represent the element of the domain
    // but the position of the element in the domain 
    // Complexity: O(k) - wiht k = number of variables in table
    size_t partialQuery2TablePos( int* query, int size )
    {
      size_t pos = 0;
      for( int i=0; i<size; i++ )
      {
	pos += (query[ i ] * domAuxRetrival[ i ]);
      }
      return pos;
    }

    // Returns the positions to Jump to get to the next i-th 
    // value in the utilTable (at position i)
    size_t getOffsetPos( size_t col )
    {
      return domAuxRetrival[ col ];
    }

    size_t getOffsetLB( size_t curr_pos, size_t col, size_t dom_lb_pos )
    {
      return (domAuxRetrival[ col ] * dom_lb_pos) 
	- ( curr_pos % domAuxSize[ col ] );
    }

    size_t getOffsetUB( size_t curr_pos, size_t col, size_t dom_ub_pos )
    {
      size_t curr_dom_pos = curr_pos % domAuxSize[ col ];
      return( (domAuxSize[ col ] * domAuxRetrival[ col ])
	      - (domAuxRetrival[ col ] * curr_dom_pos) );
    }
    

  private:
    // The variables associated to each row of the table (the variables
    // in the separator set of current agent).
 
    // IMPORTANT ancestor variables need to be oreder first.
    std::vector< var_int* > utilTableVars;
    
    // domAuxRetrival[ i ] = \sum_j={i+1}^n D[ j ]
    // where:
    //  n = number of variables in utilTableVars
    //  D[ j ] = the size of the j-th variable's domain      
    std::vector< double > domAuxRetrival;
    std::vector< int > domAuxSize;

    // The table containing the costs for every value combination of variables
    // in the separator set, following the order of 'utilTableVars'.
    std::vector< cost_type > utilTable;

    // The indexes of 'utilTable' that are actually filled --- no constraint
    // violation.
    std::vector< size_t > _utilTablePos;

    // The actual size of the UtilTable (counts only table positions which 
    // have finite cost and satisfy all hard constraints.
    size_t _utilTableSize;
  };
  
};
#endif
