#include "dpop-value-message.hh"
#include "search-solution.hh"
#include "agent.hh"

using namespace DPOP;
using namespace std;


ValueMessage::ValueMessage( )
  : cost_thisAgent( 0 ), cost_otherAgents( 0 ), best_cost( 0 ), bound( 0 )
{
  //state.resize( g_variables.size(), NA_VALUE );
  state_size = g_variables.size();
  state = new int[ g_variables.size() ];
  for(int i=0; i<state_size; i++) { 
    state[i]==NA_VALUE;
  }
}


ValueMessage::~ValueMessage()
{
  delete[] state;
}


ValueMessage::ValueMessage( const ValueMessage& other )
{
  src = other.src;
  dest = other.dest;
  state = other.state;
  cost = other.cost;
}

ValueMessage& ValueMessage::operator=( const ValueMessage& other )
{
  if( this != &other )
  { 
    // Do not change source and destination
    state = other.state;
    cost = other.cost;
  }
  return *this;
}

void ValueMessage::reset()
{
  cost = worstValue( );
}


void ValueMessage::include( const ValueMessage& other )
{
  cost = 0;
  state = other.getState();
}


void ValueMessage::dump()
{
  cout << "Message Value content:\n";
  cout << " curr state: ";
  for(int i=0;i<state_size; i++) cout << state[i] << ", ";
  cout <<"\n curr cost: [" << cost 
       << "] : "  << endl;

