#include "dpop-util-message.hh"
#include "var_int.hh"
#include "search-domain.hh"
#include "agent.hh"

using namespace std;
using namespace DPOP;

UtilMessage::UtilMessage()
{
  
}


UtilMessage::UtilMessage( const UtilMessage& other )
{
  cout << "This not be called!\n";
  printWarningMessage( "UtilMessage()=" );
}


UtilMessage::~UtilMessage()
{

}


UtilMessage& UtilMessage::operator=( const UtilMessage& other )
{
  cout << "This not be called!\n";
  printWarningMessage( "UtilMessage::operator=" );
  return *this;
}


void UtilMessage::reset()
{
  // nothing
}


void UtilMessage::dump()
{
  cout << "DPOP Util Message\n";
  if( utilTableVars.empty() ) { cout <<"empty\n"; return;}
  cout << "| Sender: " << getSource().getName() <<endl;
  cout << "| Dest: " <<   getDestination().getName() <<endl;
  cout << "| Header variables: ";
  for( auto v : utilTableVars )
    cout << v->getName() << " ";
  cout << endl;

  for(int i=0; i<domAuxSize.size(); i++ )
    cout << "| domAuxsize["<<i<<"]: "<<domAuxSize[ i ] << endl;
  for(int i=0; i<domAuxRetrival.size(); i++ )
    cout << "| domAuxRetrival["<<i<<"]: "<<domAuxRetrival[ i ] << endl; 

  int* query = new int[ utilTableVars.size() ];

  for(int i=0; i<utilTable.size(); i++)
  {
    tablePos2Query( query, i );
    cout << "| ";
    for(int j=0; j<utilTableVars.size(); j++ )
      cout << query[ j ] << " ";
    cout << ": " << utilTable[ i ] << endl;
  }
  cout << "+--\n";
  delete query;
}


void UtilMessage::initialize( vector< var_int* > ancestors )
{
  utilTableVars = ancestors;
  
  size_t capacity = 1;
  domAuxRetrival.resize( ancestors.size(), 1 );
  domAuxSize.resize( ancestors.size(), 0 );
  
  if( ancestors.size() > 0 )
  for( int i=0; i<ancestors.size(); i++ )
  {
    domAuxSize[ i ] = ancestors[ i ]->getDomain().size();
    capacity *= domAuxSize[ i ];

    for( int ii=i+1; ii<ancestors.size(); ii++ ) {
      domAuxRetrival[ i ] *= ancestors[ ii ]->getDomain().size();
    }
  }
  
  utilTable.resize( capacity, worstValue() );
  _utilTablePos.resize( capacity );
  _utilTableSize = 0; 
}


void UtilMessage::include( size_t table_pos, cost_type sol_cost )
{
  // update only if cost is finite 
  if ( isNotNA( sol_cost ) and isFinite( sol_cost ) ) 
  {
    utilTable[ table_pos ] = sol_cost;
  }
}
