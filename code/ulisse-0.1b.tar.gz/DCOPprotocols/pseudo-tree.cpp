#include "pseudo-tree.hh"
#include "pseudo-node.hh"
#include "agent.hh"
#include "constraint.hh"
#include "var_int.hh"

using namespace std;
#define ORDER_CONSTR
//#define ORDER_AID

/// auxiliary functions
bool orderAgentNeighboursAsc (Agent* LHS, Agent* RHS);
bool orderAgentNeighboursDesc (Agent* LHS, Agent* RHS);
bool orderPairSecAsc( std::pair<Agent*,int> LHS, std::pair<Agent*,int> RHS);


PseudoTree::PseudoTree( )
{
  // Create successors of each Agent by populating 'g_agent_neighbours'
  map< string, Agent* >::iterator a_it = g_agents.begin();
  for( ; a_it != g_agents.end(); ++a_it )
  {
    l_makeSuccessors( *a_it->second );
    markedAgents[ a_it->second ] = -1;
  }
  
  // Order Agents via decreasing number of neighbours for the dfs search
  std::vector<std::pair<Agent*,int> > dfs_ordering;
  std::vector<std::pair<Agent*,int> > d_it;
#if defined ORDER_CONSTR
  // Order each agent successor via decreasing number of constraints
  map<Agent*,std::vector<Agent*> >::iterator n_it = 
    g_agent_neighbours.begin();
  for( ; n_it != g_agent_neighbours.end(); ++n_it )
    std::sort ( n_it->second.begin(), n_it->second.end(), orderAgentNeighboursAsc );

  n_it = g_agent_neighbours.begin();
  for( ; n_it != g_agent_neighbours.end(); ++n_it )
  {
    dfs_ordering.push_back( make_pair( n_it->first, n_it->second.size() ) );
  }
  std::sort( dfs_ordering.begin(), dfs_ordering.end(), orderPairSecAsc );
#elif defined ORDER_AID
  for( auto& kv : g_agents )
    dfs_ordering.push_back( make_pair( kv.second, kv.second->getID() ) );
#endif

  // call the DFS exploration for the PseudoTree construction
  for( int i = 0; i < dfs_ordering.size(); i++ )
  {
    if ( markedAgents[ dfs_ordering[ i ].first ] == -1 )
    {
      causal_node parent; parent.first = 0;
      PseudoNode* curr_node = new PseudoNode(*(dfs_ordering[ i ].first), parent );
      l_dfsStep( curr_node );
    }
  }
}


PseudoTree::~PseudoTree()
{ 
  for( auto n : nodes )
    delete n;
}


vector<Agent*> PseudoTree::getAncestors( Agent & a )
{
  vector< Agent* > res; 

  PseudoNode* p = &seekNode( a );
  while( not p->isRoot() )
  {
    p = &p->getParent();
    res.push_back( &p->getContent() );
  }
  return res;
}

vector<Agent*> PseudoTree::getSeparator( Agent& a )
{
  // @todo
  cout << "PseudoTree::getSeparator() - Warning: this Fuction is not implemented!\n";
  vector<Agent*> A;
  return A;
}

PseudoNode& PseudoTree::seekNode( Agent& a )
{
  for( int i=0; i<nodes.size(); i++)
  {
    if( nodes[ i ]->getContent() == a ) 
      return *nodes[ i ];
  }
  // should never happen that node is not found.
  cout << "Error in PseudoTree::seekNode - abort\n";
  exit(-1);
}


PseudoNode& PseudoTree::getRoot() const
{
  assert( !nodes.empty() );
  return *nodes[ 0 ]; 
}


void PseudoTree::l_dfsStep( PseudoNode* curr_node )
{
  static int lev = 0;
  Agent& curr_agent = curr_node->getContent();

  if( markedAgents[ &curr_agent ] > -1 ) return; 
  
  markedAgents[ &curr_agent ] = lev;
  
  if ( curr_node ) {
    nodes.push_back( curr_node );
    unlockedNodes[ curr_node ] = false;
  }

  // Recur
  int numof_neighbours = g_agent_neighbours[ &curr_agent ].size();
  for( int i = 0; i < numof_neighbours; i++ )
  {
    Agent &succ_agent = *g_agent_neighbours[ &curr_agent ][ i ];
    // check if successor was already descendant of some other node
    if( markedAgents[ &succ_agent ] == -1 )
    {
      // Add parent + parent-child constraints
      std::vector<Constraint*> dep = l_getLinks( curr_agent, succ_agent );
      causal_node parent( curr_node, dep );
      PseudoNode *succ_node = new PseudoNode( succ_agent, parent );
 
      succ_node->setParent( *curr_node, dep );
      curr_node->addChild( *succ_node, dep );
            
      lev++;
      l_dfsStep( succ_node );
      lev--;
    }
    else if ( markedAgents[ &succ_agent ] < lev-1 )
    {
      std::vector<Constraint*> dep = l_getLinks( curr_agent, succ_agent );
      curr_node->addAncestor( seekNode( succ_agent ), dep );
    }
  }
}


std::vector<Constraint* > PseudoTree::l_getLinks( Agent& Ai, Agent& Aj )
{
  std::vector<Constraint* > cons;

  for( int i = 0; i < Ai.numofBoundaryVariables(); i++ )
  {
    var_int& vi = Ai.getLocalVariable( i );
    // scan all constraint involving vi
    for( int c = 0; c < vi.numofConstraints(); c++ )
    {
      Constraint& Ci = vi.getConstraint( c );

      for( int j = 0; j < Aj.numofBoundaryVariables(); j++ )
      {
	var_int& vj = Aj.getLocalVariable( j );
	if( Ci.hasInScope( vi ) && Ci.hasInScope( vj ) )
	  if( find (cons.begin(), cons.end(), &Ci ) == cons.end() )
	    cons.push_back( &Ci );
      }
    }
  }
  return cons;
}


void PseudoTree::l_makeSuccessors( Agent& A )
{  
  std::vector<Agent*> neighbours;
  std::vector<Agent*>::iterator n_it;

  // get all constraints involving the boundary variables of A
  for( int i=0; i<A.numofBoundaryVariables(); i++ )
  {
    var_int& A_vi = A.getBoundaryVariable( i );

    for( int c=0; c<A_vi.numofConstraints(); c++)
    {
      Constraint& c_in_A = A_vi.getConstraint( c );

      // Build the neighbours of agent A scanning the local constraint 
      // involving A's boundary variables
      for( int a=0; a<c_in_A.getArity(); a++ )
      {
	var_int& scope_c = c_in_A.getScopeVar( a );
	Agent& Ac = scope_c.getOwner();
	if( Ac != A )
	{
	  if( find( neighbours.begin(), neighbours.end(), &Ac ) 
	      == neighbours.end() ) // not found
	  {
	    neighbours.push_back( &Ac );
	  }
	}

      }//- arity of c_in_A
    }//- all c_in_A for boundary variables of A
  }//- all boundary variables of A
  
  g_agent_neighbours[ &A ] = neighbours;
}


vector<PseudoNode*> PseudoTree::getLeaves()
{
  vector<PseudoNode*> res;
  for( auto n : nodes )
  {
    if ( n->isLeaf() )
      res.push_back( n );
  }
  return res;
}


vector<PseudoNode*> PseudoTree::get_ready_nodes()
{
  vector<PseudoNode*> res;
  std::map<PseudoNode*, bool >::const_iterator it = unlockedNodes.begin();
  
  for( ; it != unlockedNodes.end(); ++it )
  {
    if ( it->second ) continue;
    
    // check if all the children are unlocked
    bool can_unlock = true;
    for( int i=0; i < it->first->numofChildren(); i++ )
    {
      PseudoNode& c = it->first->getChild( i );
      if( ! unlockedNodes[ &c ] ) {
	can_unlock = false; break;
      }
    }
    if( can_unlock ) res.push_back( it->first );
  }
  return res;
}


void PseudoTree::dump()
{
  PseudoNode& n = getRoot();
  queue< pair< PseudoNode*, int> > Q;
  Q.push( make_pair( &n, 0 ) );
  int lev = 0;
  while( not Q.empty() )
  {
    pair< PseudoNode*, int> n = Q.front(); 
    cout << "Lev " << n.second << ": ";
    n.first->dump();
    lev = n.second+1;
    Q.pop();
    for( int i=0; i<n.first->numofChildren(); i++ )
    {
      Q.push( make_pair( &n.first->getChild( i ), lev ) );
    }
  }
}


/// Auxiliary ordering functions used within std::sort(.)
bool orderAgentNeighboursAsc (Agent* LHS, Agent* RHS) 
{
  return ( g_agent_neighbours[ LHS ].size() > 
	   g_agent_neighbours[ RHS ].size() ); 
}//-

bool orderAgentNeighboursDesc (Agent* LHS, Agent* RHS) 
{
  return ( g_agent_neighbours[ LHS ].size() <
	   g_agent_neighbours[ RHS ].size() ); 
}//-

bool orderAgentIDAsc (Agent* LHS, Agent* RHS) 
{
  return ( LHS->getID() > RHS->getID() ); 
}//-

bool orderAgentIDDesc (Agent* LHS, Agent* RHS) 
{
  return ( LHS->getID() < RHS->getID() ); 
}//-

bool orderPairSecAsc( std::pair<Agent*,int> LHS, std::pair<Agent*,int> RHS)
{
  return ( LHS.second > RHS.second );
}//-
