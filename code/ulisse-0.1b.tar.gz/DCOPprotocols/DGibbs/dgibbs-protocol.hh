#ifndef _ULISSE_DGIBBS_PROTOCOL_HH_
#define _ULISSE_DGIBBS_PROTOCOL_HH_

#include "globals.hh"
#include "protocol.hh"
#include "cpa-message.hh"
#include "bt-message.hh"
#include "agent.hh"

class Agent;
class PseudoNode;
class VariableOrdering;

namespace DGibbs {

  /**
   * Implements the Decentralized Gibbs coordinating 
   * each agent in a linear order.
   */
  class DGibbsProtocol : public Protocol
  {
  public:
    
    /**
     * Default constructor.
     */
    DGibbsProtocol();
    
    /**
     * Default constructor.
     */
    
    ~DGibbsProtocol();
    
    /**
     * Links the Agent governing this protocol and initialize the messages 
     * source and destinations according to the VariableOrdering.
     */
    virtual void initialize( Agent& a, const VariableOrdering& O );
    
    /**
     * Executes the protocol.
     */
    virtual void run();
    
    /**
     * Terminates the protocol.
     */
    virtual void terminate();
        
  private:
    
    /**
     * Auxiliary function to compute cost of a constraint.
     */
    cost_type l_getCost( const Constraint& Ci );
        
  private:
    cost_type tuple[ 2 ];

    /// CPA Message
    CPAMessage messageCPA;
    
    /// Backtrack Message
    BTMessage messageBT;
    
    // true if it is the head of the linear ordering
    bool isRoot;

    // true if it is the tail of the linear ordering
    bool isLeaf;

    // true if the current agent has the CPA token
    bool hasToken;
  };
  
};

#endif
