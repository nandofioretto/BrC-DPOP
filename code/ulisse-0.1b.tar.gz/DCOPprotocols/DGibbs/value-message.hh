#ifndef _ULISSE_DGIBBS_VALUE_MESSAGE_HH_
#define _ULISSE_DGIBBS_VALUE_MESSAGE_HH_

#include "globals.hh"
#include "message.hh"

class Solution;

namespace DGibbs {
  
  class ValueMessage : public Message
  {
  public:
    /**
     * Default Constructor
     */
    ValueMessage();
    
    /**
     * Copy Constructor
     */
    ValueMessage( const ValueMessage& other );
    
    /**
     * Default Destructor
     */
    ~ValueMessage();
    
    /*
     * Operation= on curr_state
     */
    ValueMessage& operator=( const ValueMessage& other );

    /**
     * The message type.
     */
    virtual std::string getType() const
    {
      return "Value";
    }

    /**
     * Reset message content (no touch header).
     */
    virtual void reset();

    /**
     * Prints Value message on screen.
     */
    virtual void dump();

    /*
     * Operations on curr_state
     */
    int  operator[] (size_t pos) const
    {
      return state[ pos ];
    }
    
    int& operator[] (size_t pos)
    {
      return state[ pos ];
    }
    
    /**
     * Aggregates a search solution to the current state
     */
    void include( const Solution& sol, int* solPos2statePos );
    
    /**
     * Aggregates a Value message with current one. Updates the current state 
     * with the one held by the 'other' Value message and the 'otherAgents' cost 
     * with total cost of the 'other' Value message.
     */
    void include( const ValueMessage& other );
    
    /**
     * The state size
     */
    size_t size() const
    {
      return state_size;//state.size();
    }
    
    /**
     * Sets the cost associated to the solution reported by the agent holding the 
     * Value message to c.
     */
    void setAgentCost( double c )
    {
      cost_thisAgent = c;
    }
    
    /**
     * Increases the cost associated to the solution reported by the agent holding 
     * the Value message by c.
     */
    void incrAgentCost( double c )
    {
      cost_thisAgent += c;
    }
    
    /**
     * Decreases the cost associated to the solution reported by the agent holding 
     * the Value message by c.
     */
    void decrAgentCost( double c )
    {
      cost_thisAgent -= c;
    }
    
    /**
     * Returns the cost.
     */
    double getCost( ) const
    {
      return cost_thisAgent + cost_otherAgents;
    }
    
    /**
     * Return the curren state.
     */
    int* getState() const
    {
      return state;
    }

    /**
     * Returns the cost associated to the best solution.
     */
    double getBestCost() const
    {
      return best_cost;
    }
    
    /**
     * Save current state and cost into best state and cost
     * if they are better.
     */
    void updateIfBetter( );

    /**
     * Return the state associated to the best solution
     * found so far.
     */
    int* getBestState()
    {
      return best_state;
    }
    
    /**
     * Sets the bound
     */
    void setBound( double b )
    {
      bound = b;
    }
    
    /**
     * Returns the bound.
     */
    double getBound( ) const
    {
      return bound;
    }
    

  private:
    /// The current state of the system holding values for each variable
    /// @note: it is unecessary to fill the whole state each time 
    /// (unless we use an efficient handling---like with a unique message
    /// and a pointer to the content). Indeed we only need to know about
    /// the current agent varialbe values and the values of the variables
    /// in the scope of a constraint with the boundary variables of this 
    /// agent.
    // std::vector<int> state;
    int* state;
    int state_size;

    cost_type bestDelta;

    cost_type Delta;

    size_t bestIteration;
 
    //std::vector<int> best_state;
    int* best_state; 
    double best_cost;
    
    /// The list of constraints that need to be propagated due to a change
    /// in the boundary variables of the sender Agent
    std::vector< std::string > constr_store;
  };
  
};
#endif
