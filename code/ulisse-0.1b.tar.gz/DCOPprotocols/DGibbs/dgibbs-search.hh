#ifndef _ULISSE_DGIBBS_SEARCH_HH_
#define _ULISSE_DGIBBS_SEARCH_HH_

#include "globals.hh"
#include "search-engine.hh"
#include "pseudo-tree.hh"

class Agent;
class Solution;
class PseudoNode;
class PseudoTree;

namespace DGibbs {

  /**
   * The Distribuited Gibbs search engine.
   * Implements the Distribuited Gibbs search engine, which
   * act on the boundary variables of each agent.
   */
  class DGibbsSerch : public SearchEngine
  {
  public:
    /**
     * Default constructor.
     */
    DGibbsSearch( );
    
    /**
     * Default distructor.
     */
    ~DGibbsSearch( );
    
    /**
     * Initializes the agent associated to this search engine, 
     * the variables over which perform the search and 
     * Create a variable ordering schema
     */
    virtual void initialize( Agent& a );

    /**
     * Reset search state.
     */
    virtual void reset()
    {
      searchEnded = false;
    }
    
    /**
     * Finds the next satisfiable solution in the given enumeration 
     * of the solution space.
     */
    virtual bool nextSolution();
    
    /**
     * Finds the assignment to the variables in scope which optimizes
     * the local cost.
     */
    virtual bool bestSolution();
    
    /**
     * Finds all possible satisfiable solutions.
     */
    virtual bool allSolutions();
    
    /**
     * Returns the last found. 
     */
    virtual Solution& getSolution()
    {
      return curr_solution;
    }
    
    /**
     * Returns the best found. 
     */
    virtual Solution& getBestSolution()
    {
      return best_solution;
    }
    
    virtual void dump() const;

    
  private:
    cost_type tuple[ 2 ];

    // The domains associated to each Variable
    std::vector< std::vector<int> > stateDomains;

    // The value choices for the state in the previous iteration.
    Solution prev_solution;

    // Agent's boundary variables context - values
    std::vector<int> context;

    std::unordered_map<unsigned int, unsigned int> 
    neigbourVarPos2contextPos;

    // The set of agent's neighbours
    std::vector<var_int*> neigbhoursVars;
    
    // The number of iteration that this agent has sampled
    size_t currIteration;

    // The most recent iteration that a better solution was found
    size_t bestIteration;

    // The difference in solution quality between the current solution
    // and the best solution found in the previous iteration.
    cost_type costDelta;

    // The differnece in solution quality between the best solution found in 
    // the current iteration and the best solution found so far up to 
    // the previous iteration.
    cost_type bestCostDelta;

    // The ancestors variables connected with local variables used by this search.
    std::vector<var_int*> ancestorsVars; // ??
  };

  
};

#endif
