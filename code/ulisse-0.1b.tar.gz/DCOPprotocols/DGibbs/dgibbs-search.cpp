#include "globals.hh"
#include "dgibbs-search.hh"

using namespace DGibbs;

DGibbsSerch::DGibbsSerch()
{
  // @todo
}

DGibbsSerch::~DGibbsSerch()
{
  // todo
}

void DGibbsSerch::initializes( Agent& a )
{
  // This part must go in the BASE class
  owner = &a;
  for( int i=0; i<a.numofBoundaryVariables(); i++ )
    scope.push_back( &a.getBoundaryVariable( i ) );
  
  // Init current and best solutions
  curr_solution.initialize( scope.size() );
  best_solution.initialize( scope.size() );
  ////////////////////////////////////////

  // Set initial Values:
  prev_solution.initialize( scope.size() );
  
  currIteration = 0;
  bestIteration = 0;
  costDelta = 0;
  bestCostDelta = 0;

  // Retrieve all negibours

  // Populate domains:
  stateDomains.resize( scope.size() );
  for( int k=0; k<scope.size(); k++ )
  {
    vector<int> D( scope[ k ]->getDomain.size() );
    for( int i=0; i< D.size(); i++ )
      D[ i ] = scope[ k ]->getDomain[ i ];
    stateDomains[ k ] = D;
  }

  // Random assignment to all the elements in the variable 
  // domains.

  if( /* this agent is the root */ )
  {
    currIteration++;
  }
}


bool DGibbsSerch::nextSolution()
{
  // 
  for( int i=0; i<scope.size(); i++ )
  {
    // sample based on current context -- i.e. var received
    // in previous state
    sample( i );
  }

  // compute bounds

  // update bounds
  if( isBetter( costDelta, bestCostDelta ) ) // save opt. param as global var.
  {
    bestCostDelta = costDelta;
    best_solution = curr_solution; // @todo! careful here
    bestIteration = currIteration;
  }
  return true;
}


bool DGibbsSerch::bestSolution()
{
  // @not to be done
  return true;
}


bool DGibbsSerch::allSolutions()
{
  // @not to be done
  return true;
}


void DGibbsSerch::dump() const 
{
  cout << "DGibbsSearchEngine" << endl;
}
