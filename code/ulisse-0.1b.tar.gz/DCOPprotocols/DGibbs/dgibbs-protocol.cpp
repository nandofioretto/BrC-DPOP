#include "sbb-protocol.hh"
#include "linear-ordering.hh"
#include "search-solution.hh"
#include "agent.hh"
#include "constraint.hh"
#include "var_int.hh"
#include "relation.hh"
#include "ext-soft-relation.hh"
#include "search-engine.hh"
#include "mailbox-system.hh"

using namespace std;
using namespace SynchBB;

//#define DBG

DGibbsProtocol::DGibbsProtocol()
  : isRoot(false), isLeaf(false)
{
  // nothing
}


DGibbsProtocol::~DGibbsProtocol()
{
  // nothing
}


void DGibbsProtocol::initialize( Agent& a, const VariableOrdering& O )
{
  owner = &a;
  
  int pos   = ((LinearOrdering&)O).getAgentPosition( a );
  // simply set the messages
  PseudoNode& curr_node = ((LinearOrdering&)O).getNode( pos );
  PseudoNode& succ_node = ((LinearOrdering&)O).getSuccessor( curr_node );
  PseudoNode& pred_node = ((LinearOrdering&)O).getPredecessor( curr_node );

  if( curr_node == ((LinearOrdering&)O).getHead() ) { 
    isHead = true; hasToken = true; 
  }
  else if( curr_node == ((LinearOrdering&)O).getTail() ) { 
    isTail = true;
  }

  // initialize message CPA -- sender and receiver
  messageCPA.setSource( curr_node.getContent() );
  if( not isTail ) {
    messageCPA.setDestination( succ_node.getContent() );
  }
  messageCPA.reset();

  // initialize message BT  -- seneder and receiver
  messageBT.setSource( curr_node.getContent() );
  if( not isHead ) {
    messageBT.setDestination( pred_node.getContent() );
  }
  messageBT.reset();
   
}


// This function is now simulated -- otherwise will be run based on the 
// notion of events
void DGibbsProtocol::run()
{
  // Check incoming messages 
  // Type: VALUE - 
  //       1. update msg in agent context
  //       2. Sample()
  //       3. DFS-Prop() best solution.
  //       4a. sends new values into VALUE msg (update their values or 
  //           save msg in their incoming msg queue)
  //       4b. If isLeaf -> send BACKTRACK
  //       5. Add neigbouring agents to queue.
  //       
  // Type: BACKTRACK -
  //       1. IF this agent has received a BACKTRACK msg from each child
  //          -> send BACKTRACK msg to its parent
  //       2. IF root 
  //          -> start new iteration.
  


  while( not owner->getDcopSearchEngine().isTerminated() )
  {
    // Communication Starts
    if( not hasToken )
    {
      g_stats.setTimer( t_comm, aID );
      const Message* recv = owner->openMailbox().read();
      if( not recv ) { continue; }
    
      if( recv->getType() == "CPA" )
      {
	messageCPA.include( (CPAMessage&)*recv );
	hasToken = true;
      }
      if( recv->getType() == "BT" )
      {
      	messageBT.include( (BTMessage&)*recv );
	hasToken = true;
      }
    g_stats.stopwatch( t_comm, aID );
    }
    // Communication Ends

    g_stats.setTimer( t_search_boundary, aID );
    // @note: nextSolution() also compute costs for boundary vars"
    bool exists_solB = owner->getDcopSearchEngine().nextSolution();
    g_stats.stopwatch( t_search_boundary, aID );

    if( exists_solB )
    {
      g_stats.setTimer( t_comm, aID );
      // Save solution and integrate it in the CPA message
      if( owner->getDcopSearchEngine().getScopeSize() > 0 )
      {
	// reset current agent cost -- new assignment has been found.
	messageCPA.setAgentCost( 0 );
	messageCPA.include( owner->getDcopSearchEngine().getSolution(),
			    owner->getDcopSearchEngine().getScope2varID());
		
	// Compute cost with ancestors and add it to the CPA message
	cost_type cost = l_computeAncestorsCost();

	if( isFinite( cost ) )
	  messageCPA.incrAgentCost( cost );
	else {
	  g_stats.stopwatch( t_comm, aID );
	  continue;
	}
      }
      g_stats.stopwatch( t_comm, aID );


      g_stats.setTimer( t_search_local, aID );
      // @note: agentSearch also sum up to all costs
      bool exists_solL = owner->getAgentSearchEngine().bestSolution();
      g_stats.stopwatch( t_search_local, aID );

      if( exists_solL )
      {	
	g_stats.setTimer( t_comm, aID );
	// Include solution/cost with existing cpa-msg
	messageCPA.include( owner->getAgentSearchEngine().getBestSolution(),
			    owner->getAgentSearchEngine().getScope2varID() );
	g_stats.stopwatch( t_comm, aID );

	// SBB: Check bounds
	if( not checkBB() ) continue;
	
	if( not isTail )
	{
	  g_stats.setTimer( t_comm, aID );
	  // send the CPA message to next agent in the chain
	  hasToken = false;
	  owner->openMailbox().send( messageCPA );
	  g_stats.stopwatch( t_comm, aID );

	  // here is simulated -- run the protocol of the next agent.
	  messageCPA.getDestination().runProtocol();
	}
	else
	{
	  g_stats.setTimer( t_comm, aID );
	  messageCPA.updateIfBetter();
	  messageBT.setBestCost( messageCPA.getBestCost() );
	  messageBT.setBestState( messageCPA.getBestState() );
	  g_stats.stopwatch( t_comm, aID );
	}
      }
    }// boundary-var search
  }// while


  if( isHead ) 
  {
    g_stats.setTimer( t_comm, aID );
    messageBT.dump();    // reports best solution
    g_stats.setBestCost( messageBT.getBestCost() );
    g_stats.stopwatch( t_comm, aID );
  }
  else {
    g_stats.setTimer( t_comm, aID );
    hasToken = false;
    owner->openMailbox().send( messageBT ); // returns the TOKEN
    g_stats.stopwatch( t_comm, aID );

  }
}


void DGibbsProtocol::terminate()
{
  // @todo
}


cost_type DGibbsProtocol::l_computeAncestorsCost( )
{
  cost_type cost = 0;
  // cost derived from agent constraints with ancestors
  size_t nconstr = owner->numofAncestorsConstraints();
  for( int i=0; i<nconstr; i++ )
  {
    Constraint& c = owner->getAncestorsConstraint( i );

    if( c.getType() != extSoft ) continue;
  
    cost_type u = l_getCost( c );
    if( not isFinite( u ) ) return u;
    cost += u;
  }
  return cost;
}

cost_type DGibbsProtocol::l_getCost( const Constraint& Ci )
{
  // project agent scope to current constraint scope
  for( int a=0; a<Ci.getArity(); a++ )
  {
    tuple[ a ] = messageCPA[ Ci.refScope( a ).getID() ];
  }
  
  return Ci.getExtSoftRelation().getCost( tuple[0], tuple[1] );
}
