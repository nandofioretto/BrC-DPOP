#ifndef _ULISSE_SYNCHBB_BT_MESSAGE_HH_
#define _ULISSE_SYNCHBB_BT_MESSAGE_HH_

#include "globals.hh"
#include "message.hh"

namespace SynchBB 
{    
  class BTMessage : public Message
  {
  public:
    /**
     * Default Constructors
     */
    BTMessage();
    
    /**
     * Default Constructors
     */
    BTMessage(const BTMessage& other);

    /**
     * Default destructor
     */
    ~BTMessage();
    
    /**
     * Operation= on curr_state
     */
    virtual BTMessage& operator=( const BTMessage& other );

    /**
     * The message type.
     */
    virtual std::string getType() const 
    {
      return "BT";
    }

    /**
     * Reset message content (no touch header).
     */
    virtual void reset();

    /**
     * Prints BT message on screen.
     */
    virtual void dump();


    void include( const BTMessage& other );

    /**
     * Returns the cost associated to the best solution.
     */
    cost_type getBestCost() const
    {
      return best_cost;
    }

    void setBestCost( cost_type c )
    {
      best_cost = c;
    }
    
    /**
     * Return the state associated to the best solution
     * found so far.
     */
    /*std::vector<int>*/
    int* getBestState() const
    {
      return best_state;
    }

    // @todo: just pass ptr and copy it
    void setBestState( int* s )
    {
      best_state = s;
    }

  private:
    int* best_state;
    // std::vector<int> best_state;
    cost_type best_cost;
  };
  
};

#endif
