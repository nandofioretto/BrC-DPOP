#include "bt-message.hh"
#include "agent.hh"
using namespace SynchBB;
using namespace std;

BTMessage::BTMessage() 
  : best_cost( 0 )
{
  // nothing
}

BTMessage::BTMessage(const BTMessage& other) 
{
  src = other.src;
  dest = other.dest;
  best_state = other.best_state;
  best_cost = other.best_cost;
}

BTMessage::~BTMessage()
{
  // nothing
  //delete[] best_state;
}


BTMessage& 
BTMessage::operator=( const BTMessage& other )
{
  if( this != &other )
  {
    best_state = other.best_state;
    best_cost = other.best_cost;
  }
  return *this;
}

void BTMessage::include( const BTMessage& other )
{
  best_state = other.best_state;
  best_cost  = other.best_cost;
}

void BTMessage::reset()
{
  best_cost = worstValue( src->getOptimizationType() );
  //best_state = new int[g_variables.size()];
  //for(int i=0; i<g_variables.size(); i++) best_state[i]=NA_VALUE;
}

void BTMessage::dump()
{
  cout << "Message BT content:\n";
  cout << " best state: ";
  //for( auto i : best_state ) cout << i << ", ";
  if( best_state )
  for(int i=0; i<g_variables.size(); i++) cout << best_state[i] << ", ";
  cout <<"\n best cost: " << best_cost << endl;
}
