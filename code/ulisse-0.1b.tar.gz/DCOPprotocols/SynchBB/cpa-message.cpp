#include "cpa-message.hh"
#include "search-solution.hh"
#include "agent.hh"

using namespace SynchBB;
using namespace std;


CPAMessage::CPAMessage( )
  : cost_thisAgent( 0 ), cost_otherAgents( 0 ), best_cost( 0 ), bound( 0 )
{
  //state.resize( g_variables.size(), NA_VALUE );
  state_size = g_variables.size();
  state = new int[ g_variables.size() ];
  best_state = new int[ g_variables.size() ];
  for(int i=0; i<state_size; i++)
    { state[i]=best_state[i]=NA_VALUE; }

  state_dangling_ptr = state;
  best_state_dangling_ptr = best_state;
}


CPAMessage::~CPAMessage()
{
  // Only pointer copied from msg to msg so cannt delete here
  delete[] state_dangling_ptr;
  delete[] best_state_dangling_ptr;
  // nothing
}


CPAMessage::CPAMessage( const CPAMessage& other )
{
  src = other.src;
  dest = other.dest;
  state = other.state;
  cost_thisAgent = other.cost_thisAgent;
  cost_otherAgents = other.cost_otherAgents;
  bound = other.bound;
}

CPAMessage& CPAMessage::operator=( const CPAMessage& other )
{
  if( this != &other )
  { 
    // Do not change source and destination
    state = other.state;
    cost_otherAgents = other.cost_otherAgents;
    cost_thisAgent = other.cost_thisAgent;
    best_cost = other.best_cost;
    best_state = other.best_state;
    bound = other.bound;
  }
  return *this;
}

void CPAMessage::reset()
{
  cost_thisAgent = 0;
  cost_otherAgents = 0;
  best_cost = worstValue( src->getOptimizationType() );
  // best_state.assign( g_variables.size(), NA_VALUE );
}


void CPAMessage::include( const Solution& sol, int* solPos2statePos )
{
  if ( isNotNA( sol.getCost() ) and 
       isFinite( sol.getCost() ) ) // update only if cost is finite 
  {
    for( int i=0; i<sol.size(); i++ )
    {
      state[ solPos2statePos[ i ] ] = sol[ i ];
    }
    cost_thisAgent += sol.getCost();
  }
}


void CPAMessage::include( const CPAMessage& other )
{
  cost_thisAgent = 0;
  state = other.getState();
  cost_otherAgents = other.getCost();
  bound = other.bound;
}


void CPAMessage::updateIfBetter( )
{
  if( isBetter( cost_thisAgent + cost_otherAgents, 
		best_cost, src->getOptimizationType() ) )
  {
    memcpy(best_state, state, state_size*sizeof(int));;
    best_cost  = cost_thisAgent + cost_otherAgents;
  }
}


void CPAMessage::dump()
{
  cout << "Message CPA content:\n";
  cout << " curr state: ";
  for(int i=0;i<state_size; i++) cout << state[i] << ", ";
  //for( auto i : state ) cout << i << ", ";
  cout <<"\n curr cost: [" << cost_thisAgent 
       << "] + anc: " << cost_otherAgents << endl;

  cout << " best state: ";
  for(int i=0;i<state_size; i++) cout << best_state[i] << ", ";
  //for( auto i : best_state ) cout << i << ", ";
  cout <<"\n best cost: " << best_cost << endl;
}
