#include "sbb-protocol.hh"
#include "linear-ordering.hh"
#include "search-solution.hh"
#include "agent.hh"
#include "constraint.hh"
#include "var_int.hh"
#include "relation.hh"
#include "ext-soft-constraint.hh"
#include "search-engine.hh"
#include "mailbox-system.hh"
#include "external-search-engine.hh"
#include "internal-search-engine.hh"

using namespace std;
using namespace SynchBB;

//#define DBG

SynchBBProtocol::SynchBBProtocol()
  : isHead(false), isTail(false), hasToken(false)
{
  query = new int[10];
}


SynchBBProtocol::~SynchBBProtocol()
{
  delete[] query;
  for( auto kv : mailbox )
    delete kv.second;
}


void SynchBBProtocol::initMailboxes()
{
  mailbox[ "CPA" ] = new MailboxSystem();
  mailbox[ "CPA" ]->initialize( *owner );
  mailbox[ "BT" ]  = new MailboxSystem();
  mailbox[ "BT" ]->initialize( *owner );
}


void SynchBBProtocol::initialize( Agent& a, const VariableOrdering& O )
{
  owner = &a;
  
  initMailboxes();

  int pos   = ((LinearOrdering&)O).getAgentPosition( a );
  // simply set the messages
  PseudoNode& curr_node = ((LinearOrdering&)O).getNode( pos );
  PseudoNode& succ_node = ((LinearOrdering&)O).getSuccessor( curr_node );
  PseudoNode& pred_node = ((LinearOrdering&)O).getPredecessor( curr_node );

  if( curr_node == ((LinearOrdering&)O).getHead() ) { 
    isHead = true; hasToken = true; 
  }
  else if( curr_node == ((LinearOrdering&)O).getTail() ) { 
    isTail = true;
  }

  // initialize message CPA -- sender and receiver
  messageCPA.setSource( curr_node.getContent() );
  if( not isTail ) {
    messageCPA.setDestination( succ_node.getContent() );
  }
  messageCPA.reset();

  // initialize message BT  -- seneder and receiver
  messageBT.setSource( curr_node.getContent() );
  if( not isHead ) {
    messageBT.setDestination( pred_node.getContent() );
  }
  messageBT.reset();
}


// This function is now simulated -- otherwise will be run based on the 
// notion of events
void SynchBBProtocol::run()
{
  owner->getExternalSearchEngine().reset();
  int aID = owner->getID();
  while( not owner->getExternalSearchEngine().isTerminated() )
  {
    // Each agent waits for a token.
    // At the begin the TOKEN is given to the root agent.
    // If the agent has a token already skip this part and start with search.
#ifdef DBG
    cout << "********************************************************* "
	 << "Agent: " << owner->getName() << endl;
#endif

    // Communication Starts
    if( not hasToken )
    {
      g_stats.setTimer( t_comm, aID );
      const CPAMessage* recvCPA = (CPAMessage*)(openMailbox( "CPA" ).read());
      const BTMessage* recvBT   = (BTMessage*)(openMailbox( "BT" ).read());
      
      if( (not recvCPA) and (not recvBT) ) { continue; }
    
      // Only when a CPA message is received the search is re-started
      // (when a BT message is received the search is simply resumed).
      if( recvCPA )
      {
	// set to 0 current cost and sum cost of other agent in the 
	// ancestor cost.
	messageCPA.include( *recvCPA );
	hasToken = true;
	//owner->getDcopSearchEngine().reset(); // @multi-agent
      }
      if( recvBT )
      {
      	messageBT.include( *recvBT );
	hasToken = true;
      }
      g_stats.stopwatch( t_comm, aID );
    }
    // Communication Ends


    // @note: nextSolution() also compute costs for boundary vars"
    g_stats.setTimer( t_search_boundary, aID );
    bool exists_solB = owner->getExternalSearchEngine().nextSolution();
    g_stats.stopwatch( t_search_boundary, aID );

    if( exists_solB )
    {
      g_stats.setTimer( t_comm, aID );

      // Save solution and integrate it in the CPA message
      if( owner->getExternalSearchEngine().getScopeSize() > 0 )
      {
	// reset current agent cost -- new assignment has been found.
	messageCPA.setAgentCost( 0 );
	messageCPA.include( owner->getExternalSearchEngine().getSolution(),
			    owner->getExternalSearchEngine().getScope2varID());
	
	// Compute cost with ancestors and add it to the CPA message
	cost_type cost = l_computeAncestorsCost();
	
	if( isFinite( cost ) )
	  messageCPA.incrAgentCost( cost );
	else {
	  g_stats.stopwatch( t_comm, aID );
	  continue;
	}
      }
      g_stats.stopwatch( t_comm, aID );


      // @note: agentSearch also sum up to all costs
      g_stats.setTimer( t_search_local, aID );
      bool exists_solL = owner->getInternalSearchEngine().bestSolution();
      g_stats.stopwatch( t_search_local, aID );

      if( exists_solL )
      {	
	// Include solution/cost with existing cpa-msg
	g_stats.setTimer( t_comm, aID );
	messageCPA.include( owner->getInternalSearchEngine().getBestSolution(),
			    owner->getInternalSearchEngine().getScope2varID() );
	g_stats.stopwatch( t_comm, aID );

	// SBB: Check bounds
	if( not checkBB() ) continue;
	
	if( not isTail )
	{
	  // send the CPA message to next agent in the chain
	  g_stats.setTimer( t_comm, aID );
	  hasToken = false;
	  openMailbox( "CPA" ).send( messageCPA );
	  g_stats.stopwatch( t_comm, aID );

	  // here is simulated -- run the protocol of the next agent.
	  messageCPA.getDestination().runProtocol();
	}
	else
	{
	  g_stats.setTimer( t_comm, aID );
	  messageCPA.updateIfBetter();
	  messageBT.setBestCost( messageCPA.getBestCost() );
	  messageBT.setBestState( messageCPA.getBestState() );
	  g_stats.stopwatch( t_comm, aID );
	}
      }
    }// boundary-var search

  }// while


  if( isHead ) 
  {
    g_stats.setTimer( t_comm, aID );
    messageBT.dump();    // reports best solution
    g_stats.setBestCost( messageBT.getBestCost() );
    g_stats.stopwatch( t_comm, aID );
  }
  else {
    g_stats.setTimer( t_comm, aID );
    hasToken = false;
    openMailbox( "BT" ).send( messageBT ); // returns the TOKEN
    g_stats.stopwatch( t_comm, aID );

  }
}


void SynchBBProtocol::terminate()
{
  // @todo
}


cost_type SynchBBProtocol::l_computeAncestorsCost( )
{
  cost_type cost = 0;
  // cost derived from agent constraints with ancestors
  size_t nconstr = owner->numofAncestorsConstraints();
  for( int i=0; i<nconstr; i++ )
  {
    Constraint& c = owner->getAncestorsConstraint( i );

    if( c.getType() != extSoft ) continue;
  
    cost_type u = l_getCost( (ExtSoftConstraint&)(c) );
    if( not isFinite( u ) ) return u;
    cost += u;
  }
  return cost;
}

cost_type SynchBBProtocol::l_getCost( ExtSoftConstraint& Ci )
{
  // project agent scope to current constraint scope
  for( int a=0; a<Ci.getArity(); a++ )
  {
    query[ a ] = messageCPA[ Ci.getScopeVar( a ).getID() ];
  }
  
  return Ci.getCost( query );
}
