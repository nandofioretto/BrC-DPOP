#ifndef _ULISSE_SYNCHBB_PROTOCOL_HH_
#define _ULISSE_SYNCHBB_PROTOCOL_HH_

#include "globals.hh"
#include "protocol.hh"
#include "cpa-message.hh"
#include "bt-message.hh"
#include "agent.hh"

class Agent;
class PseudoNode;
class VariableOrdering;
class ExtSoftConstraint;

namespace SynchBB {

  /**
   * Implements the synchronous branch and bound search coordinating 
   * each agent in a linear order.
   */
  class SynchBBProtocol : public Protocol
  {
  public:
    
    /**
     * Default constructor.
     */
    SynchBBProtocol();
    
    /**
     * Default constructor.
     */
    
    ~SynchBBProtocol();
    
    /**
     * Links the Agent governing this protocol and initialize the messages 
     * source and destinations according to the VariableOrdering.
     */
    virtual void initialize( Agent& a, const VariableOrdering& O );
    
    /**
     * Initializes the mailboxes used by this protocol.
     */
    virtual void initMailboxes();

    /**
     * Executes the protocol.
     */
    virtual void run();
    
    /**
     * Terminates the protocol.
     */
    virtual void terminate();
        
  private:

    /**
     * Check if current solution is improving the current bound.
     */
    bool checkBB()
    {
      return( isBetter( messageCPA.getCost(), messageCPA.getBestCost(), 
			owner->getOptimizationType()) );
    }

    /**
     * Compute the cost of the constraints whose scope are boundary 
     * variables of the agent owner and boundary variables of ancestors 
     * agents.
     */
    cost_type l_computeAncestorsCost();
    
    /**
     * Auxiliary function to compute cost of a constraint.
     */
    cost_type l_getCost( ExtSoftConstraint& Ci );
        
  private:
    int* query;

    /// CPA Message
    CPAMessage messageCPA;
    
    /// Backtrack Message
    BTMessage messageBT;
    
    // true if it is the head of the linear ordering
    bool isHead;

    // true if it is the tail of the linear ordering
    bool isTail;

    // true if the current agent has the CPA token
    bool hasToken;
  };
  
};

#endif
