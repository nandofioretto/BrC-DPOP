#ifndef _ULISSE_SYNCHBB_CPA_MESSAGE_HH_
#define _ULISSE_SYNCHBB_CPA_MESSAGE_HH_

#include "globals.hh"
#include "message.hh"

class Solution;

namespace SynchBB {
  
  class CPAMessage : public Message
  {
  public:
    /**
     * Default Constructor
     */
    CPAMessage();
    
    /**
     * Copy Constructor
     */
    CPAMessage( const CPAMessage& other );
    
    /**
     * Default Destructor
     */
    ~CPAMessage();
    
    /*
     * Operation= on curr_state
     */
    CPAMessage& operator=( const CPAMessage& other );

    /**
     * The message type.
     */
    virtual std::string getType() const
    {
      return "CPA";
    }

    /**
     * Reset message content (no touch header).
     */
    virtual void reset();

    /**
     * Prints CPA message on screen.
     */
    virtual void dump();

    /*
     * Operations on curr_state
     */
    int  operator[] (size_t pos) const
    {
      return state[ pos ];
    }
    
    int& operator[] (size_t pos)
    {
      return state[ pos ];
    }
    
    /**
     * Aggregates a search solution to the current state
     */
    void include( const Solution& sol, int* solPos2statePos );
    
    /**
     * Aggregates a CPA message with current one. Updates the current state 
     * with the one held by the 'other' CPA message and the 'otherAgents' cost 
     * with total cost of the 'other' CPA message.
     */
    void include( const CPAMessage& other );
    
    /**
     * The state size
     */
    size_t size() const
    {
      return state_size;//state.size();
    }
    
    /**
     * Sets the cost associated to the solution reported by the agent holding the 
     * CPA message to c.
     */
    void setAgentCost( double c )
    {
      cost_thisAgent = c;
    }
    
    /**
     * Increases the cost associated to the solution reported by the agent holding 
     * the CPA message by c.
     */
    void incrAgentCost( double c )
    {
      cost_thisAgent += c;
    }
    
    /**
     * Decreases the cost associated to the solution reported by the agent holding 
     * the CPA message by c.
     */
    void decrAgentCost( double c )
    {
      cost_thisAgent -= c;
    }
    
    /**
     * Returns the cost.
     */
    double getCost( ) const
    {
      return cost_thisAgent + cost_otherAgents;
    }
    
    /**
     * Return the curren state.
     */
    int* getState() const
    {
      return state;
    }

    /**
     * Returns the cost associated to the best solution.
     */
    double getBestCost() const
    {
      return best_cost;
    }
    
    /**
     * Save current state and cost into best state and cost
     * if they are better.
     */
    void updateIfBetter( );

    /**
     * Return the state associated to the best solution
     * found so far.
     */
    int* getBestState()
    {
      return best_state;
    }
    
    /**
     * Sets the bound
     */
    void setBound( double b )
    {
      bound = b;
    }
    
    /**
     * Returns the bound.
     */
    double getBound( ) const
    {
      return bound;
    }
    

  private:
    /// The current state of the system holding values for each variable
    /// @note: it is unecessary to fill the whole state each time 
    /// (unless we use an efficient handling---like with a unique message
    /// and a pointer to the content). Indeed we only need to know about
    /// the current agent varialbe values and the values of the variables
    /// in the scope of a constraint with the boundary variables of this 
    /// agent.
    // std::vector<int> state;
    int* state;
    int state_size;

    // the cost of the solution excluding the variables values of current agent.
    // (and therefore the constraints involving those variables and their neigbours).
    double cost_otherAgents;
    // cost of the current agent solution.
    double cost_thisAgent;

    //std::vector<int> best_state;
    int* best_state; 
    double best_cost;
    
    double bound;

    // pointers for 
    int* state_dangling_ptr;
    int* best_state_dangling_ptr;
    
    /// The list of constraints that need to be propagated due to a change
    /// in the boundary variables of the sender Agent
    std::vector< std::string > constr_store;
    
  };
  
};
#endif
