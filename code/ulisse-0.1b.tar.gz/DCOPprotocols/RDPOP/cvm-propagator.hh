#ifndef _ULISSE_CVM_PROPAGATOR_HH_
#define _ULISSE_CVM_PROPAGATOR_HH_

#include "globals.hh"

class var_int;
class IntHardConstraint;
class TrailStack;
class ConstraintStore;

class CVMPropagator
{
public:
  CVMPropagator();
  ~CVMPropagator();

  /* typedef to a function pointer which 
     returns bool and takes in input int. */
  // typedef bool( Propagator::*propagator )( IntHardConstraint& ); 

  typedef bool(*relation2)(int, int);
  typedef bool(*relation3)(int, int, double);


  void initialize(TrailStack* t, ConstraintStore* s);
  bool initCVM( IntHardConstraint &r );

  // propagator select( IntHardConstraint &r );
  bool consistency( var_int& v );
  bool propagate( IntHardConstraint &r );
  bool c_int_EQ( IntHardConstraint &r );
  bool c_int_NE( IntHardConstraint &r );
  bool c_int_LT( IntHardConstraint &r );
  bool c_int_LEQ( IntHardConstraint &r );
  bool c_int_GT( IntHardConstraint &r );
  bool c_int_GEQ( IntHardConstraint &r );
  bool c_int_PlusEQconst( IntHardConstraint &r );
  bool c_int_PlusLEQconst( IntHardConstraint &r );
  bool c_int_PlusGEQconst( IntHardConstraint &r );
  bool c_abs_int_sub_int_gt_int( IntHardConstraint& r );


  bool updateCVM(CVMatrix& CVM, var_int& var_x, var_int& var_y, relation2 rel);
  bool updateCVM( CVMatrix& CVM, var_int& var_x, var_int& var_y, 
		  relation3 rel, double ax, double ay, double c );

private:
  // Link to the trailstack used in search associated to this propagator.
  TrailStack* trailstack;
  // Link to the constraint-store used in the search associated to this
  // propagator 
  ConstraintStore* constraintStore;

};

#endif
