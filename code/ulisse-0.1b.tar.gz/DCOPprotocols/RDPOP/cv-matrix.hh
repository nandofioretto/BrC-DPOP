#ifndef _ULISSE_CONSTRAINT_VALUE_MATRIX_HH_
#define _ULISSE_CONSTRAINT_VALUE_MATRIX_HH_

#include "globals.hh"

typedef std::pair<int,int> interval;

class var_int;

/**
 * Constrained Value Matrix:
 * represent an extensive value representation of a binary constraint
 * and it is used to map values of a variable to values of the other
 * variable in a path of binary constraints.
 * 
 * Details:
 *   vRow, vCol -->
 *     |
 *     v
 *   e.g [2, 3] = 1 means D(vRow)=1 with D(vCol)=3 is active, where 
 *   2, 3 are the *labels* of elements in D and *NOT* values.
 *
 *   In the binary constraint c( X, Y ) we adopt this encoding:
 *     X = vRow, Y = Vrow
 *
 * @note: (efficiency)
 *        CVMs treat constraints as directional (e.g., X<Y).
 */
class CVMatrix
{
public:
  /**
   * Default Constructor.
   */
  CVMatrix();

  /**
   * Default Destructor.
   */
  ~CVMatrix();


  /**
   * Copy Constructor.
   */
  CVMatrix( const CVMatrix& other );

  /**
   * Initializes the constraint Value Matrix
   */
  void initialize( Constraint& c );

  /**
   * Initializes the constraint Value Matrix
   */
  void initialize( size_t v_rowID, size_t v_colID );

  /**
   * Copy other matrix to this one.
   */
  void copy( const CVMatrix& other );

  /**
   * Joins two values constraint Matrices.
   */
  void join( CVMatrix& other );

  /**
   * Joins two values constraint matrices.
   */
  void join( CVMatrix &B, size_t v_from, size_t v_to );
 
  /**
   * same as above.
   */
  CVMatrix& operator *= ( CVMatrix &other);
  

  /**
   * Merges two CVM, having same row and col IDs. 
   * Item [i][j] = 1, if edges[i][j] OR other.edges[i][j]
   *             = 0, otherwise
   */
  void merge( CVMatrix& other );

  /**
   * Returns the set of elements reachable by varId with value val.
   */
  std::vector<int> project( int varId, int val );

  /**
   * Unset element
   */
  void unset( int valRow, int valCol )
  {
    if( checkBounds(valRow, valCol) )
      edges[ valRow ][ valCol ] = false;
  }
  
  /**
   * Set element
   */
  void set( int valRow, int valCol )
  { 
    if( checkBounds( valRow, valCol ) )
      edges[ valRow ][ valCol ] = true;
  }

  /**
   * Set interval associated to valRow element
   */
  void set( int valRow, interval b )
  { 
    for( int i=b.first; i<=b.second; i++ )
      edges[ valRow ][ i ] = true;
  }

  /**
   * Set interval associated to valCol element
   */
  void set( interval b, int valCol )
  {
    for( int i=b.first; i<=b.second; i++ )
      edges[ i ][ valCol ] = true;
  }

  bool isActive( int d1, int d2 )
  {
    return edges[ d1 ][ d2 ];
  }

  int getLB( size_t vID )
  {
    return bounds[ vID ].first;
  }

  int getUB( size_t vID )
  {
    return bounds[ vID ].second;
  }

  /**
   * Copies bounds from variable (check if it is row or col) 
   * and updates elements in the matrix accordingly
   */
  void setBounds( var_int& var );

  void setBounds( size_t rID, interval ri, size_t cID, interval ci )
  {
    bounds[ rID ] = ri;
    bounds[ cID ] = ci;
  }

  /**
   * Set a zero matrix
   */
  void setZero();


  void setOne();

  /**
   * Set the identity matrix - only if n X n 
   */
  void setIdentity();

  /**
   * Set the identity matrix - according to variable vID 
   */
  void setIdentity( size_t vID );

  /**
   * Transpose the matrix - only if n X n 
   */
  void transpose();

  size_t nbRows() const
  {
    return dom_vRow;
  }

  size_t nbCols() const
  {
    return dom_vCol;
  }

  size_t getRowID() const
  {
    return vRowID;
  }

  size_t getColID() const
  {
    return vColID;
  }

  void dump();

private:
  bool checkBounds( int r, int c )
  {
    return( r >= 0 and r < dom_vRow and 
	    c >= 0 and c <= dom_vCol );
  }
  
private:
  // Link to the constraint associated to this constraint value graph. 
  Constraint* constraint;
  size_t vRowID;
  size_t vColID;

  // lower and upper bounds associated to each variable in 'vars'. 
  std::map<size_t,interval> bounds; // positions
 
  // D_v1 x D_v2 edge matrix
  size_t dom_vRow, dom_vCol;  
  bool** edges;  
  bool** tmp;			// aux used in join
};


#endif
