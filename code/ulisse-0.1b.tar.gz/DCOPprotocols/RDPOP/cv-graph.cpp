#include "cv-graph.hh"
#include "globals.hh"

using namespace std;

CVGraph::CVGraph()
{
  // nothing
}


CVGraph::~CVGraph()
{
  // nothing
}


CVGraph::CVGraph( const CVGraph& other )
{
  if( this != &other )
  {
    constraint = other.constraint;
    varBounds = other.varBounds;
    varValBounds = other.varValBounds;
    changed = other.changed;
  }
  return *this;
}


void CVGraph::initialize( Constraint& con )
{
  assert( con.getArity() == 2 );
  constraint = &con;

  // size_D1 = con.getScopeVar( 0 ).getDomain().size();
  // size_D2 = con.getScopeVar( 1 ).getDomain().size();

  // init bounds
  for( int i=0; i <con.getArity(); i++ )
  {
    size_t vid = con.getScopeVar( i ).getID();
    int lb = con.getScopeVar( i ).getDomain().lb_pos();
    int ub = con.getScopeVar( i ).getDomain().ub_pos();
    varBounds[ vid ] = make_pair( lb, ub );
  }

  var_int& v1 = con.getScopeVar( 0 );
  domBound b1 = make_pair( v1.getDomain().lb_pos(),
			   v1.getDomain().ub_pos() );
  size_t v1id = v1.getID();

  var_int& v2 = con.getScopeVar( 0 );
  domBound b2 = make_pair( v2.getDomain().lb_pos(),
			   v2.getDomain().ub_pos() );
  size_t v2id = v2.getID();

  // initialize as all valid
  for( int j=0; j<v1.getDomain().size(); j++ )
  {
    varValBounds[ v1id ].push_back( make_pair( j, b2 ) );
  }

  for( int j=0; j<v2.getDomain().size(); j++ )
  {
    varValBounds[ v2id ].push_back( make_pair( j, b1 ) );
  }
  
}


void getSrcDst( const CVGraph& RHS, size_t& src, size_t& mid, size_t& dst )
{
  size_t rhs_v0_id = RHS.constraint->getScopeVar( 0 );
  size_t rhs_v1_id = RHS.constraint->getScopeVar( 1 );
  size_t lhs_v0_id = constraint->getScopeVar( 0 );
  size_t lhs_v1_id = constraint->getScopeVar( 1 );

  if( rhs_v0_id == lhs_v0_id ) {
    mid = lhs_v0_id; src = lhs_v1_id; dst = rhs_v1_id;
  }
  else if( rhs_v0_id == lhs_v1_id ) {
    mid = lhs_v1_id; src = lhs_v0_id; dst = rhs_v1_id;
  }
  else if( rhs_v1_id == lhs_v0_id ) {
    mid = lhs_v0_id; src = lhs_v1_id; dst = rhs_v0_id;
  }
  else if( rhs_v1_id == lhs_v1_id ) {
    mid = lhs_v1_id; src = lhs_v0_id; dst = rhs_v0_id;
  }
}



// this.(dst, mid) X RHS.(mid, src) = (dst, src)
// Join the current CVG (sent from the parent to this node)
// with the CVG associated to a constraint held by this node
// and shared with parent:
// 
void join( const CVGraph& RHS )
{
  size_t dst, mid, src;
  getSrcDst( RHS, src, mid, dst );

  vector<pair<int,domBound> >& srcVals = RHS.varValBounds[ src ];
  vector<pair<int,domBound> >& dstVals = varValBounds[ dst ];
  vector<pair<int,domBound> >& midVals = RHS.varValBounds[ mid ];

  for( int i=0; i<srcVals.size(); i++ )
  {
    size_t lb = srcVals[ i ].first;
    size_t ub = srcVals[ i ].second;
    
    // take widest bounds at destination, passing through middle node
    size_t j_dst_lb = varBounds[ dst ].second; // curr dst ub
    size_t j_dst_ub = varBounds[ dst ].first; // curr dst lb 
    for( int j=lb; j<=ub; j++ )
    {
      j_dst_lb = min( j_dst_lb, midVals[ j ].first );
      j_dst_ub = max( j_dst_ub, midVals[ j ].second );
    }

    // save bounds for value i at source
    varValBounds[ src ][ i ] = make_pair( j_dst_lb, j_dst_ub );
  }

  // update SRC var bounds
  varBounds[ src ] = RHS.varBounds[ src ];
}


void dump()
{
  cout << "CVG for constraint " << constraint.getName();
}
