#ifndef _ULISSE_RDPOP_AC_UP_MESSAGE_HH_
#define _ULISSE_RDPOP_AC_UP_MESSAGE_HH_

#include "globals.hh"
#include "message.hh"
#include "var_int.hh"

class var_int;
class Agent;

namespace DPOP {
  
  class AC_upMessage : public Message
  {
  public:
    /**
     * Default Constructor
     */
    AC_upMessage();

    /**
     * Constructor: initalizes AC_upmessage according to var v
     */
    AC_upMessage( Agent& _src, Agent& _dst, var_int& v );
    
    /**
     * Copy Constructor
     */
    AC_upMessage( const AC_upMessage& other );    

    /**
     * Default Destructor
     */
    ~AC_upMessage();
    
    /*
     * Operation= on curr_state
     */
    AC_upMessage& operator=( const AC_upMessage& other );

    /**
     * The message type.
     */
    virtual std::string getType() const
    {
      return "AC-up";
    }

    /**
     * Reset message content (no touch header).
     */
    virtual void reset();

    /**
     * Prints AC_up message on screen.
     */
    virtual void dump();

    /**
     * Signal a change in the variable domain.
     */
    void setChanged( bool flag=true ) 
    {
      changed = flag;
    }

    /**
     * Returns whether changes happend in the chain of nodes explored till here. 
     */
    bool isChanged()
    {
      return changed;
    }
    
    /**
     * Returns whether there were changes in the variable domain.
     */
    bool isDomVarChanged()
    {
      return variable->isChanged();
    }

    /**
     * Set the variable associated with this message.
     */
    void setVariable( var_int& var )
    {
      variable = &var;
    }

    /**
     * Get the variable associated with this message.
     */
    var_int& getVariable()
    {
      return *variable;
    }
    
  private:
    var_int* variable; // @todo: we should only encode its domain here 
    bool changed;      // @todo: if the variable has been changed before msg passing
  };
  
};
#endif
