#include "rdpop-protocol.hh"
#include "pseudo-tree.hh"
#include "pseudo-node.hh"
#include "agent.hh"
#include "var_int.hh"
#include "scheduler.hh"
#include "ext-soft-constraint.hh"
#include "int-hard-constraint.hh"
#include "search-solution.hh"
#include "mailbox-system.hh"
#include "prop-rdfs.hh"
#include "external-search-engine.hh"
#include "internal-search-engine.hh"
#include "cv-matrix.hh"
#include "statistics.hh"

#include "rdpop-ACup-message.hh"
#include "rdpop-ACdown-message.hh"
#include "rdpop-PRdown-message.hh"
#include "rdpop-PRinit-message.hh"


using namespace std;
using namespace DPOP;

//#define NOAC

RDPOPprotocol::RDPOPprotocol()
{
  isRoot = false; 
  isLeaf = false;
  // nothing
  //query = new int[10];
}


RDPOPprotocol::~RDPOPprotocol()
{
  // delete[] utilTableQuery;
  // delete[] recvMsgQuery;
  delete[] constrQuery;
  // for( auto& kv : mailbox )
  //   delete kv.second;
}


void RDPOPprotocol::initialize( Agent& a, const VariableOrdering& O )
{
  owner = &a;
  initDPOP( a, O );

  initLocalConstraints();

  constrQuery = new int[10];

  initMailboxes();
  initHandlers();
  // Init AC-mailbox
  initAC_up_MailBox();
  initAC_down_MailBox();
  // Init PR-mailbox
  initPR_down_MailBox( O );
  initPR_path_MailBox( O );
  // Init UTIL-mailbox
  initUTILmailbox( O );

  if( isLeaf ) nbExpectedMessages[ "AC-up" ] = 0;
  else nbExpectedMessages[ "AC-up" ]   = msgAC_successors.size();
  if( isRoot ) nbExpectedMessages[ "AC-down" ] = 0;
  else nbExpectedMessages[ "AC-down" ] = msgAC_ancestors.size();

  //  initRDPOP( a, O );
}


void RDPOPprotocol::initLocalConstraints()
{
  for( auto c : owner->getLocalConstraints() )
  {
    if( c->getType() == extSoft or c->getType() == intSoft ) {
      localConstraints.push_back( (ExtSoftConstraint*)c );
    }
  }
}


void RDPOPprotocol::initMailboxes()
{
  mailbox[ "AC-up" ] = new MailboxSystem();
  mailbox[ "AC-up" ]->initialize( *owner );
  mailbox[ "AC-down" ] = new MailboxSystem();
  mailbox[ "AC-down" ]->initialize( *owner );
  mailbox[ "PR-down" ]  = new MailboxSystem();
  mailbox[ "PR-down" ]->initialize( *owner );
  mailbox[ "PR-init" ]  = new MailboxSystem();
  mailbox[ "PR-init" ]->initialize( *owner );
  mailbox[ "UTIL" ]  = new MailboxSystem();
  mailbox[ "UTIL" ]->initialize( *owner );
}


// Checked: Mar 27
// Status : ok
void RDPOPprotocol::initHandlers()
{
  activeHandler[ "AC-up" ]   = false;
  activeHandler[ "AC-down" ] = false;
  activeHandler[ "PR-down" ] = true;
  activeHandler[ "PR-init" ] = true;
  activeHandler[ "UTIL" ]    = false;
  activeHandler[ "VALUE" ]   = false;
}


void RDPOPprotocol::initUTILmailbox( const VariableOrdering& O )
{
  // Initialize UTIL Msg
  PseudoNode& curr_node = ((PseudoTree&)O).seekNode( *owner );
  nbExpectedMessages[ "UTIL" ] = curr_node.numofChildren();

  msgUTIL.setSource( *owner );
  if( not isRoot ) {
    msgUTIL.setDestination( curr_node.getParent().getContent() );
  }

}

// Checked: Mar 28
// Status : ok
void RDPOPprotocol::initAC_up_MailBox()
{
  // retrieve ancestor variables
  set< var_int* > ancestorVars;
  for( auto& v : hardConstrainedAncestorVars )
    ancestorVars.insert( v );
  for( auto& v : softConstrainedAncestorVars )
    ancestorVars.insert( v );

  for( auto& v : ancestorVars )
  {
    AC_upMessage M( *owner, v->getOwner(), *v );
    msgAC_ancestors[ v->getID() ] = M;
  }
}


bool RDPOPprotocol::ancestorsVarsContains( var_int& v )
{
  bool in_hc = 
    ( find( hardConstrainedAncestorVars.begin(),
	    hardConstrainedAncestorVars.end(), &v )
      != hardConstrainedAncestorVars.end() );
  bool in_sc = 
    ( find( softConstrainedAncestorVars.begin(),
	    softConstrainedAncestorVars.end(), &v )
      != softConstrainedAncestorVars.end() );
  
  return ( in_hc or in_sc );
}


// Checked: Mar 28
// Status : ok
void RDPOPprotocol::initAC_down_MailBox( )
{
  // retrieve the list of constraints involving boundary,
  // and get their variables, which are not in ancestors, nor in the local 
  // variables of current agent

  for( auto& v : owner->getBoundaryVariables() )
  {
    for( int i=0; i<v->numofConstraints(); i++ )
    {
      Constraint& c = v->getConstraint( i );
      for( int j=0; j<c.getArity(); j++ ) 
      {
	var_int& v = c.getScopeVar( j );
	if( not ancestorsVarsContains( v ) // not in B_k of some ancestor a_k
	    and 
	    not owner->hasInLocalVariables( v ) ) // not in L_i
	{
	  if( msgAC_successors.find( v.getID() ) ==
	      msgAC_successors.end() ) 
	  {
	    AC_downMessage M( *owner, v.getOwner(), v );
	    msgAC_successors[ v.getID() ] = M;
	  }
	}
      }
    }
  }

}


// Checked: Mar 28
// Status : ok
void RDPOPprotocol::initPR_down_MailBox( const VariableOrdering& O )
{
  // Retrieve children of a_i.
  PseudoNode& curr_node = ((PseudoTree&)O).seekNode( *owner );
  numofChildren = curr_node.numofChildren();
  for( int i=0; i<numofChildren; i++ )
  {
    Agent& dst = curr_node.getChild( i ).getContent();
    PR_downMessage M( *owner, dst );
    msgPR_successors[ dst.getID() ] = M;
  }

  // This need to be done after AC
  if( not isRoot )
  {
    // save constraints connecting this agent to its parent
    parentConstraints = curr_node.getParentCausal().second;
    nbExpectedMessages[ "PR-down" ] = 1;
    // save constraints connecting this agent to each of its ancestor
    for( int i=0; i<curr_node.numofAncestors(); i++ )
    {
      size_t aaID = curr_node.getAncestor( i ).getContent().getID();
      ancestorConstraints[ aaID ] = curr_node.getAncestorCausal( i ).second;
    }
  }
  else
    nbExpectedMessages[ "PR-down" ] = 0;
}


// Checked: Mar 28
// Status : ok
void RDPOPprotocol::initPR_path_MailBox( const VariableOrdering& O )
{
  PseudoNode& curr_node = ((PseudoTree&)O).seekNode( *owner );
  if( not isRoot )
    parent = &curr_node.getParent().getContent();

  for( int i=0; i<curr_node.numofAncestors(); i++ )
  {
    Agent& pa = curr_node.getAncestor( i ).getContent();
    pseudoParents.push_back( &pa );
  }

  msgPR_init.setSource( *owner );
  if( not curr_node.isRoot() )
    msgPR_init.setDestination( curr_node.getParent().getContent() );

  if( isLeaf ) nbExpectedMessages[ "PR-init" ] = 0;
  else nbExpectedMessages[ "PR-init" ] = curr_node.numofChildren();
}


bool RDPOPprotocol::receivedAllMessages( string msgType )
{
  if( openMailbox( msgType ).size() < nbExpectedMessages[ msgType ] )
    return false;
  else return true;
}


// Checked: Mar 28
// Status : ok
// Check whether the subtree rooted at a_i was changed by the AC
bool RDPOPprotocol::varDomainChangedFomAC_upMsg()
{
  while( openMailbox( "AC-up" ).size() > 0 )
  {
    AC_upMessage* msg = ((AC_upMessage*)openMailbox( "AC-up" ).read());
    if( msg->isChanged() ) return true;
  }
  return false;
}


// Checked: Mar 28
// Status : ok
bool RDPOPprotocol::varDomainChangedByAC()
{
  //for( auto& v : owner->getExternalSearchEngine().getScope() )
  for( auto& v : owner->getExternalSearchEngine().getScopeInHardConstr() )
  {
    if( v->isJustChanged() ) return true;
  }
  return false;
}


// Checked: Mar 28
// Status : ok
void RDPOPprotocol::AC_up_messageHandler()
{

  if( receivedAllMessages( "AC-up" ) )
  {
    g_stats.incrMsgNb( m_bcdpop_AC, owner->getID() );
    //cout << "Agent " << owner->getID() << " ACup\n";

    // Signal terminate of AC-up phase. Signal potential start of 
    // phases PR-down / AC-down
    activeHandler[ "AC-up" ]   = false;
    activeHandler[ "PR-down" ] = true;
    activeHandler[ "AC-down" ] = true;
    
    // Holds whether some variable domain has changed in the path 
    // of messages up to here (Fix point still not reached)
    bool changes = false;
    
    if( isLeaf ) { changes = false; } // reset changed flag
    else changes = varDomainChangedFomAC_upMsg();
    
    //#ifndef NOAC
    bool checkAC = true;
    checkAC = owner->getExternalSearchEngine().reduce();
    if( not checkAC ) { terminate(); }
    //#endif
    
    ////cout << "\t changes: " << changes << endl;
    ////owner->getBoundaryVariable( 0 ).dump();
 
    changes |= varDomainChangedByAC();

    if( isRoot )
    {
      // If, no variable domain was changed during last AC-up iteration
      // pass the control to PR-down (root)
      if( not changes ) { activeHandler[ "AC-down" ] = false; }
    }
    else // not Root
    {
      // update messages ACup with the change flag
      // and send it to all ancestors
      for( auto& kv : msgAC_ancestors )
      {
	// cout << "\tsending msg ACup to " << kv.second.getDestination().getName()<<endl;
    	kv.second.setChanged( changes );
      	openMailbox( "AC-up" ).send( kv.second );
      	g_scheduler->aQueue.push( kv.second.getDestination() );
      }
    }
    openMailbox( "AC-up" ).reset();
  }
  else // still waiting for some AC-up message
  {
    // reschedule current agent to wait all messages
    g_scheduler->aQueue.push( *owner );
  }

}


// Checked: Mar 28
// Status : ok
void RDPOPprotocol::AC_down_messageHandler()
{

  if( receivedAllMessages( "AC-down" ) )
  {
    ////cout << "Agent " << owner->getID() << " ACdown\n";
    g_stats.incrMsgNb( m_bcdpop_AC, owner->getID() );

    // Set restart AC-up phase 
    activeHandler[ "AC-down" ] = false;
    activeHandler[ "AC-up" ] = true;    

    if( not isLeaf )
    {
      // send msg AC-down to all successors
      for( auto& kv : msgAC_successors )
      {
	////cout << "\tsending msg ACdown to " << kv.second.getDestination().getName() << endl;

	openMailbox( "AC-down" ).send( ((Message&)(kv.second)) );
	g_scheduler->aQueue.push( kv.second.getDestination() );	  
      }
    }
    openMailbox( "AC-down" ).reset();
  }

  // reschedule current message (will restart AC-up)
  g_scheduler->aQueue.push( *owner );

}


// Checked: Mar 28
// Status : 
CVMatrix* RDPOPprotocol::getCVMfrom_PR_downMsg( PR_downMessage& PRmsg, size_t v_sID )
{
  for( int i=0; i<PRmsg.size(); i++ ) {
    if( PRmsg.getCVM( i ).getRowID() == v_sID ) {
      return &PRmsg.getCVM( i );
    }
  }
  return 0;
}



// Checked: Mar 28
// Status : ok
// propagate up from leaves
void RDPOPprotocol::PR_init_messageHandler() 
{
  if( receivedAllMessages( "PR-init" ) ) // when n message = n children.
  {

    ////cout << "Agent: " << owner->getID() << " PRinit\n";

    // Prepare AC-up exectuion 
    activeHandler[ "PR-init" ] = false;
    activeHandler[ "AC-up" ] = true;
 
    // Save the reachability Path information of this agent with its pseudo-parents.
    for( auto &src : pseudoParents )
    {
      IDpair sd = make_pair( src->getID(), owner->getID() );
      IDpair var_sd = make_pair( src->getBoundaryVariable( 0 ).getID(),
				 owner->getBoundaryVariable( 0 ).getID() );
      reachablePaths_vars[ sd ] = var_sd;
      reachablePaths[ sd ] = owner;

      // cout << "\t-init-reachablePaths[" << sd.first << ", " << sd.second << "] = " << owner->getID()  << endl;

      // insert path into message
      msgPR_init.insertPath( sd );
    }
 

    if( not isLeaf )
    {
      // SAVE the recability Path information received from the children of
      // this agent and prepare a PR-init message for its parent
      while( not openMailbox( "PR-init" ).isEmpty() )
      {
	PR_initMessage* msg = ((PR_initMessage*)openMailbox( "PR-init" ).read());

	for( int i=0; i< msg->nbPaths(); i++ )
	{
	  IDpair& sd = msg->getPath( i );           // source -> destination
	  reachablePaths[ sd ] = &msg->getSource(); // traversing msg->source
	  
	  // cout << "\t-recv-reachablePaths[" << sd.first << ", " << sd.second << "] = " << msg->getSource().getID() << endl;	  

	  IDpair var_sd = 
	    make_pair( g_Agents[ sd.first ]->getBoundaryVariable(0).getID(),
		       g_Agents[ sd.second ]->getBoundaryVariable(0).getID() );
	  reachablePaths_vars[ sd ] = var_sd;

	  // if source is differnet from this agent, then send it up to next parent
	  if( sd.first != owner->getID() )
	  {
	    msgPR_init.insertPath( sd );
	  }
	}
      }// all msgs read
    }
    else{ // a_i is a Leaf, activate AC-Message Handler:
      g_scheduler->aQueue.push( *owner );
    }
    
    if( not isRoot )
    {
      // Send all paths to parent
      openMailbox( "PR-init" ).send( msgPR_init );
      g_scheduler->aQueue.push( msgPR_init.getDestination() );
      // msgPR_init.dump();
      // getchar();
    }
  } // 
  else  // still waiting for some AC-up message
  {
    g_scheduler->aQueue.push( *owner );
  }
}


// Merge all constraints from this agent to parent involving same variables
// into a single CVM.
// Checked: Mar 28
// Status : ok
void RDPOPprotocol::mergeParentConstraints( CVMatrix& M_pi )
{
  vector<Constraint*>& PC = parentConstraints;

  CVMatrix& CVM_0 = *g_constraint2cvm[ PC[ 0 ]->getID() ];
  M_pi.copy( CVM_0 );  
  // cout << "Merging: " << PC[ 0 ]->getName() << " " << PC[ 0 ]->getID() << endl;
  // CVM_0.dump();
  for( int i=1; i<PC.size(); i++ )
  {
    CVMatrix& CVM_i = *g_constraint2cvm[ PC[ i ]->getID() ];
    M_pi.merge( CVM_i );
    // cout << "Merging: " << PC[ i ]->getName() << endl;
    // CVM_i.dump();
  }
}


// Check if aID is present among the reachablePaths already saved 
bool RDPOPprotocol::isInReachablePaths( size_t aID )
{
  for( auto& kv : reachablePaths ) // <src, dst, interface>
  {
    size_t a_sID = kv.first.first;  // agent src
    if( a_sID == parent->getID() ) 
      return true;
  }
  return false;
}


void RDPOPprotocol::saveMsgUTILaux( size_t vID, CVMatrix* M )
{
  msgUTIL.insertVar( vID );
  varID2UtilQuery[ vID ] = msgUTIL.nbTableVariables() - 1;
  if( M ) CVMrecv[ vID ] =  M;
}


// Checked: Mar 28
// Status : ok
void RDPOPprotocol::PR_down_messageHandler()
{

  if( receivedAllMessages( "PR-down" ) )
  {
    //// cout << "---------------\n";
    //cout << "(PRdown) Agent: " << owner->getID() << endl;

    size_t a_iID = owner->getID(); // agent ID
    size_t v_iID = owner->getBoundaryVariable(0).getID(); // var agent ID
    size_t v_PiID = isRoot ? -1 
      : parent->getBoundaryVariable(0).getID(); // parent var ID

    // Save AUX info for UTIL msg construction
    varID2UtilQuery[ v_iID ] = -1;

    // Path from parent to this node
    CVMatrix M_ip;

    if( not isRoot ) {
      // If the agent has more than one constraint with its parent, then 
      // this function will merge them generating a unique CVM M_pi
      mergeParentConstraints( M_ip );
      // If M_Pi->ai is not in the reachable paths received
      // then integrate it into the variables for UTIL table
      saveMsgUTILaux( v_PiID, NULL );

      if( not g_BCDPOP ) M_ip.setOne();

      // M_ip.dump();
      // getchar();
    }


    PR_downMessage* PRmsg = (PR_downMessage*)openMailbox( "PR-down" ).read();    

    // save the path with src already read
    std::map< size_t, bool > processed;

    // Note that the set of src's in reachablePaths is equal to the separator
    // of a_i, and therefore the set of values to be used in the UTILtable.
    for( auto& kv : reachablePaths ) // <src, dst, interface>
    {
      size_t a_sID = kv.first.first;  // agent src
      size_t a_dID = kv.first.second; // agent dst
      size_t v_sID = reachablePaths_vars[ kv.first ].first;  // var src
      size_t v_dID = reachablePaths_vars[ kv.first ].second; // var dst
      Agent* a_j = kv.second;	                            // interface 
      size_t a_jID = a_j->getID();			    // interface
      size_t v_jID = a_j->getBoundaryVariable( 0 ).getID(); // var interface
      CVMatrix M_si;		// from src -> a_i
      
      // cout << ":- Analyzing Reachable PATH[ " << a_sID << " -> " 
      // 	   << a_dID << "] via " << a_jID << endl;
      // if( processed[ a_sID ] ) {
      // 	cout  << "already processed\n"; 
      // }

      // Path starts at this agent, hence send CVM identity.
      if( a_sID == a_iID ) {
	M_si.initialize( v_sID, v_sID );
	M_si.setIdentity( );

	// M_si.dump();
      }
      else {
	// Retrieve M_sp from message received
	CVMatrix* M_sp = getCVMfrom_PR_downMsg( *PRmsg, v_sID );

	// Save Matrix from src -> parent( a_i )
	if( v_sID != v_PiID and not processed[ a_sID ] ) {
	  saveMsgUTILaux( v_sID, M_sp );
	}

	// Join Matrices to get reachable paths 's' -> 'i'
	M_si.copy( M_ip );		  // B

	if( not g_BCDPOP ) M_sp->setOne();

	M_si.join( *M_sp, v_sID, v_iID ); // M_sp x M_pi

	// Message reach destination.
	if( a_dID == a_iID )
	{
	  // For all ancestors, p, retrieve the direct M_pi and
	  // the indirect (from message) M_pi. Merge them and
	  // join them into UTIL Table
	  if( not g_BCDPOP ) M_si.setOne();	  
	  for( auto &c : ancestorConstraints[ a_sID ] )
	  {
	    CVMatrix& CVM_c = *g_constraint2cvm[ c->getID() ];
	    // Merge CVM from the same source.
	    M_si.merge( CVM_c );
	  }
	  CVMrecvDest[ v_sID ] = new CVMatrix( M_si );
	}
	
	// M_si.dump();
	// getchar();

      } //PATH-did not start at this agent (end)
      processed[ a_sID ] = true;

      // CVM not at destination -> continue with a_i's children
      if( a_dID != a_iID ) msgPR_successors[ a_jID ].insertCVM( M_si );

    } // FOR-EACH reachable path (end)

    // Create UTILtable:
    int lb = g_Variables[v_iID]->getDomain().lb_pos();
    int ub = g_Variables[v_iID]->getDomain().ub_pos();

    // Perform a DFS 
  
    // Root only has one value combination( its own )
    if( isRoot ) {
      vector<int> key(1, -1); vector<int> empty;
      for( int i=lb; i<=ub; i++) { 
	msgUTIL.insert( key, make_pair( i, computeCost( empty , i ) ) );
      }
    }
    else {
      // for each combination of values child -> parent 
      createUtilTable( M_ip, v_iID, v_PiID );
    }

    // msgUTIL.dump();
    // getchar();


    // Send msg PR to all successors
    if( not isLeaf ) {
      for( auto& kv : msgPR_successors ) {
	openMailbox( "PR-down" ).send( kv.second );
	g_scheduler->aQueue.push( kv.second.getDestination() );      
      }
    }


    // AC phase terminated
    activeHandler[ "AC-down" ] = false;
    activeHandler[ "AC-up" ]   = false;
    // PR-down phase terminate
    activeHandler[ "PR-down" ] = false;
    openMailbox( "PR-down" ).reset(); // reset queue
    activeHandler[ "UTIL" ] = true;
  }
  else {  // still waiting for some PR message
    // reschedule current agent to wait all messages
    g_scheduler->aQueue.push( *owner );
  }

}




// First CVMs *must* be M_pi. 
// we'll take only the restriction of the active values in p (rows)
// varsID vector *must* follow same order of the CVMs 
void RDPOPprotocol::createUtilTable( CVMatrix& M_ai_Pi, size_t viID, size_t vpID )
{
  ////cout << ":-createTable()--------------------------------\n";

  // parent + sep(ai)
  vector< size_t > util_varsID = msgUTIL.getVarsID();

  //// cout << "msg util over vars: ";
  //// for( int i=0; i<util_varsID.size(); i++ ) cout << " v_" << util_varsID[ i ];
  //// cout << endl;
  
  size_t limit = util_varsID.size() - 1;
  vector< int > util_row( limit+1, 0 );
  vector< int > carry( limit+1, 0 );
  vector< int > carryUB( limit+1, 0 );
  vector< int > carryLB( limit+1, 0 );

  // Initialize the carry
  for( int i=0; i<limit; i++ )
  {
    size_t vaID = util_varsID[ i+1 ];
    CVMatrix& M = *CVMrecv[ vaID ];
    carryLB[ i ] = carry[ i ] = M.getLB( vaID );   // Lower bound 
    carryUB[ i ] = M.getUB( vaID ); // upper bound 
  }

  // Iterate for all elements of the Parent Pi
  int a,b;
  for( int p = M_ai_Pi.getLB( vpID ); p <= M_ai_Pi.getUB( vpID ); p++ )
  {
    util_row[ 0 ] = p;
    for( int v = M_ai_Pi.getLB( viID ); v <= M_ai_Pi.getUB( viID ); v++ )
    {
      pair<int, cost_type> util_val( v, 0 );

      if( M_ai_Pi.getRowID() == viID ) { a = v; b = p; }
      else {a = p; b = v; }

      ////cout << "parent-child rel: " << p << " " << v << endl;

      if( not M_ai_Pi.isActive( a, b ) ) // if exists parent child rel
	continue;

      if( limit == 0 ) { 	// only parent in msgUTIL vars
	// process solution
	util_val.second = computeCost( util_row, v );
	if( isFinite( util_val.second ) )
	  msgUTIL.insert( util_row, util_val );
      }
      else {
	// Perform a DFS over all other variables
	int lev = 0;
	while( lev >= 0 )
	{
	  while( carry[ lev ] <= carryUB[ lev ] )
	  {
	    size_t vaID = util_varsID[ lev+1 ];
	    CVMatrix& M = *CVMrecv[ vaID ];

	    CVMatrix* R = 0;
	    if( CVMrecvDest.find( vaID ) != CVMrecvDest.end() )
	      R = CVMrecvDest[ vaID ];

	    int pp = carry[ lev ];
	    util_row[ lev+1 ] = pp;
	    carry[ lev ]++;

	    //// cout << " :- v_" << vaID << ", v_" << vpID << ": "
	    //// 	 << "(" << pp << ", " << p << ") \n"; 

	    if( R ) { 
	      //// cout << " :- v_" << vaID << ", v_" << viID << ": "
	      //// 	   << "(" << pp << ", " << v << ") \n"; 

	      if ( not R->isActive( pp, v ) ) { 
		////cout << "R NOT ACTIVE\n";
		continue;
	      }
	    }
	    
	    ////assert( M.getRowID() == vaID );

	    if( M.isActive( pp, p ) )
	    {
	      lev++;
	      //M.dump();
	      ////cout << "is active " << pp << ", " << p << endl;
	      if( lev == limit )
	      {
		////cout << "Sol found\n";
		// for(int ii=0; ii<util_row.size(); ii++)
		//   cout << " " << util_row[ ii ];
		// cout << endl;
		// getchar();
		util_val.second = computeCost( util_row, v );
		if( isFinite( util_val.second ) )
		  msgUTIL.insert( util_row, util_val );
		lev--;
	      }
	    }
	  }// iterate throughout all elements of current ancestor
	  carry[ lev ] = carryLB[ lev ];
	  // cout << "Restoring lev " << lev << " to LB: " << carryLB[ lev ] << endl;  
	  lev--;
	  
	}//while-lev>0

      }//-end-DFS
      
    } // j ( children )
  }// i (parent )
  ////cout << ":-createTableEND()--------------------------------\n";

}



// VERY INEFFICIENT:
// Tutto cio' puo' esser fatto un girno in meno -- per ogni value combination
// (tmp) devo semplicemente popolare UtilTable[tmp] con i possibili valori 
// ammessi e non calcolare i percorsi d'accapo
// Costi possono esser calcolati while going down in the search-tree -->
// can also do pruning this way (but a need a TRAIL-STACK-like structure)
void RDPOPprotocol::createUtilTable( std::vector< std::vector< int > >& values, 
				     int v  )
{
  int lev = 0;
  size_t limit = values.size();
  vector< int > tmp( limit, 0 );
  vector< int > idx( limit, 0 );
  pair<int, cost_type> ins(v, 0);

  while( lev >= 0 )
  {
    while( idx[ lev ] < values[ lev ].size() )
    {
      tmp[ lev ] = values[ lev ][ idx[ lev ] ];
      idx[ lev ]++;

      // Need to check if value is admissible, from connectivity matrix.
      // all and only contraint reachability matrices paths needed!
      
      lev++;
      if( lev == limit )
      {
	// process solution:
	ins.second = computeCost( tmp,  v );
	if( isFinite( ins.second) )
	  msgUTIL.insert( tmp, ins );

	lev--;
      }
    }
    idx[ lev ] = 0;
    lev--;
  }
}


// TODO:: ALSO CHECK HARD CONSTRAINTS ??
cost_type RDPOPprotocol::computeCost( vector<int>& others_val, int curr_var_val )
{
  cost_type cost = 0;
  int sidx;

  // Check cost of local constraints
  for( int i=0; i<localConstraints.size(); i++ )
  {
    ExtSoftConstraint& c = *localConstraints[ i ];
    for( int a=0; a<c.getArity(); a++ )
    {
      sidx = varID2UtilQuery[ c.getScopeVar( a ).getID() ];
      constrQuery[ a ] = ( sidx != -1 ) ? others_val[ sidx ] : curr_var_val;
    }
    cost_type lc = c.getCost( constrQuery );
    if( !isFinite( lc ) ) { return lc; }
    cost += lc;
  }
  

  // Check Soft Constraints and include Cost of ancestors with boundary variables
  for( int s=0; s<softConstrainedAncestorVars.size(); s++ )
  {
    for( int j=0; j<ancestorSoftConstraints[ s ].size(); j++ )
    {
      ExtSoftConstraint& c = *ancestorSoftConstraints[ s ][ j ];
      
      for( int a=0; a<c.getArity(); a++ )
      {
	sidx = varID2UtilQuery[ c.getScopeVar( a ).getID() ];
	constrQuery[ a ] = ( sidx != -1 ) ? others_val[ sidx ] : curr_var_val;
      }
      cost_type lc = c.getCost( constrQuery );
      if( !isFinite( lc ) ) { return lc; }
      cost += lc;
    }
  }
  return cost;
}



void RDPOPprotocol::UTILmessageHandler()
{

  // Each agent waits to receive all UTIL messages from its children.
  if( receivedAllMessages( "UTIL" ) )
  {    
    if( isLeaf )
    {
      // Extract Best Cost from UTIL table,
      // already done in construction
    }
    else{
      size_t nb_msgs = openMailbox( "UTIL" ).size();

      vector<UTILMessage*> utilMsgRecv( nb_msgs );
      // used to map vars of msg received to vars of ai UTIL TABLE
      vector< vector<int> > utilMsgRecv_varsMap( nb_msgs ); 
      // used to store the values projected from ai's UTIL message to 
      // UTIL message received
      vector< vector<int> > utilMsgRecv_valsProj( nb_msgs ); 

      // Collect the message received, and popolate the DS above. 
      int k=0;
      while( openMailbox( "UTIL" ).size() > 0 )
      {
	UTILMessage* msg = (UTILMessage*)openMailbox( "UTIL" ).read();
	utilMsgRecv[ k ] = msg ;
	utilMsgRecv_varsMap[ k ] = msgUTIL.mapVars2Vars( msg->getVarsID() );
	size_t nb_vars = utilMsgRecv_varsMap[ k ].size();
	utilMsgRecv_valsProj[ k ].resize( nb_vars );
	k++;
      }

      // Join Incoming Messages and Project over local variables
      // For each combination of values stored in ai.UTILmsg.TABLE(.first)
      // retrieve costs of corresponding combinations (if available) in 
      // received messages.
      msgUTIL.setTraversable();
      do {
	cost_type cost = 0;
	// Project current value comibnation over the received Tables and get cost. 
	for( int msg_i=0; msg_i<utilMsgRecv.size(); msg_i++ )
	{
	  // Read the values of ai's table, associated to variables
	  // of i-th message UTIL received.
	  msgUTIL.extract( utilMsgRecv_valsProj[ msg_i ], 
			   utilMsgRecv_varsMap[ msg_i ] );
	  cost_type rcv_cb 
	    = utilMsgRecv[ msg_i ]->getCost( utilMsgRecv_valsProj[ msg_i ] );
	  if( not isFinite( rcv_cb ) ) 
	  {
	    cost = worstValue(); break;
	  }
	  cost += rcv_cb;
	}
	msgUTIL.addLastTraversedCost( cost );
      } while( msgUTIL.advance() );
    }// not a leaf

    // Send message to parent
    if( not isRoot ) 
    {
      openMailbox( "UTIL" ).send( msgUTIL );
      g_scheduler->aQueue.push( msgUTIL.getDestination() );
    }
    else{
      g_stats.setBestCost( msgUTIL.getBestCost() );
      // Start Value propagation phase
    }

    activeHandler[ "UTIL" ]   = false;
    activeHandler[ "VALUE" ]  = true;
  }
  else {
    // reschedule current agent to wait all messages
    g_scheduler->aQueue.push( *owner );
  }

}


// Send msgs to only those variables that have changed.
void RDPOPprotocol::run()
{
  size_t aID = owner->getID();
  // cout << "agent: " << owner->getName() << " running protocol" << endl;     
  // g_scheduler->dump();
  // getchar();

  if( activeHandler[ "PR-init"] )
  {
    g_stats.setTimer( t_comm, aID );
    PR_init_messageHandler();
    g_stats.stopwatch( t_comm, aID );
  }

  if( not activeHandler[ "PR-init" ] )
  {
    if( activeHandler[ "AC-up" ] ) {
      g_stats.setTimer( t_comm, aID );
      AC_up_messageHandler();
      g_stats.stopwatch( t_comm, aID );
    }
    
    if( activeHandler[ "AC-down" ] ) {
      g_stats.setTimer( t_comm, aID );
      AC_down_messageHandler();
      g_stats.stopwatch( t_comm, aID );
    }

    if( (not activeHandler[ "AC-up" ] ) and
      activeHandler[ "PR-down" ] ) {
      g_stats.setTimer( t_comm, aID );
      PR_down_messageHandler();
      g_stats.stopwatch( t_comm, aID );
    }
  }

  if( activeHandler[ "UTIL" ] ) {
    g_stats.setTimer( t_search_local, aID );
    UTILmessageHandler();
    g_stats.stopwatch( t_search_local, aID );
  }

  if( activeHandler[ "VALUE" ] )
  {
    g_stats.setTimer( t_statistics, aID );
    size_t max_size = 1;
    vector<size_t> vars = msgUTIL.getVarsID();
    for( int i=0; i<vars.size(); i++ )
    {
      max_size *= g_Variables[ vars[ i ] ]->getDomain().size();
    }
    g_stats.setMsgSize( m_dpop_UTILrows_ap, aID, max_size );
    max_size *= owner->getBoundaryVariable( 0 ).getDomain().size();
    g_stats.setMsgSize( m_dpop_UTILrows_bp, aID, max_size );
    

    g_stats.setMsgSize( m_bcdpop_UTILentries_bp, aID,
			msgUTIL.completeSizeBeforeProjection() );
    g_stats.setMsgSize( m_bcdpop_UTILentries_ap, aID,
			msgUTIL.completeSizeAfterProjection() );

    g_stats.setMsgSize( m_bcdpop_UTILrows_bp, aID, 
			msgUTIL.utilVectorSizeBeforeProjection() );
    g_stats.setMsgSize( m_bcdpop_UTILrows_ap, aID, 
			msgUTIL.utilVectorSizeAfterProjection() );

    g_stats.stopwatch( t_statistics, aID );

    activeHandler[ "VALUE" ] = false;
  }

}

void RDPOPprotocol::terminate()
{
  cout << "The problem is UNSATISFIABLE\n";
  //g_stats.dump();
  exit(1);
  // @todo
}
