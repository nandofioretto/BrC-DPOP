#ifndef _ULISSE_CONSTRAINT_VALUE_GRAPH_HH_
#define _ULISSE_CONSTRAINT_VALUE_GRAPH_HH_

#include "globals.hh"

typedef size_t type_vID;
typedef std::pair<int,int> domBound;

class var_int;

std::map<Constraint, CVGraph*> g_constraint2cvg;
/**
 * The constraint Value Graph contains a succint explicit representation
 * of the constraint.
 * 
 * It acts exploits both domain variable bounds and explicit values.
 */
class CVGraph
{
public:
  /**
   * Default Constructor.
   */
  CVGraph();

  /**
   * Default Destructor.
   */
  ~CVGraph();

  /**
   * Copy Constructor.
   */
  CVGraph( const CVGraph& other );

  /**
   * Initializes the CVG
   */
  void initialize( Constraint& c );

  /**
   * Joins two CVGs.
   * note: carful to path direction -- can also be imposed via input. 
   */
  CVGraph& join( const CVGraph& LHS, const CVGraph& RHS );

  
  void setLB( type_vID vID, int lb )
  {
    bounds[ vID ].first = lb;
  }

  void setUB( type_vID vID, int ub )
  {
    bounds[ vID ].second = ub;
  }

  void setBounds( type_vID vID, int lb, int ub )
  {
    bounds[ vID ].first = lb;
    bounds[ vID ].second = ub;
  }

  int getLB( type_vID vID )
  {
    return bounds[ vID ].first;
  }

  int getUB( type_vID varID )
  {
    return bounds[ vID ].second;
  }

  void resetChangedFlags()
  {
    for( auto kv : changed )
      kv.second = false;
  }

  void dump();

private:

  // Link to the constraint associated to this constraint value graph. 
  Constraint* constraint;

  // the variable bounds as given from the variable domain.
  // ( no redundancy here - take it from domain )
  std::map<varID,domBound> varBounds;

  // labels here and not values -- bounds are labels,
  // and also values are labels
  std::map< varID, std::vector<std::pair<int,domBound> > > varValBounds;

  // Flag whenever a variable domain has changed due to the effect
  // of propagating some constraint.
  std::map< type_vID, bool > changed;
  
};

#endif
