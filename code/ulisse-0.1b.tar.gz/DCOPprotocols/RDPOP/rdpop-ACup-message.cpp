#include "rdpop-ACup-message.hh"
#include "search-solution.hh"
#include "agent.hh"
#include "var_int.hh"

using namespace DPOP;
using namespace std;


AC_upMessage::AC_upMessage( )
  : variable( 0 ), changed( false )
{
  // nothing
}


AC_upMessage::AC_upMessage( Agent& _src, Agent& _dst, var_int& v )
{
  src  = &_src;
  dest = &_dst;
  variable = &v;
  changed = v.isChanged();
}


AC_upMessage::~AC_upMessage()
{ 
  // nothing
}


AC_upMessage::AC_upMessage( const AC_upMessage& other )
{
  src = other.src;
  dest = other.dest;
  variable = other.variable;
  changed = other.changed;
}


AC_upMessage& AC_upMessage::operator=( const AC_upMessage& other )
{
  if( this != &other )
  {
    src = other.src;
    dest = other.dest;
    variable = other.variable;
    changed = other.changed;
  }
  return *this;
}


void AC_upMessage::reset()
{
  // changed = false;
}


void AC_upMessage::dump()
{
  cout << "Message type: AC_up ";
  if( src and dest )
    cout << "  Src: " << src->getName()
	 << "  Dst: " << dest->getName();
  if( changed ) cout << "  (CHANGED)\n";
  else cout << "  (NOT CHANGED) \n";
}
