#ifndef _ULISSE_RULE_BASED_DPOP_PROTOCOL_HH_
#define _ULISSE_RULE_BASED_DPOP_PROTOCOL_HH_

#include "globals.hh"
#include "protocol.hh"
#include "dpop-protocol.hh"
#include "agent.hh"
#include "rdpop-ACup-message.hh"
#include "rdpop-ACdown-message.hh"
#include "rdpop-PRdown-message.hh"
#include "rdpop-PRinit-message.hh" // contains definition of IDpair
#include "rdpop-UTIL-message.hh"

class Agent;
class VariableOrdering;
class ExtSoftConstraint;
class IntHardConstraint;
class Constraint;

class ACMessage;

namespace DPOP {

  /**
   * Implements the RDPOP (Rules-based-DPOP) algorithm.
   * Description:
   */
  class RDPOPprotocol : public DPOPprotocol
  {
  public:
    
    /**
     * Default constructor.
     */
    RDPOPprotocol();
    
    /**
     * Default constructor.
     */
    
    ~RDPOPprotocol();
    
    /**
     * Links the Agent governing this protocol and initialize the messages 
     * source and destinations according to the VariableOrdering.
     */
    virtual void initialize( Agent& a, const VariableOrdering& O );

    
    /**
     * Initializes local constraints.
     */
    void initLocalConstraints();

    /**
     * Initializes the mail boxes
     */
    virtual void initMailboxes( );

    /**
     * Initializes the Message Handler map
     */
    void initHandlers();

    /**
     * Init messages AC-up to send.
     */
    void initAC_up_MailBox( );

    /**
     * Init messages AC-down to send.
     */
    void initAC_down_MailBox( );

    /**
     * Init messages PR-down to send.
     */  
    void initPR_down_MailBox( const VariableOrdering& O );

    /**
     * Init message PR-init.
     */
    void initPR_path_MailBox( const VariableOrdering& O );

    /**
     * Init messages PR to send.
     */
    void initPR_MailBox( );

    /**
     * Init message UTIL to send.
     */
    void initUTILmailbox( const VariableOrdering& O );
    
    /**
     * Executes the protocol.
     */
    virtual void run();
    
    /**
     * Terminates the protocol.
     */
    virtual void terminate();

    /**
     * Returns wheter the agent running the protocol has received all messages 
     * of type 'msgType', expected at one iteration.
     */
    bool receivedAllMessages( std::string msgType );

    /**
     * Check if in receiving messages AC-up, no domain has changed (i.e., 
     * distributed AC fixpoint reached).
     */
    bool varDomainChangedFomAC_upMsg();

    /**
     * Check if any var is changed by local AC
     */
    bool varDomainChangedByAC();

    /**
     * The AC-up message handler.
     */
    void AC_up_messageHandler();

    /**
     * The AC-down message handler.
     */
    void AC_down_messageHandler();

    /**
     * The AC-up message handler.
     */
    void PR_down_messageHandler();

   /**
    * The PR-init message handler.
    */
    void PR_init_messageHandler(); 
    
   /**
    * The UTIL message handler.
    */
    void UTILmessageHandler();

    /**
     * Whether the v is contained in 'hardConstrainedAncestorVars'.
     */
    bool ancestorsVarsContains( var_int& v );
    
    /**
     * Returns the correspoding CVMatrix from the received PR-down messages
     */
    CVMatrix* getCVMfrom_PR_downMsg( PR_downMessage& PRmsg, size_t v_sID );
  
    /** Merge all constraints from this agent to parent involving same variables
     * into a single CVM.    
     */
    void mergeParentConstraints( CVMatrix& M_pi );

    bool isInReachablePaths( size_t aID );
    
    void saveMsgUTILaux( size_t vID, CVMatrix* M );

    void createUtilTable( CVMatrix& M, size_t vId, size_t pID  );

    void createUtilTable( std::vector< std::vector< int > >& values, int v  );

    cost_type computeCost( std::vector<int>& others_val, int curr_var_val );

  private:
    // Notation: We call a_i the agent running this protocol.
    
    // These are the messages that a_i will send during the AC_up propagation
    // phase. They are the messages associated to each variables x_k \in B_j for all 
    // agent aj \in Pi \cup PPi.
    std::map< size_t, AC_upMessage > msgAC_ancestors; // < var_id, MSG >

    // These are the messages that a_i will send during the AC_down propagation
    // phase. They are messages associated to each variable x_k \in B_j for all 
    // agent aj \in Ci \cup PCi.
    std::map< size_t, AC_downMessage > msgAC_successors; // < var_id, MSG >
    
    // These are the messages that a_i will send during the PR_downMessage phase,
    // that is, when updating the Value reachability matrices. They are the messages
    // associated to each agents a_j \in C_i.
    // The PR_downMessage may or may not contain a CVM
    std::map< size_t, PR_downMessage > msgPR_successors; // <agent_id, MSG >

    // The message to be sent by a_i to its parent in the PR init phase.
    PR_initMessage msgPR_init;

    // The PseudoParents of a_i
    std::vector< Agent* > pseudoParents;
    Agent* parent;

    // map< dest, vect of children of current node, connected
    // via  a path to reach dest
    // <aID, aID> --> via Agent*
    std::map< IDpair, Agent*> reachablePaths;

    // <aID, aID> (src, dst) -> (vID, vID) src, dst var idx in the boundary
    // variables of agents
    std::map< IDpair, IDpair> reachablePaths_vars;

    // If a node has constraints c_1,...,c_k, with its parent, we create a CVM where
    // position [i, j] = \BigVee_k CVM(c_k)[ i ][ j ]
    // That is, if there exists at least one path, then mark it.
    // constraint shared with parent
    std::vector<Constraint*> parentConstraints;

    // source_agent_id, vector of constraints connecting source with this agent.
    std::map< size_t, std::vector<Constraint*> > ancestorConstraints;

    // source agent id, CVMatrix resulting from mergina all constraints above
    // + the path reticulated down in the PR_down pahse.
    //std::map< size_t, CVMatrix> ancestorCVM; // Not used

    // Flags to signal whether the agent running this protocol should
    // execute or not the AC/PR phases
    std::map< std::string, size_t > nbExpectedMessages;
    std::map< std::string, bool   > activeHandler;


    //std::map< size_t, CVMatrix > CVMpaths;
 

    //////////////////////////////////////////
    // DPOP handling
    UTILMessage msgUTIL;

    std::map< size_t, CVMatrix* > CVMrecv;
    std::map< size_t, CVMatrix* > CVMrecvDest;

   
    // Support DS: 
    // the query to check for cost computation of each constraint when 
    // processing the UTIL table
    int* constrQuery;
    // Used to associated var ID to the position of in the constrQuery array.
    std::map<int,int> varID2UtilQuery;

    // contains the local constraints to this agent -> this is an HACKING, as it is 
    // usually treated in the External search
    std::vector<ExtSoftConstraint*> localConstraints;
 
  };
  
};


#endif
