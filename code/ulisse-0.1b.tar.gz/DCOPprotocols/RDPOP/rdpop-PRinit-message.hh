#ifndef _ULISSE_RDPOP_PR_INIT_MESSAGE_HH_
#define _ULISSE_RDPOP_PR_INIT_MESSAGE_HH_

#include "globals.hh"
#include "message.hh"

class Agent;

namespace DPOP {
  
  typedef std::pair<size_t,size_t> IDpair;

  class PR_initMessage : public Message
  {
  public:
    /**
     * Default Constructor
     */
    PR_initMessage();

    /**
     * Constructor: initalizes AC_initmessage according to var v
     */
    PR_initMessage( Agent& _src, Agent& _dst );
    
    /**
     * Copy Constructor
     */
    PR_initMessage( const PR_initMessage& other );
    
    /**
     * Default Destructor
     */
    ~PR_initMessage();
    
    /*
     * Operation= on curr_state
     */
    PR_initMessage& operator=( const PR_initMessage& other );

    /**
     * The message type.
     */
    virtual std::string getType() const
    {
      return "PR-init";
    }

    /**
     * Reset message content (no touch header).
     */
    virtual void reset();

    /**
     * Prints AC_init message on screen.
     */
    virtual void dump();

    /**
     * The number of pahts in the message
     */
    size_t nbPaths() const
    {
      return paths.size();
    }

    /**
     * Get the i-th path.
     */
    IDpair& getPath( int i )
    {
      return paths[ i ];
    }

    void insertPath( IDpair& sd )
    {
      paths.push_back( sd );
    }

  private:
    // <src, dst>  variables in a path.
    // src is a node ancestor of dst
    std::vector< IDpair > paths;

  };
  
};
#endif
