#include "rdpop-protocol.hh"
#include "pseudo-tree.hh"
#include "pseudo-node.hh"
#include "agent.hh"
#include "var_int.hh"
#include "scheduler.hh"
#include "ext-soft-constraint.hh"
#include "int-hard-constraint.hh"
#include "search-solution.hh"
#include "mailbox-system.hh"
#include "prop-rdfs.hh"
#include "external-search-engine.hh"
#include "internal-search-engine.hh"
#include "cv-matrix.hh"
#include "statistics.hh"

#include "rdpop-ACup-message.hh"
#include "rdpop-ACdown-message.hh"
#include "rdpop-PRdown-message.hh"
#include "rdpop-PRinit-message.hh"


using namespace std;
using namespace DPOP;

//#define DBG_MSG
//#define DBG_RUN
//#define DBG_COST

//#define NOAC

RDPOPprotocol::RDPOPprotocol()
{
  isRoot = false; 
  isLeaf = false;
  // nothing
  //query = new int[10];
}


RDPOPprotocol::~RDPOPprotocol()
{
  // delete[] utilTableQuery;
  // delete[] recvMsgQuery;
  delete[] constrQuery;
  // for( auto& kv : mailbox )
  //   delete kv.second;
}


void RDPOPprotocol::initialize( Agent& a, const VariableOrdering& O )
{
  owner = &a;

  initDPOP( a, O );

  initLocalConstraints();

  constrQuery = new int[10];

  initMailboxes();
  initHandlers();
  // Init AC-mailbox
  initAC_up_MailBox();
  initAC_down_MailBox();
  // Init PR-mailbox
  initPR_down_MailBox( O );
  initPR_path_MailBox( O );
  // Init UTIL-mailbox
  initUTILmailbox( O );

  if( isLeaf ) nbExpectedMessages[ "AC-up" ] = 0;
  else nbExpectedMessages[ "AC-up" ]   = msgAC_successors.size();
  if( isRoot ) nbExpectedMessages[ "AC-down" ] = 0;
  else nbExpectedMessages[ "AC-down" ] = msgAC_ancestors.size();

  //  initRDPOP( a, O );
}


void RDPOPprotocol::initLocalConstraints()
{
  for( auto c : owner->getLocalConstraints() )
  {
    if( c->getType() == extSoft or c->getType() == intSoft ) {
      localConstraints.push_back( (ExtSoftConstraint*)c );
    }
  }
}


void RDPOPprotocol::initMailboxes()
{
  mailbox[ "AC-up" ] = new MailboxSystem();
  mailbox[ "AC-up" ]->initialize( *owner );
  mailbox[ "AC-down" ] = new MailboxSystem();
  mailbox[ "AC-down" ]->initialize( *owner );
  mailbox[ "PR-down" ]  = new MailboxSystem();
  mailbox[ "PR-down" ]->initialize( *owner );
  mailbox[ "PR-init" ]  = new MailboxSystem();
  mailbox[ "PR-init" ]->initialize( *owner );
  mailbox[ "UTIL" ]  = new MailboxSystem();
  mailbox[ "UTIL" ]->initialize( *owner );
}


// Checked: Mar 27
// Status : ok
void RDPOPprotocol::initHandlers()
{
  activeHandler[ "AC-up" ] = false;
  activeHandler[ "AC-down" ] = false;
  activeHandler[ "PR-down" ] = true;
  activeHandler[ "PR-init" ] = true;
  activeHandler[ "UTIL" ]    = false;
  activeHandler[ "VALUE" ]   = false;
}


void RDPOPprotocol::initUTILmailbox( const VariableOrdering& O )
{
  // Initialize UTIL Msg
  PseudoNode& curr_node = ((PseudoTree&)O).seekNode( *owner );
  nbExpectedMessages[ "UTIL" ] = curr_node.numofChildren();

  msgUTIL.setSource( *owner );
  if( not isRoot ) {
    msgUTIL.setDestination( curr_node.getParent().getContent() );
  }

}

// Checked: Mar 28
// Status : ok
void RDPOPprotocol::initAC_up_MailBox()
{
  // retrieve ancestor variables
  set< var_int* > ancestorVars;
  for( auto& v : hardConstrainedAncestorVars )
    ancestorVars.insert( v );
  for( auto& v : softConstrainedAncestorVars )
    ancestorVars.insert( v );

  // cout << "Agent " << owner->getID() << endl;

  for( auto& v : ancestorVars )
  {
    AC_upMessage M( *owner, v->getOwner(), *v );
    msgAC_ancestors[ v->getID() ] = M;
    // cout << "\t msgAC_ancestors[ v_" << v->getID() << " ] = ";
    // M.dump();
  }
}


bool RDPOPprotocol::ancestorsVarsContains( var_int& v )
{
  bool in_hc = 
    ( find( hardConstrainedAncestorVars.begin(),
	    hardConstrainedAncestorVars.end(), &v )
      != hardConstrainedAncestorVars.end() );
  bool in_sc = 
    ( find( softConstrainedAncestorVars.begin(),
	    softConstrainedAncestorVars.end(), &v )
      != softConstrainedAncestorVars.end() );
  
  return ( in_hc or in_sc );
}


// Checked: Mar 28
// Status : ok
void RDPOPprotocol::initAC_down_MailBox( )
{
  // retrieve the list of constraints involving boundary,
  // and get their variables, which are not in ancestors, nor in the local 
  // variables of current agent

  // cout << "Agent " << owner->getID() << endl;

  for( auto& v : owner->getBoundaryVariables() )
  {
    for( int i=0; i<v->numofConstraints(); i++ )
    {
      Constraint& c = v->getConstraint( i );
      for( int j=0; j<c.getArity(); j++ ) 
      {
	var_int& v = c.getScopeVar( j );
	if( not ancestorsVarsContains( v ) // not in B_k of some ancestor a_k
	    and 
	    not owner->hasInLocalVariables( v ) ) // not in L_i
	{
	  if( msgAC_successors.find( v.getID() ) ==
	      msgAC_successors.end() ) 
	  {
	    AC_downMessage M( *owner, v.getOwner(), v );
	    msgAC_successors[ v.getID() ] = M;
	    // cout << "\t msgAC_successors[ v_" << v.getID() << " ] = ";
	    // M.dump();
	  }
	}
      }
    }
  }

}


// Checked: Mar 28
// Status : ok
void RDPOPprotocol::initPR_down_MailBox( const VariableOrdering& O )
{
  // cout << "Agent " << owner->getID() << endl;

  // Retrieve children of a_i.
  PseudoNode& curr_node = ((PseudoTree&)O).seekNode( *owner );
  numofChildren = curr_node.numofChildren();
  for( int i=0; i<numofChildren; i++ )
  {
    Agent& dst = curr_node.getChild( i ).getContent();
    PR_downMessage M( *owner, dst );
    msgPR_successors[ dst.getID() ] = M;
    // cout << "\t msgPR_successors[ v_" << dst.getID()  << " ] = ";
    // M.dump();
  }

  // This need to be done after AC
  if( not isRoot )
  {
    // save constraints connecting this agent to its parent
    parentConstraints = curr_node.getParentCausal().second;
    // cout << "causal to parent: \n";
    // for( auto& c : parentConstraints )
    //   { cout << "\t";  c->dump();}

    nbExpectedMessages[ "PR-down" ] = 1;
    // save constraints connecting this agent to each of its ancestor
    for( int i=0; i<curr_node.numofAncestors(); i++ )
    {
      size_t aaID = curr_node.getAncestor( i ).getContent().getID();
      ancestorConstraints[ aaID ] = curr_node.getAncestorCausal( i ).second;
      // cout << "causal to ancestor: " << aaID << endl;
      // for( auto& c : ancestorConstraints[ aaID ] )
      // { cout << "\t";  c->dump();}
    }
  }
  else
    nbExpectedMessages[ "PR-down" ] = 0;
}


// Checked: Mar 28
// Status : ok
void RDPOPprotocol::initPR_path_MailBox( const VariableOrdering& O )
{
  PseudoNode& curr_node = ((PseudoTree&)O).seekNode( *owner );
  // cout << "Agent " << owner->getID() << " Ancestors: " << endl;
  
  if( not isRoot )
    parent = &curr_node.getParent().getContent();

  for( int i=0; i<curr_node.numofAncestors(); i++ )
  {
    Agent& pa = curr_node.getAncestor( i ).getContent();
    pseudoParents.push_back( &pa );
    // cout << "\t " << pa.getID() << endl;
  }

  msgPR_init.setSource( *owner );
  if( not curr_node.isRoot() )
    msgPR_init.setDestination( curr_node.getParent().getContent() );

  if( isLeaf ) nbExpectedMessages[ "PR-init" ] = 0;
  else nbExpectedMessages[ "PR-init" ] = curr_node.numofChildren();
}


bool RDPOPprotocol::receivedAllMessages( string msgType )
{
  if( openMailbox( msgType ).size() < nbExpectedMessages[ msgType ] )
    return false;
  else return true;
}


// Checked: Mar 28
// Status : ok
// Check whether the subtree rooted at a_i was changed by the AC
bool RDPOPprotocol::varDomainChangedFomAC_upMsg()
{
  while( openMailbox( "AC-up" ).size() > 0 )
  {
    AC_upMessage* msg = ((AC_upMessage*)openMailbox( "AC-up" ).read());
    if( msg->isChanged() ) return true;
  }
  return false;
}


// Checked: Mar 28
// Status : ok
bool RDPOPprotocol::varDomainChangedByAC()
{
  for( auto& v : owner->getExternalSearchEngine().getScope() )
  {
    if( v->isJustChanged() ) return true;
  }
  return false;
}


// Checked: Mar 28
// Status : ok
void RDPOPprotocol::AC_up_messageHandler()
{

  if( receivedAllMessages( "AC-up" ) )
  {
    //cout << "Agent " << owner->getID() << " ACup\n";
    activeHandler[ "AC-up" ]   = false;
    activeHandler[ "PR-down" ] = true;
    activeHandler[ "AC-down" ] = true;

    // Hold whether some variable domain has changed in the path 
    // of messages up to here (Fix point still not reached)
    bool changes;

    if( isLeaf ) changes = false; // reset changed flag
    else changes = varDomainChangedFomAC_upMsg();

#ifndef NOAC
    bool checkAC = owner->getExternalSearchEngine().reduce();
    if( not checkAC ) { terminate(); }
#endif

    // update current message with local (if leaf only local information matter)
    changes |= varDomainChangedByAC();
    
    // cout << "\t changes: " << changes << endl;
    
    if( isRoot ) {
      // no variable domain was changed during last AC-up iteration.
      if( not changes ) {
	// AC phase terminates here for Root agent
	activeHandler[ "AC-down" ] = false;
	// Pass the control to PR-down (root)
      }
    } // isRoot
    else // not Root
    {
      for( auto& kv : msgAC_ancestors )
      {
      	// update messages ACup with the change flag:
      	kv.second.setChanged( changes );
      	openMailbox( "AC-up" ).send( kv.second );
      	g_scheduler->aQueue.push( kv.second.getDestination() );
      }
    }
    openMailbox( "AC-up" ).reset();
  }
  else {
    // reschedule current agent to wait all messages
    g_scheduler->aQueue.push( *owner );
  }

}


// Checked: Mar 28
// Status : ok
void RDPOPprotocol::AC_down_messageHandler()
{
  if( receivedAllMessages( "AC-down" ) )
  {
    //cout << "Agent " << owner->getID() << " ACdown\n";

    activeHandler[ "AC-down" ] = false;
    activeHandler[ "AC-up" ] = true;    
    if( not isLeaf )
    {
      // send msg AC-down to all successors
      for( auto& kv : msgAC_successors )
      {
	openMailbox( "AC-down" ).send( ((Message&)(kv.second)) );
	g_scheduler->aQueue.push( kv.second.getDestination() );	  
      }
    }
    // reset msg queue
    openMailbox( "AC-down" ).reset();
  }
  // reschedule current message (will restart AC-up)
  g_scheduler->aQueue.push( *owner );
}


// Checked: Mar 28
// Status : 
CVMatrix* RDPOPprotocol::getCVMfrom_PR_downMsg( PR_downMessage& PRmsg, size_t v_sID )
{
  for( int i=0; i<PRmsg.size(); i++ ) {
    if( PRmsg.getCVM( i ).getRowID() == v_sID ) { 
      return &PRmsg.getCVM( i );
    }
  }
  return 0;
}


// Merge all constraints from this agent to parent involving same variables
// into a single CVM.
// Checked: Mar 28
// Status : ok
void RDPOPprotocol::mergeParentConstraints( CVMatrix& M_pi )
{
  vector<Constraint*>& PC = parentConstraints;
  CVMatrix& CVM_0 = *g_constraint2cvm[ PC[ 0 ]->getID() ];
  M_pi.copy( CVM_0 );  
  for( int i=1; i<PC.size(); i++ )
  {
    CVMatrix& CVM_i = *g_constraint2cvm[ PC[ i ]->getID() ];
    M_pi.merge( CVM_i );
  }
}


// Checked: Mar 28
// Status : ok
// propagate up from leaves
void RDPOPprotocol::PR_init_messageHandler() 
{
  if( receivedAllMessages( "PR-init" ) ) // when n message = n children.
  {
    activeHandler[ "PR-init" ] = false;
    activeHandler[ "AC-up" ] = true;

 
    // cout << "Agent: " << owner->getID() << endl;

    for( auto &src : pseudoParents )
    {
      // save expected paths
      IDpair sd = make_pair( src->getID(), owner->getID() );
      IDpair var_sd = make_pair( src->getBoundaryVariable( 0 ).getID(),
				 owner->getBoundaryVariable( 0 ).getID() );
      reachablePaths_vars[ sd ] = var_sd;
      reachablePaths[ sd ] = owner;

      // cout << "\t-init-reachablePaths[" << sd.first << ", " << sd.second
      // 	   << "] = " << owner->getID()  << endl;

      // insert path into message
      msgPR_init.insertPath( sd );
    }
 

    if( not isLeaf )
    {
      // SAVE received paths and prepare message
      while( not openMailbox( "PR-init" ).isEmpty() )
      {
	PR_initMessage* msg = ((PR_initMessage*)openMailbox( "PR-init" ).read());

	for( int i=0; i< msg->nbPaths(); i++ )
	{
	  IDpair& sd = msg->getPath( i );           // source -> destination
	  reachablePaths[ sd ] = &msg->getSource(); // traversing msg->source

	  // cout << "\t-recv-reachablePaths[" << sd.first << ", " << sd.second
	  //      << "] = " << msg->getSource().getID() << endl;
	  
	  IDpair var_sd = 
	    make_pair( g_Agents[ sd.first ]->getBoundaryVariable(0).getID(),
		       g_Agents[ sd.second ]->getBoundaryVariable(0).getID() );
	  reachablePaths_vars[ sd ] = var_sd;

	  // if source is differnet from this agent, then send it up to next parent
	  if( sd.first != owner->getID() )
	  {
	    msgPR_init.insertPath( sd );
	  }
	}
      }
    }
    else{
      // Activate AC-Message Handler:
      g_scheduler->aQueue.push( *owner );
    }
    
    if( not isRoot )
    {
      // Send all paths to parent
      openMailbox( "PR-init" ).send( msgPR_init );
      g_scheduler->aQueue.push( msgPR_init.getDestination() );	  
      // msgPR_init.dump();
    }
  }
  else 
  {
    g_scheduler->aQueue.push( *owner );
  }
}


// Checked: Mar 28
// Status : ok
void RDPOPprotocol::PR_down_messageHandler()
{
  // Each agent only receives one PR-down message, from its parent.
  // Such message may or may not have a CVM
  if( receivedAllMessages( "PR-down" ) )
  {
    // cout << "(PRdown) Agent: " << owner->getID() << endl;

    // At the begin each child CVM is empty.
    PR_downMessage* PRmsg = (PR_downMessage*)openMailbox( "PR-down" ).read();    
    size_t a_iID = owner->getID();
    size_t v_iID = owner->getBoundaryVariable(0).getID();
    CVMatrix M_pi;		// (all constraints) a_p -> a_i
    map< int, vector< vector< int > > > ai_UTILvaluesToJoin;
    varID2UtilQuery[ v_iID ] = -1;

    if( not isRoot ) 
    {
      // This need to be done after AC
      mergeParentConstraints( M_pi );

      // cout << "\tCVM a_p -> a_i: ";
      // M_pi.dump();

      // Check if parent is present among the reachablePaths already saved 
      bool parent_check = false;
      for( auto& kv : reachablePaths ) // <src, dst, interface>
      {
	size_t a_sID = kv.first.first;  // agent src
	if( a_sID == parent->getID() ) parent_check = true;
      }

      //if not, then integrate it into the variables for vuilding table
      if( not parent_check )
      {
	int vID = parent->getBoundaryVariable(0).getID();
	msgUTIL.insertVar( vID );
	varID2UtilQuery[ vID ] = msgUTIL.nbTableVariables() - 1;
	
	int lb = M_pi.getLB( v_iID );
	int ub = M_pi.getUB( v_iID );
	for( int i=lb; i<=ub; i++ )
	{
	  ai_UTILvaluesToJoin[ i ].push_back( M_pi.project( v_iID, i ) );
	}
      }
    }

    // Note that the set of src's in reachablePaths is equal to the separator
    // of a_i, and therefore the set of values to be used in the UTILtable.
    for( auto& kv : reachablePaths ) // <src, dst, interface>
    {
      size_t a_sID = kv.first.first;  // agent src
      size_t a_dID = kv.first.second; // agent dst
      size_t v_sID = reachablePaths_vars[ kv.first ].first; // var src
      size_t v_dID = reachablePaths_vars[ kv.first ].second; // var dst
      Agent* a_j = kv.second;	// agent to traverse 
      size_t a_jID = a_j->getID();
      size_t v_jID = a_j->getBoundaryVariable( 0 ).getID();

      // cout << "\t Analyzing Reachable PATH[ " << a_sID << " -> " 
      // 	   << a_dID << "] via " << a_jID << endl;

      CVMatrix M_si;		// a_s -> a_i
      // Path starts at this agent, hence send CVM identity.
      if( a_sID == a_iID )
      {

	//cout << "\t a_s = a_i - set Matrix ID:\n";  

	// Prepare Identity Matrix ( path i->i )
	M_si.initialize( v_sID, v_sID );
	M_si.setIdentity( );

      }
      else
      {
	// cout << "\t a_s != a_i - read recv Message with src:\n";  

	// Retrieve M_sp from message received
	CVMatrix* M_sp = getCVMfrom_PR_downMsg( *PRmsg, v_sID );

	// M_sp->dump();

	// Join Matrices to get reachable paths 's' -> 'i'
	M_si.copy( M_pi ); // B
	M_si.join( *M_sp, v_sID, v_iID ); // M_sp x M_pi

	// cout << "\t M_sp x M_si = \n";
	// M_si.dump();

	// Message reach destination.
	if( a_dID == a_iID )
	{
	  // cout << "\t a_d = a_i - reached Destination (merging ancestors)\n";

	  // For all ancestors, p, retrieve the direct M_pi and
	  // the indirect (from message) M_pi. Merge them and
	  // join them into UTIL Table
	  for( auto &c : ancestorConstraints[ a_sID ] )
	  {
	    CVMatrix& CVM_c = *g_constraint2cvm[ c->getID() ];
	    
	    // cout << "\t" << c->getID() << endl;
	    // CVM_c.dump();

	    // Merge CVM from the same source.
	    M_si.merge( CVM_c );
	  }
	  // M_si.dump();
	}

	// Need to project out current variable ( v_iID )   ----> NO!
	int lb = M_si.getLB( v_iID );
	int ub = M_si.getUB( v_iID );
	for( int i=lb; i<=ub; i++ )
	{
	  ai_UTILvaluesToJoin[ i ].push_back( M_si.project( v_iID, i ) );
	}
	// TODO: check if lb>ub otherwise no need to insert v_sID --> FAIL ?
	msgUTIL.insertVar( v_sID );
	varID2UtilQuery[ v_sID ] = msgUTIL.nbTableVariables() - 1;

      }
      
      // CVM not at destination -> continue with a_i's children
      if( a_dID != a_iID ) msgPR_successors[ a_jID ].insertCVM( M_si );

    } // FOR-EACH reachable path (end)


    // Send msg PR to all successors
    if( not isLeaf )
    {
      for( auto& kv : msgPR_successors )
      {
	openMailbox( "PR-down" ).send( kv.second );
	g_scheduler->aQueue.push( kv.second.getDestination() );      
      }
    }

    // cout << "CREATE UTIL TABLE:\n";

    // Create UTILtable:
    int lb = g_Variables[v_iID]->getDomain().lb_pos();
    int ub = g_Variables[v_iID]->getDomain().ub_pos();
    // Perform a DFS 
    if( not isRoot )
    {
      for( int i=lb; i<=ub; i++ )
      {
	// also pass all the M_si here - actually save them in an array
	// of Matrices in the class and then work on them
	createUtilTable( ai_UTILvaluesToJoin[ i ], i );
      }
    }
    else
    {
      // Root only has one value combination( its own )
      vector<int> key(1, -1);
      for( int i=lb; i<=ub; i++ ) 
      {
	msgUTIL.insert( key, make_pair( i, 0 ) );
      }
    }

    // msgUTIL.dump();
    // getchar();

    // AC phase terminated
    activeHandler[ "AC-down" ] = false;
    activeHandler[ "AC-up" ]   = false;
    // PR-down phase terminate
    activeHandler[ "PR-down" ] = false;
    openMailbox( "PR-down" ).reset(); // reset queue
    activeHandler[ "UTIL" ] = true;
  }
  else {
    // reschedule current agent to wait all messages
    g_scheduler->aQueue.push( *owner );
  }

}


// VERY INEFFICIENT:
// Tutto cio' puo' esser fatto un girno in meno -- per ogni value combination
// (tmp) devo semplicemente popolare UtilTable[tmp] con i possibili valori 
// ammessi e non calcolare i percorsi d'accapo
// Costi possono esser calcolati while going down in the search-tree -->
// can also do pruning this way (but a need a TRAIL-STACK-like structure)
void RDPOPprotocol::createUtilTable( std::vector< std::vector< int > >& values, 
				     int v  )
{
  int lev = 0;
  size_t limit = values.size();
  vector< int > tmp( limit, 0 );
  vector< int > idx( limit, 0 );
  pair<int, cost_type> ins(v, 0);

  while( lev >= 0 )
  {
    while( idx[ lev ] < values[ lev ].size() )
    {
      tmp[ lev ] = values[ lev ][ idx[ lev ] ];
      idx[ lev ]++;

      // Need to check if value is admissible, from connectivity matrix.
      // all and only contraint reachability matrices paths needed!
      
      lev++;
      if( lev == limit )
      {
	// process solution:
	ins.second = computeCost( tmp,  v );
	if( isFinite( ins.second) )
	  msgUTIL.insert( tmp, ins );

	lev--;
      }
    }
    idx[ lev ] = 0;
    lev--;
  }
}


// TODO:: ALSO CHECK HARD CONSTRAINTS ??
cost_type RDPOPprotocol::computeCost( vector<int>& others_val, int curr_var_val )
{
  cost_type cost = 0;
  int sidx;

  // Check cost of local constraints
  for( int i=0; i<localConstraints.size(); i++ )
  {
    ExtSoftConstraint& c = *localConstraints[ i ];
    for( int a=0; a<c.getArity(); a++ )
    {
      sidx = varID2UtilQuery[ c.getScopeVar( a ).getID() ];
      constrQuery[ a ] = ( sidx != -1 ) ? others_val[ sidx ] : curr_var_val;
    }
    cost_type lc = c.getCost( constrQuery );
    if( !isFinite( lc ) ) { return lc; }
    cost += lc;
  }


  // Check Soft Constraints and include Cost of ancestors with boundary variables
  for( int s=0; s<softConstrainedAncestorVars.size(); s++ )
  {
    for( int j=0; j<ancestorSoftConstraints[ s ].size(); j++ )
    {
      ExtSoftConstraint& c = *ancestorSoftConstraints[ s ][ j ];
      
      for( int a=0; a<c.getArity(); a++ )
      {
	sidx = varID2UtilQuery[ c.getScopeVar( a ).getID() ];
	constrQuery[ a ] = ( sidx != -1 ) ? others_val[ sidx ] : curr_var_val;
      }
      cost_type lc = c.getCost( constrQuery );
      if( !isFinite( lc ) ) { return lc; }
      cost += lc;
    }
  }
  return cost;
}



void RDPOPprotocol::UTILmessageHandler()
{
  // Each agent waits to receive all UTIL messages from its children.
  if( receivedAllMessages( "UTIL" ) )
  {
    // cout << "************************\n";
    // cout << " UTIL msg " << owner->getName() << endl;
    // cout << "************************\n";
    if( isLeaf )
    {
      // Extract Best Cost from UTIL table
      // Already done in construction
    }
    else{
      size_t nb_msgs = openMailbox( "UTIL" ).size();

      vector<UTILMessage*> utilMsgRecv( nb_msgs );
      // used to map vars of msg received to vars of ai UTIL TABLE
      vector< vector<int> > utilMsgRecv_varsMap( nb_msgs ); 
      // used to store the values projected from ai's UTIL message to 
      // UTIL message received
      vector< vector<int> > utilMsgRecv_valsProj( nb_msgs ); 

      // Collect the message received, and popolate the DS above. 
      int k=0;
      while( openMailbox( "UTIL" ).size() > 0 )
      {
	UTILMessage* msg = (UTILMessage*)openMailbox( "UTIL" ).read();
	utilMsgRecv[ k ] = msg ;

	// cout << "Recv message: ";
	// msg->dump();
	// getchar();
	
	utilMsgRecv_varsMap[ k ] = msgUTIL.mapVars2Vars( msg->getVarsID() );

	// cout << "utilMsgRecv_varsMap: \n";
	// for( int i=0; i<utilMsgRecv_varsMap[ k ].size(); i++ )
	//   cout << utilMsgRecv_varsMap[ k ][ i ] << " ";
	// cout << endl;
	// getchar();

	size_t nb_vars = utilMsgRecv_varsMap[ k ].size();
	utilMsgRecv_valsProj[ k ].resize( nb_vars );
	k++;
      }
      
      // msgUTIL.dump();
      // getchar();


      // Join Incoming Messages and Project over local variables
      // For each combination of values stored in ai.UTILmsg.TABLE(.first)
      // retrieve costs of corresponding combinations (if available) in 
      // received messages.
      msgUTIL.setTraversable();
      do {
	cost_type cost = 0;

	// Project current value comibnation over the received Tables and get cost. 
	for( int msg_i=0; msg_i<utilMsgRecv.size(); msg_i++ )
	{
	  // Read the values of ai's table, associated to variables
	  // of i-th message UTIL received.
	  msgUTIL.extract( utilMsgRecv_valsProj[ msg_i ], 
			   utilMsgRecv_varsMap[ msg_i ] );

	  // cout << "utilMsgRecv_valsProj: from MSG#" << msg_i << ": ";
	  // for( int j=0; j<utilMsgRecv_valsProj[ msg_i ].size(); j++ )
	  //   cout << utilMsgRecv_valsProj[ msg_i ][ j ] << " ";

	  cost_type rcv_cb 
	    = utilMsgRecv[ msg_i ]->getCost( utilMsgRecv_valsProj[ msg_i ] );

	  // cout << " -> " << rcv_cb  << endl;
	  //getchar();

	  if( not isFinite( rcv_cb ) ) { 
	    cost = worstValue(); break;
	  }
	  cost += rcv_cb;
	}

	msgUTIL.addLastTraversedCost( cost );
	
      } while( msgUTIL.advance() );
            
    }// not a leaf


    // Send message to parent
    if( not isRoot ) 
    {
      openMailbox( "UTIL" ).send( msgUTIL );
      g_scheduler->aQueue.push( msgUTIL.getDestination() );
    }
    else{
      g_stats.setBestCost( msgUTIL.getBestCost() );
      // Start Value propagation phase
    }

    // cout << "Agent " << owner->getName() << " is done with UTIL pahse: \n";
    // msgUTIL.dump();
    // getchar();

    activeHandler[ "UTIL" ]   = false;
    activeHandler[ "VALUE" ]  = true;
  }
  else {
    // reschedule current agent to wait all messages
    g_scheduler->aQueue.push( *owner );
  }

}


// Send msgs to only those variables that have changed.
void RDPOPprotocol::run()
{
  size_t aID = owner->getID();
  // cout << "agent: " << owner->getName() << " running protocol" << endl;     
  // g_scheduler->dump();
  // getchar();

  if( activeHandler[ "PR-init"] )
  {
    g_stats.setTimer( t_comm, aID );
    PR_init_messageHandler();
    g_stats.stopwatch( t_comm, aID );
  }

  if( not activeHandler[ "PR-init" ] )
  {

    if( activeHandler[ "AC-up" ] ) {
      g_stats.setTimer( t_comm, aID );
      AC_up_messageHandler();
      g_stats.stopwatch( t_comm, aID );
    }
    
    if( activeHandler[ "AC-down" ] ) {
      g_stats.setTimer( t_comm, aID );
      AC_down_messageHandler();
      g_stats.stopwatch( t_comm, aID );
    }

    if( (not activeHandler[ "AC-up" ] ) and
      activeHandler[ "PR-down" ] ) {
      g_stats.setTimer( t_comm, aID );
      PR_down_messageHandler();
      g_stats.stopwatch( t_comm, aID );
    }
  }

  if( activeHandler[ "UTIL" ] ) {
    g_stats.setTimer( t_search_local, aID );
    UTILmessageHandler();
    g_stats.stopwatch( t_search_local, aID );
  }

  if( activeHandler[ "VALUE" ] ) {
    size_t max_size = 1;
    vector<size_t> vars = msgUTIL.getVarsID();
    for( int i=0; i<vars.size(); i++ )
    {
      max_size *= g_Variables[ vars[ i ] ]->getDomain().size();
    }
    // include it or not??
    max_size *= owner->getBoundaryVariable( 0 ).getDomain().size();
    //--

    // g_stats.saveMsgSize( msgUTIL.size(), aID );
    g_stats.saveMsgSize( msgUTIL.completeSize(), aID );
    g_stats.saveMsgSizeDPOP( max_size, aID );

    activeHandler[ "VALUE" ] = false;
  }

}

void RDPOPprotocol::terminate()
{
  cout << "The problem is unfeasable\n";
  g_stats.dump();
  exit(1);
  // @todo
}
