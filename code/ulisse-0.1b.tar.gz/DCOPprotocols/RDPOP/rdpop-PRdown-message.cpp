#include "rdpop-PRdown-message.hh"
#include "search-solution.hh"
#include "agent.hh"

using namespace DPOP;
using namespace std;


PR_downMessage::PR_downMessage( )
{
  // nothing
}

PR_downMessage::PR_downMessage( Agent& _src, Agent& _dst )
{
  src  = &_src;
  dest = &_dst;
}


PR_downMessage::~PR_downMessage()
{ 
  // nothing
}


PR_downMessage::PR_downMessage( const PR_downMessage& other )
{
  src = other.src;
  dest = other.dest;
}


PR_downMessage& PR_downMessage::operator=( const PR_downMessage& other )
{
  if( this != &other )
  { 
    src = other.src;
    dest = other.dest;
  }
  return *this;
}

void PR_downMessage::reset()
{
  // nothing
}


void PR_downMessage::dump()
{
  cout << "Message type: PR_down ";
  if( src and dest )
    cout << "  Src: " << src->getName()
	 << "  Dst: " << dest->getName() << endl;
  cout << "Size: " << size() << endl;
}
