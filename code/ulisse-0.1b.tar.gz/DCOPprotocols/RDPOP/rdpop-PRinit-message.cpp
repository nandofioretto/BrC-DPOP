#include "rdpop-PRinit-message.hh"
#include "search-solution.hh"
#include "agent.hh"

using namespace DPOP;
using namespace std;


PR_initMessage::PR_initMessage( )
{
  src = 0;
  dest = 0;
  // nothing
}

PR_initMessage::PR_initMessage( Agent& _src, Agent& _dst )
{
  src  = &_src;
  dest = &_dst;
}


PR_initMessage::~PR_initMessage()
{ 
  // nothing
}


PR_initMessage::PR_initMessage( const PR_initMessage& other )
{
  paths = other.paths;
  src = other.src;
  dest = other.dest;
}


PR_initMessage& PR_initMessage::operator=( const PR_initMessage& other )
{
  if( this != &other )
  { 
    paths = other.paths;
    src = other.src;
    dest = other.dest;

  }
  return *this;
}

void PR_initMessage::reset()
{
  // nothing
  paths.clear();
}


void PR_initMessage::dump()
{
  cout << "Message type: PR_init ";
  if( src and dest )
    cout << "  Src: " << src->getName()
	 << "  Dst: " << dest->getName() << endl;
  for( int i=0; i<paths.size(); i++ )
  {
    cout << "aID_" << paths[ i ].first 
	 << " -> aID_" << paths[ i ].second << endl; 
  }
}
