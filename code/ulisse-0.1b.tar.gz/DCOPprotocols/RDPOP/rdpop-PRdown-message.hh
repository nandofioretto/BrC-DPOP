#ifndef _ULISSE_RDPOP_PR_DOWN_MESSAGE_HH_
#define _ULISSE_RDPOP_PR_DOWN_MESSAGE_HH_

#include "globals.hh"
#include "message.hh"
#include "cv-matrix.hh"

class Agent;

namespace DPOP {
  
  class PR_downMessage : public Message
  {
  public:
    /**
     * Default Constructor
     */
    PR_downMessage();

    /**
     * Constructor: initalizes AC_downmessage according to var v
     */
    PR_downMessage( Agent& _src, Agent& _dst );
    
    /**
     * Copy Constructor
     */
    PR_downMessage( const PR_downMessage& other );
    

    /**
     * Default Destructor
     */
    ~PR_downMessage();
    
    /*
     * Operation= on curr_state
     */
    PR_downMessage& operator=( const PR_downMessage& other );

    /**
     * The message type.
     */
    virtual std::string getType() const
    {
      return "PR-down";
    }

    /**
     * Reset message content (no touch header).
     */
    virtual void reset();

    /**
     * Prints AC_down message on screen.
     */
    virtual void dump();

    /**
     * Returns the i-th CVM contained in this message.
     */
    CVMatrix& getCVM( int i )
    {
      return CVMs[ i ];
    }

    /**
     * Inserts a new constraint value matrix into the message.
     */
    void insertCVM( CVMatrix& CVM )
    {
      CVMs.push_back( CVM );
    }

    /**
     * If no CVM is carried by this message 
     */
    bool isEmpty()
    {
      return ( CVMs.size() == 0 );
    }

    size_t size()
    {
      return CVMs.size();
    }

  private:
    // The list of Constraint value matrices carried by the message.
    std::vector< CVMatrix > CVMs;
    // The source 
    std::vector< var_int* > CVMs_varSrc;
  };
  
};

#endif
