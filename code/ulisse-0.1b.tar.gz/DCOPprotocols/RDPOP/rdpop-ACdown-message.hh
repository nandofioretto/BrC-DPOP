#ifndef _ULISSE_RDPOP_AC_DOWN_MESSAGE_HH_
#define _ULISSE_RDPOP_AC_DOWN_MESSAGE_HH_

#include "globals.hh"
#include "message.hh"

class var_int;
class Constraint;
class Agent;

namespace DPOP {
  
  class AC_downMessage : public Message
  {
  public:
    /**
     * Default Constructor
     */
    AC_downMessage();

    /**
     * Constructor: initalizes AC_downmessage according to var v
     */
    AC_downMessage( Agent& _src, Agent& _dst, var_int& v );
    
    /**
     * Copy Constructor
     */
    AC_downMessage( const AC_downMessage& other );
    

    /**
     * Default Destructor
     */
    ~AC_downMessage();
    
    /*
     * Operation= on curr_state
     */
    AC_downMessage& operator=( const AC_downMessage& other );

    /**
     * The message type.
     */
    virtual std::string getType() const
    {
      return "AC-down";
    }

    /**
     * Reset message content (no touch header).
     */
    virtual void reset();

    /**
     * Prints AC_down message on screen.
     */
    virtual void dump();

    /**
     * Set the variable associated with this message.
     */
    void setVariable( var_int& var )
    {
      variable = &var;
    }

    /**
     * Get the variable associated with this message.
     */
    var_int& getVariable()
    {
      return *variable;
    }
    
  private:
    var_int* variable; // @todo: we should only encode its domain here 
  };
  
};
#endif
