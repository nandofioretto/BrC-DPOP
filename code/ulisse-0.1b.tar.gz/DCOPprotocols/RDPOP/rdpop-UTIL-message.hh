#ifndef _ULISSE_RDPOP_UTIL_MESSAGE_HH_
#define _ULISSE_RDPOP_UTIL_MESSAGE_HH_

#include "globals.hh"
#include "message.hh"

class var_int;
class Constraint;
class Agent;

namespace DPOP {

  typedef std::pair<int,cost_type> valCost;
  // < vector of valCosts, index of the best valCost >
  //typedef std::pair<std::vector<valCost>, int> bestValsCosts;
  typedef std::pair<std::vector<valCost>, cost_type> bestValsCosts;
  
  class UTILMessage : public Message
  {
  public:
    /**
     * Default Constructor
     */
    UTILMessage();

    /**
     * Constructor: initalizes UTILmessage according to var v
     */
    UTILMessage( Agent& _src, Agent& _dst );
    
    /**
     * Copy Constructor
     */
    UTILMessage( const UTILMessage& other );
    

    /**
     * Default Destructor
     */
    ~UTILMessage();
    
    /*
     * Operation= on curr_state
     */
    UTILMessage& operator=( const UTILMessage& other );

    /**
     * The message type.
     */
    virtual std::string getType() const
    {
      return "UTIL";
    }

    /**
     * Reset message content (no touch header).
     */
    virtual void reset();

    /**
     * Prints UTIL message on screen.
     */
    virtual void dump();
    
    void insert( std::vector<int> sep_comb, valCost this_val_cost )
    {
      UTILtable[ sep_comb ].first.push_back( this_val_cost );
      if( UTILtable[ sep_comb ].first.size() == 1)
	// PATCH!! modify the SAT value so to let it work correctly!
	UTILtable[ sep_comb ].second = this_val_cost.second;
      else {
	UTILtable[ sep_comb ].second = 
	  getBestValue( this_val_cost.second, UTILtable[ sep_comb ].second );
      }
    }
    
    void insertVar( size_t varID )
    {
      UTILtable_vars.push_back( varID );
    }

    /**
     * Returns the VarIDs of the variables involved in the util table.
     */
    std::vector< size_t >& getVarsID() 
    {
      return UTILtable_vars;
    }

    /**
     * The number of variables involved in the UTIL table
     */
    size_t nbTableVariables()
    {
      return UTILtable_vars.size();
    }

    /**
     * Set the iterator to first element of the list,
     * and the index for the best val choices to 0.
     */
    void setTraversable()
    {
      traverseTable = UTILtable.begin();
      traverseBestVals = 0;
    }

    /**
     * Increment the iterator of one position and returns whether the 
     * whole table has ben read.
     */
    bool advance()
    {
      ++traverseBestVals;
      if( traverseBestVals >= traverseTable->second.first.size() ) {
	++traverseTable;
	traverseBestVals = 0;
      }
      return (traverseTable != UTILtable.end() );
    }

    /**
     * Given a vector of vIDs, maps the corresponding index of the variables in 
     * UTILtable_vars.
     * The local variable of ai which is projected out is assigned a special idx:-1.
     */
    std::vector<int> mapVars2Vars( std::vector<size_t> vars );

    /**
     * Project the current value combination of the UTILtable (being traversed by 
     * the iterator traverseTable) so to contain only the values associated to the 
     * variables in 'vars'.
     * @note: vars *must* be a subset of UTILtable_vars, and it actually contains 
     *        the indexes  of the variables to be extracted.
     * @note: the results are saved in 'vals', which *must* be of the same size 
     *        as 'vars'
     */
    void extract( std::vector<int>& vals, std::vector<int> varsIdx);


    /**
     * Get the best cost associated to the tuple 'vals'. 
     */
    cost_type getCost( std::vector<int>& vals )
    {
      uIt = UTILtable.find( vals );
      if( uIt == UTILtable.end() ) return worstValue();
      return uIt->second.second;
    }

    /**
     * Set the cost associated to the values being hold by traverseTable and
     * traverseBestVals
     */
    void addLastTraversedCost( cost_type cost );

    /**
     * Returns the best cost
     */
    cost_type getBestCost();

    /**
     * Returns the TABLE size
     */
    size_t size()
    {
      return UTILtable.size();
    }

    /**
     * Returns the TABLE size including all the entries of the UTILtable,
     * before the projection operation.
     * Will count which elements on current agent domain can reach with other. 
     */
    size_t completeSizeBeforeProjection();

    /**
     * Returns the TABLE size including all the entries of the UTILtable,
     * after the projection operation.
     */
    size_t completeSizeAfterProjection();

    /**
     * Size accounts for only the utils vector and the number of elments 
     * of this agent to be checked. 
     */
    size_t utilVectorSizeBeforeProjection();

    /**
     * Size accounts for only the utils vector. 
     */
    size_t utilVectorSizeAfterProjection();
    
    
  private:
    // These are the variables associated to each value combination of the UTILtable
    // except the local variable of the sender agent.
    std::vector< size_t > UTILtable_vars;
    // This is the local variable of the sender agent.
    size_t projVar; // TOSET

    // The first element is the value combination for all the variables excluding 
    // a_i, the second is the set of active elements of a_i, for that particular 
    // combination with the associated cost
    std::map< std::vector<int>, bestValsCosts > UTILtable;

    std::map< std::vector<int>, bestValsCosts >::iterator traverseTable;
    int traverseBestVals;
    std::map< std::vector<int>, bestValsCosts >::iterator uIt;

  };

};
#endif
