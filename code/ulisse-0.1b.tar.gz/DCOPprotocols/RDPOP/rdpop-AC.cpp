#include "rdpop-AC.hh"
#include "linear-ordering.hh"
#include "pseudo-node.hh"
#include "search-solution.hh"
#include "agent.hh"
#include "var_int.hh"
#include "constraint.hh"
#include "ext-soft-constraint.hh"
#include "int-hard-constraint.hh"
#include "trailstack.hh"
#include "trail-variable.hh"

using namespace std;
using namespace ExtSearch;

//#define DBG

RDPOPsearch::RDPOPsearch( )
  : continuation( 0 ), currLevel( 0 )
{ 
  propagateBeforeSearch = true;
}


RDPOPsearch::~RDPOPsearch( )
{ }


//@todo:
// For each variable vi in scope, save the restriction of the 
// boundary_constraints to vi. These are the only constraints 
// to check during search.
void RDPOPsearch::initialize( Agent& a )
{
  owner = &a;
  // Initializes the scope and solutions of the search
  initSearchSettings();
  // popolate the SoftConstraint vector
  initSoftConstraints();
  // popolate the HardConstraint vector
  initHardConstraints();

  // 'hardConstraints' contains now all constraints whose scope contains exclusively 
  //  boundary variables or boundary variables + variables with some ancestors.
  //  Now we need to add constraints of boundary with local variables as well.
  for( auto c : owner->getLocalConstraints() )
  {
    for( auto v : owner->getBoundaryVariables() )
    {
      if( c->hasInScope( *v ) ) {
	if( c->getType() == intHard ) {
	  if( find( hardConstraints.begin(), hardConstraints.end(), c ) == 
	      hardConstraints.end() ) { // not present
	    hardConstraints.push_back( (IntHardConstraint*)(c) );

	    for( int s=0; s<c->getArity(); s++ ) {
	      if( find( varsIn_hardConstraints.begin(), varsIn_hardConstraints.end(),
			&c->getScopeVar( s ) ) == varsIn_hardConstraints.end() )
		varsIn_hardConstraints.push_back( &c->getScopeVar( s ) );
	    }
	  }
	}
	break;
      }
    }
  }

  // init the constraint store
  constraintStore.initialize( hardConstraints, varsIn_hardConstraints, &trailstack );

  // init the constraint value matrices
  // only for the constraints involving exclusiverly boundary variables and 
  // ancestors constraints
  // both hard and soft constraints here
  // TODO-Mar-19
  
  continuation.resize( scope.size(), 0 );

  // cout << "Hard constraints in RDPOP-AC search of " 
  //      << owner->getName() << endl;
  // for( auto c : hardConstraints )
  //   c->dump();
  // cout << endl;

}


bool RDPOPsearch::initCVM()
{
  // insert all constraints in the constraint store
  for( auto& va : varsIn_hardConstraints ) {
    constraintStore.enqueueVarChanged( *va );
    va->resetJustChangedFlag();
  }
  
  if( not constraintStore.initCVM() )
  {
    searchEnded = true;	 // Flag search termination
    return false;	 // Propagation failed
  }
  return true;
}



// one cycle of AC4 to initialize all the CVMs and
// to effectly reduce the domains without any labeling
bool RDPOPsearch::reduce()
{
  searchEnded = false;
  // check wheter the scope of the search is empty
  if( scope.empty() ) { searchEnded = true; return true; }
  // do not check for propagateBeforeSearch flag as this *has* to be done.

  // insert all constraints in the constraint store
  for( auto& va : varsIn_hardConstraints ) {
    constraintStore.enqueueVarChanged( *va );
    va->resetJustChangedFlag();
  }

  if( not constraintStore.AC4_CVM( ) )
  {
    searchEnded = true;	 // Flag search termination
    return false;	 // Propagation failed
  }

  // for( auto va : varsIn_hardConstraints ) {
  //   if( va->isJustChanged() ) cout << va->getName() << " just Changed****\n";
  // }

  return true;
}

bool RDPOPsearch::nextSolution()
{
  searchEnded = false;
  // check wheter the scope of the search is empty
  if( scope.empty() ) { searchEnded = true; return true; }

  // Propoagate all HARD constraints listed in the ancestors
  // at firt time the search is (re)started
  if( propagateBeforeSearch and currLevel == 0 )
  {
    for( auto va : varsIn_ancestorsHardConstraints ) {
      constraintStore.signalVarChanged( *va );
    }
    if( not constraintStore.iSolveFix() )
    {

      trailstack.backtrack( 0 ); // initial trail size will always be 0
      searchEnded = true;	 // Flag search termination
      return false;		 // Propagation failed
    }
  }
 
  curr_solution.reset();
  
  bool find_sol = searchStep();

  // Retore original variable states (before first Propagation) 
  // when the search is ended.
  if( searchEnded ) {
    trailstack.backtrack( 0 );
  }

  return find_sol;
}


// @todo
bool RDPOPsearch::bestSolution() 
{
  printWarningMessage( "SBBsearch::bestSolution()" );
  return false;
}


// @todo
bool RDPOPsearch::allSolutions() 
{
  printWarningMessage( "SBBsearch::allSolutions()" );
  return false;
}


bool RDPOPsearch::searchStep( )
{
  // Resuming the search from a previous call / a solution was found.
  if( currLevel == scope.size() )
  {
    trailstack.backtrack( continuation[ --currLevel ] );
  }

  while( currLevel >= 0 )
  {
    while( labeling() )
    {
      if( constraintStore.iSolveFix() )
      {
	// @todo -  Compute partial cost and check bounds. 
	currLevel++;
	if( currLevel == scope.size() ) {
	  copySolution();
	  return processSolution();
	}
      }
      else {
      	trailstack.backtrack( continuation[ currLevel ] );
      }
    }
    currLevel--;
    if( currLevel >= 0 ) {
      trailstack.backtrack( continuation[ currLevel ] ); 
    }
  }
  searchEnded = true;		// Flag search termination
  currLevel = 0; 		// Reset currLevel counter
  return false; 		// All domains are now emtpy
}


bool RDPOPsearch::labeling()
{
  var_int& v = getVariable( currLevel );
  if( v.labeling() ) 
  {
    // all the changes in the var states need to be done after this statement.
    continuation[ currLevel ] = trailstack.size();
    trailstack.trailVariable( v );

    // Set domain of v as singleton (FAST - acting on bounds only)
    v.setAssigned();
    constraintStore.signalVarChanged( v );
    return true;
  }
  return false;
}


void RDPOPsearch::copySolution( )
{
  for( int i=0; i<scope.size(); i++ )
  {
    //    curr_solution[ i ] = getVariable( i ).getValue();
    curr_solution[ i ] = getVariable( i ).getLabel();
  }
}


void RDPOPsearch::dump() const
{
  cout << "External Search (RDPOP-Search)::scope of the Search: \n";
  for( int i=0; i<scope.size(); i++ )
  {
    getVariable( i ).dump();
  }
}
