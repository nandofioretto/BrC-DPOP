#include "rdpop-UTIL-message.hh"
#include "agent.hh"
#include "var_int.hh"

using namespace DPOP;
using namespace std;


UTILMessage::UTILMessage( )
{
  // nothing
}

UTILMessage::UTILMessage( Agent& _src, Agent& _dst )
{
  src  = &_src;
  dest = &_dst;
}


UTILMessage::~UTILMessage()
{ 
  // nothing
}


UTILMessage::UTILMessage( const UTILMessage& other )
{
  src = other.src;
  dest = other.dest;
  UTILtable_vars = other.UTILtable_vars;
  UTILtable = other.UTILtable;
}


UTILMessage& UTILMessage::operator=( const UTILMessage& other )
{
  if( this != &other )
  { 
    src = other.src;
    dest = other.dest;
    UTILtable_vars = other.UTILtable_vars;
    UTILtable = other.UTILtable;
  }
  return *this;
}

void UTILMessage::reset()
{
  // nothing
}


std::vector<int> UTILMessage::mapVars2Vars( std::vector<size_t> vars )
{
  std::vector<int> map( vars.size(), -1 );

  for( int i=0; i<vars.size(); i++ ) {
    for( int j=0; j<UTILtable_vars.size(); j++ ) {
      if( vars[ i ] == UTILtable_vars[ j ] ) {
	map[ i ] = j;
	break;
      }
    }
  }
  return map;
}


void UTILMessage::extract( std::vector<int>& vals, std::vector<int> varsIdx)
{
  if( traverseTable == UTILtable.end() ) {
    cout << "The problem is UNSATISFIABLE\n";
    exit(1);
  }

  for( int i=0; i<varsIdx.size(); i++ ) {
    if( varsIdx[ i ] == -1 ){ // special code for projected local variable 
      vals[ i ] = traverseTable->second.first[ traverseBestVals ].first;
    }else{
      vals[ i ] = traverseTable->first[ varsIdx[ i ] ];
    }
  }
}


void UTILMessage::addLastTraversedCost( cost_type cost )
{
  // If cost is not finite, update best and signal infinite
  cost_type c_trav_old = traverseTable->second.first[ traverseBestVals ].second;
  cost_type& c_trav = traverseTable->second.first[ traverseBestVals ].second;
  cost_type& c_best = traverseTable->second.second;

  if( not isFinite( cost ) ) 
  { 
   c_trav = cost;
   // If previous val was best, update new best
   if( c_trav_old == c_best ) 
   {
     c_best = cost;
     for( int i=0; i<traverseTable->second.first.size(); i++ )
       c_best = getBestValue( traverseTable->second.first[ i ].second, c_best );
    }
  }
  else 
  {
    c_trav += cost;
    c_best = getBestValue( c_trav, c_best );
  }
}


cost_type UTILMessage::getBestCost()
{
  cost_type best = worstValue();
  setTraversable();
  do {
    best = getBestValue( traverseTable->second.first[ traverseBestVals ].second, 
			 best );
  } while( advance() );
  return best;
}


size_t UTILMessage::completeSizeBeforeProjection()
{
  size_t size = 0;
  for( auto& kv : UTILtable ) {
    for( int i=0; i<kv.second.first.size(); i++ ) { 
      // count it if particular element is finite
      size += isFinite( kv.second.first[ i ].second ); 
    }
    if( isFinite( kv.second.second ) )
      size += kv.first.size();
  }
  return size;
}


size_t UTILMessage::completeSizeAfterProjection()
{
  size_t size = 0;
  for( auto& kv : UTILtable ) {
    if( isFinite( kv.second.second ) )
      size += kv.first.size();
  }
  return size;
}

size_t UTILMessage::utilVectorSizeBeforeProjection()
{
  size_t size = 0;
  for( auto& kv : UTILtable ) {
    for( int i=0; i<kv.second.first.size(); i++ ) {
      // count it if particular element is finite
      size += isFinite( kv.second.first[ i ].second ); 
    }
    size += isFinite( kv.second.second );
  }
  return size;  
}

size_t UTILMessage::utilVectorSizeAfterProjection()
{
  size_t size = 0;
  for( auto& kv : UTILtable ) {
    size += isFinite( kv.second.second );
  }
  return size;  
}


void UTILMessage::dump()
{
  cout << "Message type: UTIL ";
  if( src and dest )
    cout << "  Src: " << src->getName()
	 << "  Dst: " << dest->getName() << endl;

  for( int i=0; i< UTILtable_vars.size(); i++ )
    cout << "v_"<<UTILtable_vars[ i ] << " ";
  cout << endl;

  for( auto& kv : UTILtable )
  {
    for( int i=0; i< kv.first.size(); i++ )
    {
      cout << kv.first[ i ] << " ";
    }
    cout << " -> ";
    for( int j=0; j<kv.second.first.size(); j++ ) 
    {
      cout << kv.second.first[ j ].first;
      cost_type& cost = kv.second.first[ j ].second;
      if( isFinite( cost ) )
	cout << " (" << cost << ") ";
      else
	cout << " (X) ";
    }
    cost_type& cost = kv.second.second;
    if( isFinite( cost ) )
      cout << " / " << cost << endl;
    else
      cout << "X" << endl;
  }

}
