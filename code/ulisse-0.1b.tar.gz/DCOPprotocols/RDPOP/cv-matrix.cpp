#include "cv-matrix.hh"
#include "globals.hh"
#include "constraint.hh"
#include "var_int.hh"

using namespace std;

CVMatrix::CVMatrix()
  : edges( 0 ), constraint( 0 ), dom_vRow( 0 ), dom_vCol( 0 )
{
  tmp = new bool*[ g_maxDomainSize ];
  for( int i=0; i<g_maxDomainSize; i++ ) {
    tmp[ i ] = new bool[ g_maxDomainSize ];
  }

}


CVMatrix::~CVMatrix()
{
  // for( int i=0; i<g_maxDomainSize; i++ ) {
  //   delete[] tmp[ i ];
  //   delete[] edges[ i ];
  // }
  // delete[] edges;
  // delete[] tmp;
}


CVMatrix::CVMatrix( const CVMatrix& other )
{
  constraint = other.constraint;
  vRowID = other.vRowID;
  vColID = other.vColID;
  bounds = other.bounds;
  dom_vRow = other.dom_vRow;
  dom_vCol = other.dom_vCol;
  
  edges = new bool*[ g_maxDomainSize/*dom_vRow*/ ];
  for( int i=0; i<g_maxDomainSize; i++ ) 
  {
    edges[ i ] = new bool[ g_maxDomainSize/*dom_vCol*/ ];
    memcpy( edges[ i ], other.edges[ i ], dom_vCol );
  }
}


void CVMatrix::copy( const CVMatrix& other )
{
  constraint = other.constraint;
  vRowID = other.vRowID;
  vColID = other.vColID;
  bounds = other.bounds;
  dom_vRow = other.dom_vRow;
  dom_vCol = other.dom_vCol;
  
  edges = new bool*[ g_maxDomainSize/*dom_vRow*/ ];
  for( int i=0; i<g_maxDomainSize; i++ ) 
  {
    edges[ i ] = new bool[ g_maxDomainSize/*dom_vCol*/ ];
    memcpy( edges[ i ], other.edges[ i ], dom_vCol );
  }
}


void CVMatrix::initialize( Constraint& con )
{
  if ( con.getArity() < 2 ) return;
  assert( con.getArity() == 2 );
  constraint = &con;
  g_constraint2cvm[ con.getID() ] = this;

  var_int& vr = con.getScopeVar( 0 );
  var_int& vc = con.getScopeVar( 1 );
  dom_vRow = vr.getDomain().size();
  dom_vCol = vc.getDomain().size();

  vRowID = vr.getID();
  vColID = vc.getID();

  // init bounds
  bounds[ vRowID ] = make_pair( vr.getDomain().lb_pos(), vr.getDomain().ub_pos() );
  bounds[ vColID ] = make_pair( vc.getDomain().lb_pos(), vc.getDomain().ub_pos() );

  // Create edge vectors and initialize it to TRUE
  edges = new bool*[ g_maxDomainSize/*dom_vRow*/ ];
  for( int i=0; i<g_maxDomainSize; i++ ) 
  {
    edges[ i ] = new bool[ g_maxDomainSize/*dom_vCol*/ ];
    memset( edges[ i ], 1, dom_vCol );
  }
}


void CVMatrix::initialize( size_t v_rowID, size_t v_colID )
{
  vRowID = v_rowID;
  vColID = v_colID;

  var_int& vr = *g_Variables[ v_rowID ];
  var_int& vc = *g_Variables[ v_colID ];
  
  dom_vRow = vr.getDomain().size();
  dom_vCol = vc.getDomain().size();
  bounds[ vRowID ] = make_pair( vr.getDomain().lb_pos(), vr.getDomain().ub_pos() );
  bounds[ vColID ] = make_pair( vc.getDomain().lb_pos(), vc.getDomain().ub_pos() );

  // Create edge vectors and initialize it to TRUE
  edges = new bool*[ g_maxDomainSize/*dom_vRow*/ ];
  for( int i=0; i<g_maxDomainSize; i++ ) 
  {
    edges[ i ] = new bool[ g_maxDomainSize/*dom_vCol*/ ];
    memset( edges[ i ], 1, dom_vCol );
  }
}


CVMatrix& CVMatrix::operator *= (CVMatrix &A )
{
  join( A );
  return *this;
}


// Very inefficient!
void CVMatrix::join( CVMatrix& A )
{  
  int _Rlb = A.bounds[ A.vRowID ].first;  // src
  int _Rub = A.bounds[ A.vRowID ].second; // src
  int _Clb = bounds[ vColID ].first;	// dst
  int _Cub = bounds[ vColID ].second;;	// dst
  int _mlb = bounds[ vRowID ].first;	// mid
  int _mub = bounds[ vRowID ].second;	// mid

  for( int i = 0; i < g_maxDomainSize; i++ ) {
    memset( tmp[ i ], 0, g_maxDomainSize );
  }

  for( int i = _Rlb; i <= _Rub; i++ ) 
  {
    for( int j = _Clb; j <= _Cub; j++ ) 
    {
      tmp[ i ][ j ] = 0;
      for( int k = _mlb; k <= _mub; k++ ) 
      {
	tmp[ i ][ j ] |= ( A.edges[ i ][ k ] & edges[ k ][ j ] );
	if (tmp[i][j]==1) break;
      }
    }
  }
  constraint = 0; 		// invalidate constraint link
  vRowID     = A.vRowID;	// update row ID (source)
  dom_vRow   = A.dom_vRow;	// update row domain (source)
  bounds[ vRowID ] = A.bounds[ vRowID ]; // update bounds 
  //todo: the bounds may be even tighter! update by checking them..
  
  for( int i = 0; i < dom_vRow; i++ ) {
    for( int j = 0; j < dom_vCol; j++ ) {
      edges[ i ][ j ] = tmp[ i ][ j ];
    }
  }
}


// B ( curr matrix ) should have the destination in it, 
// while A should have the source!!
void CVMatrix::join( CVMatrix &A, size_t v_from, size_t v_to )
{
  
  // cout << "B.row: " << vRowID << " B.col: " << vColID
  //      << "A.row: " << A.vRowID << " A.col: " << A.vColID
  //      << " from: " << v_from << " to: " << v_to << endl;
  // mult from source --> dest
  if( v_from == A.vRowID and v_to == vColID )
    { 
      // cout << "case1\n";
      assert( A.vColID == vRowID );
      join( A );
    }
  else if( v_from == A.vColID and v_to == vColID )
    {
      // cout << "case2\n";
      CVMatrix _A( A ); _A.transpose();
      assert( _A.vColID == vRowID );
      join( _A );
    }
  else if( v_from == A.vRowID and v_to == vRowID )
    {
      // cout << "case3\n";
      this->transpose();
      assert( A.vColID == vRowID );
      join( A );
    }
  else if( v_from == A.vColID and v_to == vRowID )
    {
      // cout << "case4\n";
      // Transpose A and Transpose B
      CVMatrix _A( A ); _A.transpose();
      this->transpose();
      assert( A.vColID == vRowID );
      join( _A );
    }
  else {
    cout << "This matrix should have the destination\n";
  }
}


void CVMatrix::merge( CVMatrix& other )
{
  bool inv = false;
  if( vRowID == other.vColID and vColID == other.vRowID )
    inv = true;

  for( int i = 0; i < dom_vRow; i++ ) 
  {
    for( int j = 0; j < dom_vCol; j++ ) 
    {
      
      edges[ i ][ j ] &= inv ? other.edges[ j ][ i ] 
	: other.edges[ i ][ j ];
    }
  }
}

// val is a label in domain of varID
vector<int> CVMatrix::project( int varID, int val )
{
  vector<int> res;

  if( varID == vRowID ) 
  {
    // Check generates empty set
    if( val < bounds[ vRowID ].first or
	val > bounds[ vRowID ].second ) 
      return res;

    int l = bounds[ vColID ].first; 
    int u = bounds[ vColID ].second;
    
    for( int i=l; i<=u; i++ )
    {
      if( edges[ val ][ i ] )
	res.push_back( i );
    }
  }
  else{
    // Check generates empty set
    if( val < bounds[ vColID ].first or
	val > bounds[ vColID ].second ) 
      return res;

    int l = bounds[ vRowID ].first; 
    int u = bounds[ vRowID ].second;
    
    for( int i=l; i<=u; i++ )
    {
      if( edges[ i ][ val ] )
	res.push_back( i );
    }
  }

  return res; // return empty
     
}


// copies bounds from variable (check if it is row or col) 
// and updates elements in the matrix accordingly
void CVMatrix::setBounds( var_int& var )
{
  int lb = var.getDomain().lb_pos();
  int ub = var.getDomain().ub_pos();
  bool clb = false, cub = false;
  if( bounds[ var.getID() ].first != lb )
    { bounds[ var.getID() ].first = lb; clb = true; }
  if( bounds[ var.getID() ].second != ub )
    { bounds[ var.getID() ].second = ub; cub = true; }
  
  // Set zeros
  if( var.getID() == vRowID )
  {
    if( clb ) {
      for( int i=0; i<lb; i++ ) memset( edges[ i ], 0, dom_vCol );
    }
    if( cub ) {
      for( int i=ub+1; i<dom_vRow; i++ ) memset( edges[ i ], 0, dom_vCol );
    }
  }
  else // var.getID() == vColID
  {
    if( clb ) {
      for( int j=0; j<lb; j++ ) 
	for( int i=0; i<dom_vRow; i++ ) edges[ i ][ j ] = 0;
    }
    if( cub ) {
      for( int j=ub+1; j<dom_vCol; j++ ) 
	for( int i=0; i<dom_vRow; i++ ) edges[ i ][ j ] = 0;
    }
  }
  
}


void CVMatrix::setZero()
{
  for( int i=0; i<dom_vRow; i++ )
    memset( edges[ i ], 0, dom_vCol );
}


void CVMatrix::setOne()
{
  for( int i=0; i<dom_vRow; i++ )
    memset( edges[ i ], 1, dom_vCol );
}


// note: different elements in domains are not managed here 
void CVMatrix::setIdentity()
{ 
  setZero();
  int start = max( bounds[ vRowID ].first, bounds[ vColID ].first );
  int end = min( bounds[ vRowID ].second, bounds[ vColID ].second );
  for( int i=start; i<=end; i++ )
  {
    edges[ i ][ i ] = 1;
  }
}


void CVMatrix::setIdentity( size_t vID )
{
  setIdentity();
  var_int& v = *g_Variables[ vID ];
  //.
  // Remove all non active elmenets
  for( int i=0; i<v.getDomain().size(); i++)
    if( not v.getDomain().is_active( i ) )
      edges[ i ][ i ] = 0;
}


void CVMatrix::transpose()
{ 
  for( int i=0; i<dom_vRow; i++ ) {
    for( int j=i+1; j<dom_vCol; j++ ) {
      std::swap( edges[ i ][ j ], edges[ j ][ i ] );
    }
  }

  std::swap( dom_vRow, dom_vCol );
  std::swap( vRowID, vColID );
}



void CVMatrix::dump()
{
  if( constraint )
    cout << "CVG for (" << constraint->getName() << ") "
	 << " v_" << vRowID << " x v_" << vColID << endl;
  else
    cout << "CVG:: " << "v_" << vRowID << " x v_" << vColID << endl;
 
  // print matrix
  for( int i=0; i<dom_vRow; i++ )
  {
    for( int j=0; j<dom_vCol; j++ )
    {
      cout << edges[ i ][ j ] << " ";
    }
    cout << endl;
  }
}
