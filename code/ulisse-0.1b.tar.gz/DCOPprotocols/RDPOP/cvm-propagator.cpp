#include "cvm-propagator.hh"
#include "search-domain.hh" // contains enum events
#include "constraint.hh" // contains constr_type
#include "int-hard-constraint.hh"
#include "var_int.hh"
#include "trailstack.hh"
#include "constraint-store.hh"
#include "cv-matrix.hh"

using namespace std;

//#define DBG
#define BOUND_CONSISTENCY


CVMPropagator::CVMPropagator()
{
  // nothing
}

CVMPropagator::~CVMPropagator() 
{
  // nothing
}

void CVMPropagator::initialize( TrailStack* t, ConstraintStore* s )
{
  trailstack = t;
  constraintStore = s;
}

bool relNE( int x, int y ) { return x != y; }
bool relEQ( int x, int y ) { return x == y; }
bool relLT( int x, int y ) { return x < y; }
bool relLEQ( int x, int y ) { return x <= y; }
bool relGT( int x, int y ) { return x > y; }
bool relGEQ( int x, int y ) { return x >= y; }
bool relPLUSEQ( int x, int y, double c ) { return ( (x + y) == c ); }
bool relPLUSLEQ( int x, int y, double c ) { return (( x + y ) <= c); }
bool relPLUSGEQ( int x, int y, double c ) { return (( x + y ) >= c); }
bool relINTSUBINTGT( int x, int y, double c ) { return ( abs(x - y) > c ); }

bool CVMPropagator::consistency( var_int& v )
{
  int event = v.getDomain().event();

  switch( event )
  {
    case BC_EVENT:
    case DC_EVENT:
      if( v.getDomain().n_active() <= 0 or
	  v.getDomain().lb_pos() > v.getDomain().ub_pos() ) {
	return false;
      }
      break;
    case FAILED_EVENT: 
      return false;
    case SING_EVENT:
      break;
    case NULL_EVENT:
      // This was the first time this variable was touched by 
      // propagation and its domain did not change.
      v.getDomain().set_event( NOT_CHANGED_EVENT );
      break;
    case NOT_CHANGED_EVENT:
      break;	// no need to check 
    }
  return true; 
}


bool CVMPropagator::propagate( IntHardConstraint &r )
{
  if( r.isAtFixpoint() )
    return true; // do not propagate if it is at fixpoint

  std::string c_name = r.getConstrType();
  if( c_name == "int_NE" ) 
    return c_int_NE( r );
  else if( c_name == "int_EQ")
    return c_int_EQ( r );
  else if( c_name == "int_LT")
    return c_int_LT( r );
  else if( c_name == "int_LEQ")
    return c_int_LEQ( r );
  else if( c_name == "int_GT")
    return c_int_GT( r );
  else if( c_name == "int_GEQ")
    return c_int_GEQ( r );
  else if( c_name == "int_PLUS_EQ")
    return c_int_PlusEQconst( r );
  else if( c_name == "int_PLUS_LEQ")
    return c_int_PlusLEQconst( r );
  else if( c_name == "int_PLUS_GEQ")
    return c_int_PlusGEQconst( r );
  else if( c_name == "abs_int_sub_int_gt_int")
    return c_abs_int_sub_int_gt_int( r );
  else
    return true;
}


bool CVMPropagator::initCVM( IntHardConstraint &r )
{
  std::string c_name = r.getConstrType();
  var_int& var_x = r.getScopeVar( 0 );
  var_int& var_y = r.getScopeVar( 1 );
  CVMatrix& CVM = *g_constraint2cvm[ r.getID() ];

  if( c_name == "int_NE" ) {
    //updateCVM( CVM, var_x, var_y, relNE );
    return c_int_NE( r );
  }
  else if( c_name == "int_EQ") {
    // updateCVM( CVM, var_x, var_y, relEQ );
    return c_int_EQ( r );
  }
  else if( c_name == "int_LT"){
    return c_int_LT( r );
    //updateCVM( CVM, var_x, var_y, relLT );
  }
  else if( c_name == "int_LEQ") {
    return c_int_LEQ( r );
    //updateCVM( CVM, var_x, var_y, relLEQ );
  }
  else if( c_name == "int_GT"){
    return c_int_GT( r );
    //    updateCVM( CVM, var_x, var_y, relGT );
  }
  else if( c_name == "int_GEQ"){
    return c_int_GEQ( r );
    //updateCVM( CVM, var_x, var_y, relGEQ );
  } 
  else if( c_name == "int_PLUS_EQ") {
    return c_int_PlusEQconst( r );
    // double b  = r.getIntCoef( 0 );
    // double ax = r.getRealCoef( 0 );
    // double ay = r.getRealCoef( 1 );
    // updateCVM( CVM, var_x, var_y, relPLUSEQ, ax, ay, b );
  }
  else if( c_name == "abs_int_sub_int_gt_int") {
    return c_abs_int_sub_int_gt_int( r );
    // double b  = r.getRealCoef( 0 );
    // updateCVM( CVM, var_x, var_y, relINTSUBINTGT, 1.0, 1.0, b );
  }
  return true;
}


bool CVMPropagator::updateCVM( CVMatrix& CVM, var_int& var_x, 
			       var_int& var_y, relation2 rel )
{
  int x_lb_pos = var_x.getDomain().lb_pos();
  int x_ub_pos = var_x.getDomain().ub_pos();
  int y_lb_pos = var_y.getDomain().lb_pos();
  int y_ub_pos = var_y.getDomain().ub_pos();
 
  CVM.setBounds( var_x );
  CVM.setBounds( var_y );
 
  bool changes = false;
  for( int i=x_lb_pos; i<=x_ub_pos; i++ )
  {
    int x = var_x.getDomain()[ i ];    
    for( int j=y_lb_pos; j<=y_ub_pos; j++ )
    {
      int y = var_y.getDomain()[ j ];
      if( not rel( x, y) and CVM.isActive( i, j ) )
      {
	CVM.unset( i, j );
	changes = true;
      }
    }
  }
  if( changes ) { 
    // if something change
    var_y.isJustChanged();
    var_x.isJustChanged();
    constraintStore->signalVarChanged( var_x );
    constraintStore->signalVarChanged( var_y );
  }

  return changes;
}



bool CVMPropagator::updateCVM
( CVMatrix& CVM, var_int& var_x, var_int& var_y, 
  relation3 rel, double ax, double ay, double c )
{
  int x_lb_pos = var_x.getDomain().lb_pos();
  int x_ub_pos = var_x.getDomain().ub_pos();
  int y_lb_pos = var_y.getDomain().lb_pos();
  int y_ub_pos = var_y.getDomain().ub_pos();
 
  CVM.setBounds( var_x );
  CVM.setBounds( var_y );
 
  bool changes = false;
  for( int i=x_lb_pos; i<=x_ub_pos; i++ )
  {
    int x = var_x.getDomain()[ i ];    
    for( int j=y_lb_pos; j<=y_ub_pos; j++ )
    {
      int y = var_y.getDomain()[ j ];
      if( not rel( ax*x, ay*y, c ) and CVM.isActive( i, j ) )
      {
	CVM.unset( i, j );
	changes = true;
      }
    }
  }
  if( changes ) { 
    // if something change
    var_y.isJustChanged();
    var_x.isJustChanged();
    constraintStore->signalVarChanged( var_x );
    constraintStore->signalVarChanged( var_y );
  }

  return changes;
}


// @note: only bound consistency implemented.
// @note: Once the constraint has been propagated, 
//        a AC fixpoint is reached---no need to propagate this constraint
//        during the same AC loop.
bool CVMPropagator::c_int_EQ( IntHardConstraint &r )
{
  var_int& var_x = r.getScopeVar( 0 );
  var_int& var_y = r.getScopeVar( 1 );
  int x_lb = var_x.getDomain().lb( );
  int y_lb = var_y.getDomain().lb( );
  int x_ub = var_x.getDomain().ub( );
  int y_ub = var_y.getDomain().ub( );
  int lb = max( x_lb, y_lb );
  int ub = min( x_ub, y_ub );

  // cout << "---------------------------------------\n";
  // cout << "Propagating EQ\n";  var_x.dump();  var_y.dump();
  // cout << "---------------------------------------\n";

  // retrieve associated constraint value matrix (graph)
  CVMatrix& CVM = *g_constraint2cvm[ r.getID() ];
  // CVM.dump();

  bool cx = false, cy = false;

  // move ub, lb in domain of vars X, Y
  if( x_lb < lb ) { var_x.getDomain().move_lb_val( lb ); cx = true; }
  if( y_lb < lb ) { var_y.getDomain().move_lb_val( lb ); cy = true; }
  if( x_ub > ub ) { var_x.getDomain().move_ub_val( ub ); cx = true; }
  if( y_ub > ub ) { var_y.getDomain().move_ub_val( ub ); cy = true; }

  if( cx ) constraintStore->signalVarChanged( var_x );
  else var_x.getDomain().set_event( NOT_CHANGED_EVENT );
  if( cy ) constraintStore->signalVarChanged( var_y );
  else var_y.getDomain().set_event( NOT_CHANGED_EVENT );

  // Here Fixpoint is not valid
  // Set local var changes 
  if( cx ) var_x.setJustChangedFlag();
  if( cy ) var_y.setJustChangedFlag();
  
  // update CVM
  updateCVM( CVM, var_x, var_y, relEQ );

  // cout << "After propagation:\n";  CVM.dump();  getchar();

  return true;
}


// var_x != var_y
// int_ne( a, b )
bool CVMPropagator::c_int_NE( IntHardConstraint &r )
{
  var_int& var_x = r.getScopeVar( 0 );
  var_int& var_y = r.getScopeVar( 1 );   

  // cout << "---------------------------------------\n";
  // cout << "Propagating NE\n";  var_x.dump();  var_y.dump();
  // cout << "---------------------------------------\n";

  // retrieve associated constraint value matrix (graph)
  CVMatrix& CVM = *g_constraint2cvm[ r.getID() ];
  // CVM.dump();

  bool c = updateCVM( CVM, var_x, var_y, relNE );
  if( not c ) { 
    var_x.getDomain().set_event( NOT_CHANGED_EVENT );
    var_y.getDomain().set_event( NOT_CHANGED_EVENT );
  }

  // cout << "After propagation:\n";  CVM.dump();  getchar();

  return true;
}


// a < b 
// @note: only bound consistency implemented.
// @note: Once the constraint has been propagated, 
//        a AC fixpoint is reached---no need to propagate this constraint
//        during the same AC loop.
// @Note: assumes no holes in the variable domains
bool CVMPropagator::c_int_LT( IntHardConstraint &r )
{
  // cout << "Propagating LT\n";
  var_int& var_x = r.getScopeVar( 0 ); // @todo
  var_int& var_y = r.getScopeVar( 1 ); // @todo
  int x_lb = var_x.getDomain().lb();
  int x_ub = var_x.getDomain().ub();
  int y_lb = var_y.getDomain().lb();
  int y_ub = var_y.getDomain().ub();

  // cout << "---------------------------------------\n";
  // cout << "Propagating LT\n";  var_x.dump();  var_y.dump();
  // cout << "---------------------------------------\n";

  CVMatrix& CVM = *g_constraint2cvm[ r.getID() ];
  // CVM.dump();

  bool cx = false, cy = false;
  if( x_lb >= y_lb ) { var_y.getDomain().move_lb_val( x_lb + 1 ); cy = true; }
  if( x_ub >= y_ub ) { var_x.getDomain().move_ub_val( y_ub - 1 ); cx = true; }

  if( cx ) constraintStore->signalVarChanged( var_x );
  else var_x.getDomain().set_event( NOT_CHANGED_EVENT );
  if( cy ) constraintStore->signalVarChanged( var_y );
  else var_y.getDomain().set_event( NOT_CHANGED_EVENT );

  // Set local var changes 
  if( cx ) var_x.setJustChangedFlag();
  if( cy ) var_y.setJustChangedFlag();

  // Update CVM (after updating bounds)
  updateCVM( CVM, var_x, var_y, relLT );

  // cout << "After propagation:\n";  CVM.dump();  getchar();

  return true;
}


// a <= b 
// @note: only bound consistency implemented.
// @note: Once the constraint has been propagated, 
//        a AC fixpoint is reached---no need to propagate this constraint
//        during the same AC loop.
bool CVMPropagator::c_int_LEQ( IntHardConstraint &r )
{
  var_int& var_x = r.getScopeVar( 0 );
  var_int& var_y = r.getScopeVar( 1 );
  int x_lb = var_x.getDomain().lb();
  int x_ub = var_x.getDomain().ub();
  int y_lb = var_y.getDomain().lb();
  int y_ub = var_y.getDomain().ub();

  // cout << "---------------------------------------\n";
  // cout << "Propagating LEQ\n";  var_x.dump();  var_y.dump();
  // cout << "---------------------------------------\n";

  CVMatrix& CVM = *g_constraint2cvm[ r.getID() ];
  //CVM.dump();

  bool cx = false, cy = false;  
  if( x_lb > y_lb ) { var_y.getDomain().move_lb_val( x_lb ); cy = true; }
  if( x_ub > y_ub ) { var_x.getDomain().move_ub_val( y_ub ); cx = true; }

  if( cx ) constraintStore->signalVarChanged( var_x );
  else var_x.getDomain().set_event( NOT_CHANGED_EVENT );
  if( cy ) constraintStore->signalVarChanged( var_y );
  else var_y.getDomain().set_event( NOT_CHANGED_EVENT );

  // Set local var changes 
  if( cx ) var_x.setJustChangedFlag();
  if( cy ) var_y.setJustChangedFlag();

  // Update CVM (after updating bounds)
  updateCVM( CVM, var_x, var_y, relLEQ );

  // cout << "After propagation:\n";  CVM.dump();  getchar();

  return true;
}


// a > b 
// @note: only bound consistency implemented.
// @note: Once the constraint has been propagated, 
//        a AC fixpoint is reached---no need to propagate this constraint
//        during the same AC loop.
bool CVMPropagator::c_int_GT( IntHardConstraint &r )
{
  // cout << "Propagating GT\n";
  var_int& var_x = r.getScopeVar( 0 ); // @todo
  var_int& var_y = r.getScopeVar( 1 ); // @todo
  int x_lb = var_x.getDomain().lb();
  int x_ub = var_x.getDomain().ub();
  int y_lb = var_y.getDomain().lb();
  int y_ub = var_y.getDomain().ub();

  // cout << "---------------------------------------\n";
  // cout << "Propagating GT\n";  var_x.dump();  var_y.dump();
  // cout << "---------------------------------------\n";

  CVMatrix& CVM = *g_constraint2cvm[ r.getID() ];
  // CVM.dump();
  
  bool cx = false, cy = false;
  if( x_lb <= y_lb ) { var_x.getDomain().move_lb_val( y_lb + 1 ); cx = true; }
  if( x_ub <= y_ub ) { var_y.getDomain().move_ub_val( x_ub - 1 ); cy = true; }
  
  if( cx ) constraintStore->signalVarChanged( var_x );
  else var_x.getDomain().set_event( NOT_CHANGED_EVENT );
  if( cy ) constraintStore->signalVarChanged( var_y );
  else var_y.getDomain().set_event( NOT_CHANGED_EVENT );

  // Set local var changes 
  if( cx ) var_x.setJustChangedFlag();
  if( cy ) var_y.setJustChangedFlag();

  // Update CVM (after updating bounds)
  updateCVM( CVM, var_x, var_y, relGT );

  // cout << "After propagation:\n";  CVM.dump();  getchar();

  return true;
}


// a >= b 
// @note: only bound consistency implemented.
// @note: Once the constraint has been propagated, 
//        a AC fixpoint is reached---no need to propagate this constraint
//        during the same AC loop.
bool CVMPropagator::c_int_GEQ( IntHardConstraint &r )
{

  var_int& var_x = r.getScopeVar( 0 );
  var_int& var_y = r.getScopeVar( 1 );
  int x_lb = var_x.getDomain().lb();
  int x_ub = var_x.getDomain().ub();
  int y_lb = var_y.getDomain().lb();
  int y_ub = var_y.getDomain().ub();

  // cout << "---------------------------------------\n";
  // cout << "Propagating GEQ\n";  var_x.dump();  var_y.dump();
  // cout << "---------------------------------------\n";

  CVMatrix& CVM = *g_constraint2cvm[ r.getID() ];
  // CVM.dump();

  bool cx = false, cy = false;
  if( x_lb < y_lb ) { var_x.getDomain().move_lb_val( y_lb ); cx = true; }
  if( x_ub < y_ub ) { var_y.getDomain().move_ub_val( x_ub ); cy = true; }
  
  if( cx ) constraintStore->signalVarChanged( var_x );
  else var_x.getDomain().set_event( NOT_CHANGED_EVENT );
  if( cy ) constraintStore->signalVarChanged( var_y );
  else var_y.getDomain().set_event( NOT_CHANGED_EVENT );

  // Set local var changes 
  if( cx ) var_x.setJustChangedFlag();
  if( cy ) var_y.setJustChangedFlag();

  // Update CVM (after updating bounds)
  updateCVM( CVM, var_x, var_y, relGEQ );

  // cout << "After propagation:\n";  CVM.dump();  getchar();

  return true;
}


// a X + b Y <= c
// int_plusLEQ(var int: x, var int: y, int: c)
// only alpha and beta
bool CVMPropagator::c_int_PlusLEQconst( IntHardConstraint& r )
{
  double alpha_x, beta_x;
  double alpha_y, beta_y;

  var_int& var_x = r.getScopeVar( 0 );
  var_int& var_y = r.getScopeVar( 1 );
  int x_lb = var_x.getDomain().lb();
  int x_ub = var_x.getDomain().ub();
  int y_lb = var_y.getDomain().lb();
  int y_ub = var_y.getDomain().ub();

  // cout << "---------------------------------------\n";
  // cout << "Propagating X+Y=c\n";  var_x.dump();  var_y.dump();
  // cout << "---------------------------------------\n";

  CVMatrix& CVM = *g_constraint2cvm[ r.getID() ];
  // CVM.dump();

  // Last Coefficient is the constant 'c'
  double b = r.getRealCoef( 0 );
  double ax = 1;//r.getRealCoef( 0 );
  double ay = 1;//r.getRealCoef( 1 );

  // cout << ax << ", " << ay << "," << b << endl;
  //#ifdef FALSE
  assert ( ax != 0 and ay != 0 );
  int lx, ux, ly, uy;
  if( ax > 0 ) {
    alpha_x = ay > 0 ? ((b - ay * y_lb) / ax) : ((b - ay * y_ub) / ax);
    ux = min( (double)x_ub, std::floor(alpha_x) );    
    // cout << "ax pos [ " << lx << " " << ux << "]\n";
  }
  else {
    beta_x = ay > 0 ? ((-b + ay * y_lb) / (-1)*ax) : ((-b + ay * y_ub) / (-1)*ax);
    lx = max( (double)x_lb, std::ceil(beta_x) );
    // cout << "ax neg [ " << lx << " " << ux << "]\n";
  }

  if( ay > 0 ) {
    alpha_y = ax > 0 ? ((b - ax * x_lb) / ay) : ((b - ax * x_ub) / ay);
    uy = min( (double)y_ub, std::floor(alpha_y) );    
    // cout << "ay pos [ " << ly << " " << uy << "]\n";
  }
  else {
    beta_y = ax > 0 ? ((-b + ax * x_lb) / (-1)*ay) : ((-b + ax * x_ub) / (-1)*ay);
    ly = max( (double)y_lb, std::ceil(beta_y) );
    // cout << "ay neg [ " << beta_y << " "<< delta_y <<  "]\n";
  }

  if( var_x.getDomain().get_pos( lx ) < 0 or 
      var_x.getDomain().get_pos( ux ) < 0 or 
      var_y.getDomain().get_pos( ly ) < 0 or 
      var_y.getDomain().get_pos( uy ) < 0 ) 
    return false;
  // printf("X [%d %d] Y [%d %d]\n", lx, ux, ly, uy );

  // move ub, lb in domain of vars X, Y
  bool cx = false, cy = false;
  if( lx > x_lb ) { var_x.getDomain().move_lb_val( lx ); cx = true; }
  if( ux < x_ub ) { var_x.getDomain().move_ub_val( ux ); cx = true; }
  if( ly > y_lb ) { var_y.getDomain().move_lb_val( ly ); cy = true; }
  if( uy < y_ub ) { var_y.getDomain().move_ub_val( uy ); cy = true; }

  if( cx ) constraintStore->signalVarChanged( var_x );
  else var_x.getDomain().set_event( NOT_CHANGED_EVENT );
  if( cy ) constraintStore->signalVarChanged( var_y );
  else var_y.getDomain().set_event( NOT_CHANGED_EVENT );

  if( cx ) var_x.setJustChangedFlag();
  if( cy ) var_y.setJustChangedFlag();
  //#endif

  // update CVM
  updateCVM( CVM, var_x, var_y, relPLUSLEQ, ax, ay, b );

  // cout << "After propagation:\n";  CVM.dump();  getchar();

  return true;
}



// a X + b Y >= c
// int_plusLEQ(var int: x, var int: y, int: c)
// only gamma and delta
bool CVMPropagator::c_int_PlusGEQconst( IntHardConstraint& r )
{
  double gamma_x, delta_x;
  double gamma_y, delta_y;

  var_int& var_x = r.getScopeVar( 0 );
  var_int& var_y = r.getScopeVar( 1 );
  int x_lb = var_x.getDomain().lb();
  int x_ub = var_x.getDomain().ub();
  int y_lb = var_y.getDomain().lb();
  int y_ub = var_y.getDomain().ub();

  // cout << "---------------------------------------\n";
  // cout << "Propagating X+Y=c\n";  var_x.dump();  var_y.dump();
  // cout << "---------------------------------------\n";

  CVMatrix& CVM = *g_constraint2cvm[ r.getID() ];
  // CVM.dump();

  // Last Coefficient is the constant 'c'
  double b = r.getRealCoef( 0 );
  double ax = 1;//r.getRealCoef( 0 );
  double ay = 1;//r.getRealCoef( 1 );

  // cout << ax << ", " << ay << "," << b << endl;
  //#ifdef FALSE
  assert ( ax != 0 and ay != 0 );
  int lx, ux, ly, uy;
  if( ax > 0 ) {
    gamma_x = ay > 0 ? ((b - ay * y_ub) / ax) : ((b - ay * y_lb) / ax);

    lx = max( (double)x_lb, std::ceil(gamma_x) );
    // cout << "ax pos [ " << lx << " " << ux << "]\n";
  }
  else {
    delta_x = ay > 0 ? ((-b + ay * y_ub) / (-1)*ax) : ((-b + ay * y_lb) / (-1)*ax);

    ux = min( (double)x_ub, std::floor(delta_x) );
    // cout << "ax neg [ " << lx << " " << ux << "]\n";
  }

  if( ay > 0 ) {
    gamma_y = ax > 0 ? ((b - ax * x_ub) / ay) : ((b - ax * x_lb) / ay);

    ly = max( (double)y_lb, std::ceil(gamma_y) );
    // cout << "ay pos [ " << ly << " " << uy << "]\n";
  }
  else {
    delta_y = ax > 0 ? ((-b + ax * x_ub) / (-1)*ay) : ((-b + ax * x_lb) / (-1)*ay);

    uy = min( (double)y_ub, std::floor(delta_y) );

    // cout << "ay neg [ " << beta_y << " "<< delta_y <<  "]\n";
  }

  if( var_x.getDomain().get_pos( lx ) < 0 or 
      var_x.getDomain().get_pos( ux ) < 0 or 
      var_y.getDomain().get_pos( ly ) < 0 or 
      var_y.getDomain().get_pos( uy ) < 0 ) 
    return false;
  // printf("X [%d %d] Y [%d %d]\n", lx, ux, ly, uy );

  // move ub, lb in domain of vars X, Y
  bool cx = false, cy = false;
  if( lx > x_lb ) { var_x.getDomain().move_lb_val( lx ); cx = true; }
  if( ux < x_ub ) { var_x.getDomain().move_ub_val( ux ); cx = true; }
  if( ly > y_lb ) { var_y.getDomain().move_lb_val( ly ); cy = true; }
  if( uy < y_ub ) { var_y.getDomain().move_ub_val( uy ); cy = true; }

  if( cx ) constraintStore->signalVarChanged( var_x );
  else var_x.getDomain().set_event( NOT_CHANGED_EVENT );
  if( cy ) constraintStore->signalVarChanged( var_y );
  else var_y.getDomain().set_event( NOT_CHANGED_EVENT );

  if( cx ) var_x.setJustChangedFlag();
  if( cy ) var_y.setJustChangedFlag();
  //#endif

  // update CVM
  updateCVM( CVM, var_x, var_y, relPLUSGEQ, ax, ay, b );

  // cout << "After propagation:\n";  CVM.dump();  getchar();

  return true;
}



// a X + b Y = c
// int_plusEQ(var int: x, var int: y, int: c)
bool CVMPropagator::c_int_PlusEQconst( IntHardConstraint& r )
{
  double alpha_x, beta_x, gamma_x, delta_x;
  double alpha_y, beta_y, gamma_y, delta_y;

  var_int& var_x = r.getScopeVar( 0 );
  var_int& var_y = r.getScopeVar( 1 );
  int x_lb = var_x.getDomain().lb();
  int x_ub = var_x.getDomain().ub();
  int y_lb = var_y.getDomain().lb();
  int y_ub = var_y.getDomain().ub();

  // cout << "---------------------------------------\n";
  // cout << "Propagating X+Y=c\n";  var_x.dump();  var_y.dump();
  // cout << "---------------------------------------\n";

  CVMatrix& CVM = *g_constraint2cvm[ r.getID() ];
  // CVM.dump();

  // Last Coefficient is the constant 'c'
  double b = r.getRealCoef( 0 );
  double ax = 1;//r.getRealCoef( 0 );
  double ay = 1;//r.getRealCoef( 1 );

  // cout << ax << ", " << ay << "," << b << endl;
  //#ifdef FALSE
  assert ( ax != 0 and ay != 0 );
  int lx, ux, ly, uy;
  if( ax > 0 ) {
    alpha_x = ay > 0 ? ((b - ay * y_lb) / ax) : ((b - ay * y_ub) / ax);
    gamma_x = ay > 0 ? ((b - ay * y_ub) / ax) : ((b - ay * y_lb) / ax);

    lx = max( (double)x_lb, std::ceil(gamma_x) );
    ux = min( (double)x_ub, std::floor(alpha_x) );    
    // cout << "ax pos [ " << lx << " " << ux << "]\n";
  }
  else {
    beta_x = ay > 0 ? ((-b + ay * y_lb) / (-1)*ax) : ((-b + ay * y_ub) / (-1)*ax);
    delta_x = ay > 0 ? ((-b + ay * y_ub) / (-1)*ax) : ((-b + ay * y_lb) / (-1)*ax);

    lx = max( (double)x_lb, std::ceil(beta_x) );
    ux = min( (double)x_ub, std::floor(delta_x) );

    // cout << "ax neg [ " << lx << " " << ux << "]\n";
  }

  if( ay > 0 ) {
    alpha_y = ax > 0 ? ((b - ax * x_lb) / ay) : ((b - ax * x_ub) / ay);
    gamma_y = ax > 0 ? ((b - ax * x_ub) / ay) : ((b - ax * x_lb) / ay);

    ly = max( (double)y_lb, std::ceil(gamma_y) );
    uy = min( (double)y_ub, std::floor(alpha_y) );    

    // cout << "ay pos [ " << ly << " " << uy << "]\n";
  }
  else {
    beta_y = ax > 0 ? ((-b + ax * x_lb) / (-1)*ay) : ((-b + ax * x_ub) / (-1)*ay);
    delta_y = ax > 0 ? ((-b + ax * x_ub) / (-1)*ay) : ((-b + ax * x_lb) / (-1)*ay);

    ly = max( (double)y_lb, std::ceil(beta_y) );
    uy = min( (double)y_ub, std::floor(delta_y) );

    // cout << "ay neg [ " << beta_y << " "<< delta_y <<  "]\n";
  }

  if( var_x.getDomain().get_pos( lx ) < 0 or 
      var_x.getDomain().get_pos( ux ) < 0 or 
      var_y.getDomain().get_pos( ly ) < 0 or 
      var_y.getDomain().get_pos( uy ) < 0 ) 
    return false;
  // printf("X [%d %d] Y [%d %d]\n", lx, ux, ly, uy );

  // move ub, lb in domain of vars X, Y
  bool cx = false, cy = false;
  if( lx > x_lb ) { var_x.getDomain().move_lb_val( lx ); cx = true; }
  if( ux < x_ub ) { var_x.getDomain().move_ub_val( ux ); cx = true; }
  if( ly > y_lb ) { var_y.getDomain().move_lb_val( ly ); cy = true; }
  if( uy < y_ub ) { var_y.getDomain().move_ub_val( uy ); cy = true; }

  if( cx ) constraintStore->signalVarChanged( var_x );
  else var_x.getDomain().set_event( NOT_CHANGED_EVENT );
  if( cy ) constraintStore->signalVarChanged( var_y );
  else var_y.getDomain().set_event( NOT_CHANGED_EVENT );

  if( cx ) var_x.setJustChangedFlag();
  if( cy ) var_y.setJustChangedFlag();
  //#endif

  // update CVM
  updateCVM( CVM, var_x, var_y, relPLUSEQ, ax, ay, b );

  // cout << "After propagation:\n";  CVM.dump();  getchar();

  return true;
}


// Creates holes
bool CVMPropagator::c_abs_int_sub_int_gt_int( IntHardConstraint& r )
{
  var_int& var_x = r.getScopeVar( 0 );
  var_int& var_y = r.getScopeVar( 1 );
  int x_lb = var_x.getDomain().lb( );
  int y_lb = var_y.getDomain().lb( );
  int x_ub = var_x.getDomain().ub( );
  int y_ub = var_y.getDomain().ub( );
  int lb = max( x_lb, y_lb );
  int ub = min( x_ub, y_ub );
  double c = r.getRealCoef( 0 );


  // retrieve associated constraint value matrix (graph)
  CVMatrix& CVM = *g_constraint2cvm[ r.getID() ];
  // CVM.dump();

  bool cx = false, cy = false;

  updateCVM( CVM, var_x, var_y, relINTSUBINTGT, 1.0, 1.0, c );

  return true;
}
