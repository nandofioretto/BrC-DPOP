#include "rdpop-ACdown-message.hh"
#include "search-solution.hh"
#include "agent.hh"
#include "var_int.hh"

using namespace DPOP;
using namespace std;


AC_downMessage::AC_downMessage( )
  : variable( 0 )
{
  // nothing
}

AC_downMessage::AC_downMessage( Agent& _src, Agent& _dst, var_int& v )
{
  src  = &_src;
  dest = &_dst;
  variable = &v;
}


AC_downMessage::~AC_downMessage()
{ 
  // nothing
}


AC_downMessage::AC_downMessage( const AC_downMessage& other )
{
  src = other.src;
  dest = other.dest;
  variable = other.variable;
}


AC_downMessage& AC_downMessage::operator=( const AC_downMessage& other )
{
  if( this != &other )
  { 
    src = other.src;
    dest = other.dest;
    variable = other.variable;
  }
  return *this;
}

void AC_downMessage::reset()
{
  // nothing
}


void AC_downMessage::dump()
{
  cout << "Message type: AC_down ";
  if( src and dest )
    cout << "  Src: " << src->getName()
	 << "  Dst: " << dest->getName() << endl;
}
