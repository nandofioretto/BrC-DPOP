#ifndef _ULISSE_VARIABLE_ORDERING_H_
#define _ULISSE_VARIABLE_ORDERING_H_

class Agent;

class VariableOrdering
{
public: 
  VariableOrdering() {};
  ~VariableOrdering() {};

  /**
   * Returns the ancestors agent (including parent) of current
   * agent -- that is the agents that have compleated before 'a'.
   */
  virtual std::vector<Agent*> getAncestors( Agent& a ) = 0;

  /**
   * Returns the neighbouring agents of a given agent
   */
  virtual std::vector<Agent*> getSeparator( Agent& a ) = 0;

  //virtual ~VariableOrdering() = 0;
  
  virtual void dump() = 0;
};

#endif
