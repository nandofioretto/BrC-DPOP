#include "pseudo-node.hh"
#include "agent.hh"
#include "constraint.hh"
#include "relation.hh"
#include "var_int.hh"

using namespace std;


PseudoNode::PseudoNode() 
  : content( 0 ), locked( 0 )
{}


PseudoNode::PseudoNode( Agent& a, causal_node p )
  : content( &a ) , parent( p ), locked( false )
{ }


PseudoNode::~PseudoNode() 
{ }


PseudoNode::PseudoNode( const PseudoNode& other )
{
  content = other.content;
  parent = other.parent;
  children = other.children;
  ancestors = other.ancestors;
  locked = other.locked;
}


PseudoNode& PseudoNode::operator=( const PseudoNode& other )
{
  if( this != &other )
  {
    content = other.content;
    parent = other.parent;
    children = other.children;
    ancestors = other.ancestors;
    locked = other.locked;
  }
  return *this;
}

// check if n is children or pseudo-children
bool PseudoNode::isAncestorOf( PseudoNode& n )
{
  if( n.isRoot() ) return false;

  PseudoNode* p = &n.getParent();
  while( not p->isRoot() )
  {
    if( p->getContent() == getContent() ) { return true;}
    p = &p->getParent();
  }
  if( p->getContent() == getContent() ) { return true;}
  return false;

  // if( n.getParent() == *this )
  // {
  //   // cout << "n is parent of this node\n";
  //   return true;
  // }
  // for( int i=0; i<n.numofAncestors(); i++ )
  // {
  //   if( *this == n.getAncestor( i ) ) {
  //     //cout << "this node is ancestor of n\n";
  //     return true;
  //   }
  // }
  // return false;
}


size_t PseudoNode::subTreeSize( )
{
  size_t size = numofChildren();
  for( int i=0; i<numofChildren(); i++)
    size += getChild( i ).subTreeSize();
  return size;
}


vector< PseudoNode* > PseudoNode::getSubTree()
{
  std::vector< PseudoNode* > T;
  for( int i=0; i<numofChildren(); i++ )
  {
    T.push_back( &getChild( i ) );
    std::vector<PseudoNode*> C = getChild( i ).getSubTree();
    T.insert( T.end(), C.begin(), C.end() );
  }
  return T;
}


void PseudoNode::setParent( PseudoNode& p, vector<Constraint* > C )
{
  parent = make_pair( &p, C );
}
  
  
void PseudoNode::addChild( PseudoNode& c, vector<Constraint* > C )
{
  causal_node child( &c, C );
  if( std::find ( children.begin(), children.end(),  
		  child ) == children.end() ) // not found
    children.push_back( child );
  //received_VALUE_msgs.push_back( NULL ); // @todo: activate this line once messages have been enalbed
}


void PseudoNode::addAncestor( PseudoNode& a, vector<Constraint* > C )
{
  ancestors.push_back( make_pair( &a, C) );
}


void PseudoNode::dump() const
{
  std::cout << "Pseudonode: "
	    << content->getName()
	    << std::endl;
  // 	    << " - ancestors: ";
  // for( auto a : ancestors )
  //   cout << a.first->getContent().getName() << " ";
  //cout << endl;
}
