#ifndef _ULISSE_LINEAR_ORDERING_HH_
#define _ULISSE_LINEAR_ORDERING_HH_

#include "globals.hh"
#include "pseudo-node.hh"
#include "variable-ordering.hh"
#include "agent.hh"

class Agent;
class PseudoTree;
class PseudoNode;

class LinearOrdering : public VariableOrdering
{
public:
  /*
   * Constructs a linear ordering of the DCOP agents based
   * on a topological sort.
   */ 
  LinearOrdering();
  
  /**
   * Default distructor.
   */
  ~LinearOrdering();
   
  /**
   * Returns the ancestors agent (including parent) of current
   * agent -- that is the agents that have compleated before 'a'.
   */
  virtual std::vector<Agent*> getAncestors( Agent & a );

  /**
   * Returns the neighbouring agents of a given agent
   */
  virtual std::vector<Agent*> getSeparator( Agent& a );

 /*
   * Get the i+1-th agent in the linear order
   * @note: if there are no successors, return *this.
   */ 
  PseudoNode& getSuccessor( PseudoNode& n );

  /*
   * Get the i-1-th agent in the linear order
   * @note: if there are not predecessors, return *this.
   */ 
  PseudoNode& getPredecessor( PseudoNode& n );

  /*
   * Get the i-th node
   */
  PseudoNode& getNode( int i ) 
  {
    return L[ i ];
  }

  /*
   * The number of pseudo-node (a.k.a., agents) in the pseudo-tree
   */
  size_t size() const
  {
    return L.size();
  }

  /*
   * Returns the position of the agent a in the linear ordering vector
   */
  int getAgentPosition( Agent& a )
  {
    return position[ a.getID() ];
  }

  /*
   * Get the first node of the Linear ordering
   */
  PseudoNode& getHead()
  {
    return L[ 0 ];
  }

  /*
   * Get the last node of the Linear ordering
   */
  PseudoNode& getTail()
  {
    return L[ L.size()-1 ];
  }

  void dump();

private:
  // Stores the linear ordering of the nodes to visit 
  std::vector<PseudoNode> L;
  
  // Stores the position of the agents into the vector 'L'  
  // Key: agentID, value: position in the LinearOrdering 
  std::map<int, int> position;

};


#endif
