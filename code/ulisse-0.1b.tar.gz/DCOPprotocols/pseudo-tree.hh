#ifndef _ULISSE_PSEUDO_TREE_HH_
#define _ULISSE_PSEUDO_TREE_HH_

#include "globals.hh"
#include "variable-ordering.hh"

class Agent;
class PseudoNode;

/**
 * @todo: the pseudo-tree construction is now done in a centralized way,
 *        use message passing procedures to make it distribuited.
 * @note: if communication-schema uses pseudo-tree, then each agent
 *        should be a pseudo-node, which can consult its children its 
 *        parent and its ancestors (with relative constraints) 
 */
class PseudoTree : public VariableOrdering
{
public:
  /**
   * Default constructor
   */
  PseudoTree();

  /**
   * Default Destructor
   */
  ~PseudoTree();

  /**
   * Returns the ancestors agent (including parent) of current
   * agent -- that is the agents that have compleated before 'a'.
   */
  virtual std::vector<Agent*> getAncestors( Agent & a );

  /**
   * Returns the neighbouring agents of a given agent
   */
  virtual std::vector<Agent*> getSeparator( Agent& a );

  /**
   * Returns node associated to an agent.
   * @note: inefficient linear scan. 
   */
  PseudoNode& seekNode( Agent& a );
  
  /**
   * Returns the root of the pseudo-tree
   */
  PseudoNode& getRoot() const;

  /**
   * Returns the leaves of the pseudo-tree.
   */
  std::vector<PseudoNode*> getLeaves();

  /**
   * @check: DEPRECATED?
   */
  std::vector<PseudoNode*> get_ready_nodes();
  
  /**
   * @check DEPRECATED?
   */
  void unlock_node( PseudoNode* n );


  void dump();

 private:

  std::vector<PseudoNode*> nodes;

  /**
   * The dfs step applied in the construction of the pseudo-tree.
   */
  void l_dfsStep( PseudoNode* curr_node );

  /**
   * Construct the agent context, i.e. the neighbouring agents having boundary 
   * variables involved in a constraint with boundary variables of A.
   */
  void l_makeSuccessors( Agent& A );
  
  /**
   * Returns the set of constraints connecting agents Ai and Aj.
   * @note: auxiliary function
   */
  std::vector<Constraint* > l_getLinks( Agent& Ai, Agent& Aj );

  /// Auxiliary structures which i don't know if are necessary anymore
  std::map<PseudoNode*, bool> unlockedNodes; // nodes unlocked.  
  std::map<Agent*, int>       markedAgents;
  ///--

};


inline void PseudoTree::unlock_node( PseudoNode* N )
{
  unlockedNodes[ N ] = true;
}


#endif
