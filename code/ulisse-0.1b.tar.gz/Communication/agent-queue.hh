#ifndef _ULISSE_AGENT_QUEUE_HH_
#define _ULISSE_AGENT_QUEUE_HH_

#include "globals.hh"
#include "agent.hh"

class AgentQueue
{
public:

  AgentQueue() : agentsQueue( 0 ), agentInQueue( 0 )
  { };

  ~AgentQueue()
  {
    if(agentsQueue) delete[] agentsQueue;
    if(agentInQueue) delete[] agentInQueue;
  };

  void initialize( ) 
  {
    capacity = g_agents.size();
    agentsQueue  = new Agent*[ capacity ];
    agentInQueue = new bool[ capacity ];
    for(int j=0; j<capacity; j++ ) {
      agentsQueue[j]=0; agentInQueue[j]=false;
    }
    size = 0;
    push_pos = 0;
    pop_pos  = 0;
    int i = 0;
    for( auto kv : g_agents )
    {
      agentID2queuePos[ kv.second->getID() ] = i++;
    }
  }

  Agent& pop()
  {
    Agent& a = *agentsQueue[ pop_pos ];
    unset( a );
    pop_pos = ((pop_pos+1) % capacity);
    size--;
    return a;
  }

  void push( Agent& a )
  {
    if( not inQueue( a ) ) 
    {
      agentsQueue[ push_pos ] = &a;
      set( a );
      push_pos = ((push_pos+1) % capacity);
      size++;
    }
  }

  bool inQueue( Agent& a )
  {
    return agentInQueue[ agentID2queuePos[ a.getID() ] ];
  }

  void unset( Agent& a )
  {
    agentInQueue[ agentID2queuePos[ a.getID() ] ] = false;
  }

  void set( Agent& a )
  {
    agentInQueue[ agentID2queuePos[ a.getID() ] ] = true;
  }

  bool isEmpty()
  {
    return size == 0;
  }

  size_t getSize()
  {
    return size;
  }

  size_t getCapacity()
  {
    return capacity;
  }

  void dump() const
  {
    int _size = size;
    int _pp   = pop_pos;
    std::cout << "AgentQueue: ";
    while( _size > 0 )
    {
      Agent& a = *agentsQueue[ _pp ];
      std::cout << a.getName() << ", "; 
      _pp = ((_pp+1) % capacity);
      _size--;
    }
    std::cout << std::endl;
  }

private:  
  Agent** agentsQueue;
  bool*   agentInQueue;
  std::unordered_map<int,int> agentID2queuePos;
  size_t size;
  size_t push_pos;
  size_t pop_pos;
  size_t capacity;
};

#endif
