#ifndef _ULISSE_MAILBOX_SYSTEM_HH_
#define _ULISSE_MAILBOX_SYSTEM_HH_

#include "globals.hh"

class Agent;
class Message;

/**
 * Stores the incoming and outgoing messages and it is associated
 * to a particular agent
 */ 
class MailboxSystem
{
public:

  /**
   * Default Constructor.
   */
  MailboxSystem();

  /**
   * Default Destructor.
   */
  ~MailboxSystem();
  
  /**
   * Initialize the Mailbox by assigning it the agent owner.
   */
  void initialize( Agent &a );
  
  /**
   * Read the incoming message.
   */
  Message* read( );

  /**
   * Process the incoming message.
   */
  void receive( Message& msg );

  /**
   * Send (and activate next agent) the outgoing message.
   */
  void send( Message& msg );

  // virtual process( Message* msg );

  /**
   * Returns the number of messages received (and not read).
   */
  size_t size() const
  {
    return mailboxInSize;
  }

  /**
   * Whether the mailbox contains no messages.
   */
  bool isEmpty() const
  {
    return mailboxInSize == 0;
  }

  /**
   * Reset the message size to 0; 
   */
  void reset()
  {
    mailboxInSize = 0;
  }

protected:
  // The agent associated to this mailbox.
  Agent* owner;

  // Links to incoming messages
  std::vector< Message* > incoming;

  // Before modify this i want to be sure it will work with 
  // the other algorithms
  // std::map< std::string, std::vector< Message* > > incoming2;
  // std::map< std::string, size_t > mailboxInSize2;

  size_t mailboxInSize;

  // Link to an outgoing message.
  Message* outgoing; // not used 

};



#endif
