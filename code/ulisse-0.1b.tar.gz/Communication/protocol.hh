#ifndef _ULISSE_PROTOCOL_HH_
#define _ULISSE_PROTOCOL_HH_

//#include "mailbox-system.hh"

class Agent;
class VariableOrdering;
class Constraint;
class MailboxSystem;


/**
 * Defines the behavior of a particular agent in terms of search within
 * its boundary variables and local variables, and communication with other
 * agents.
 */ 
class Protocol
{
public:

  virtual ~Protocol() {};
  /**
   * Links the Agent governing this protocol and initialize the messages 
   * source and destinations according to the VariableOrdering.
   */
  virtual void initialize( Agent& a, const VariableOrdering& O ) = 0;

  /**
   * Creates and initializes the mail-boxes of this agent's protocol.
   */
  virtual void initMailboxes( ) = 0;

  /**
   * Executes the protocol.
   */
  virtual void run() = 0;

  /**
   * Terminates the protocol.
   */
  virtual void terminate() = 0;

  /**
   * Accesses to the specific mailbox. 
   */
  virtual MailboxSystem& openMailbox( std::string type )
  {
    return *mailbox[ type ];
  }


protected:
  // Link to the agent over which this protocol is running.
  Agent* owner;

  // The mail-boxes assocaited to this agent (that is, where it can send 
  // and receive messages). There is a mailbox for each type of message,
  // and the number of mailboxes depends on the protocol adopted.
  std::map< std::string, MailboxSystem* > mailbox;

};

#endif
