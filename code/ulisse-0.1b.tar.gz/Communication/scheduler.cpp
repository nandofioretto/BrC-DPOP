#include "scheduler.hh"
#include "agent-queue.hh"
#include "agent.hh"

using namespace std;

Scheduler::Scheduler()
{ }


Scheduler::~Scheduler()
{ }


void Scheduler::start( vector<Agent*> initial_nodes )
{
  aQueue.initialize();

  for( auto a : initial_nodes ) {
    aQueue.push( *a );
  }

  while( not aQueue.isEmpty( ) )
  {
    Agent& exe = aQueue.pop();
    exe.runProtocol();
  }
}


void Scheduler::dump() const
{
  aQueue.dump();
}
