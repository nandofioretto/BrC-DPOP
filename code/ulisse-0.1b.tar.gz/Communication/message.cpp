#include "message.hh"
#include "agent.hh"

using namespace std;

Message::Message() 
  : src( 0 ), dest( 0 ) 
{ }


Message::~Message() 
{ }


Message::Message( const Message& other ) 
{
  src = other.src;
  dest = other.dest;
}


Message& Message::operator= (const Message& other) 
{
  if( this != &other)
  {
    src = other.src;
    dest = other.dest;
  }
  return *this;
}

