#ifndef _ULISSE_SCHEDULER_HH_
#define _ULISSE_SCHEDULER_HH_

#include "agent-queue.hh"
class Agent;

// This will be used as a global class when simulating a 
// decentralized system.
class Scheduler
{

public:

  Scheduler();

  ~Scheduler();

  void start( std::vector<Agent*> intial_nodes );
  
  void dump() const;

  AgentQueue aQueue;

};

#endif
