#include "mailbox-system.hh"
#include "agent.hh"
#include "message.hh"

using namespace std;

MailboxSystem::MailboxSystem() 
  : mailboxInSize( 0 )
{
  incoming.resize( g_agents.size() );
}

MailboxSystem::~MailboxSystem() 
{
  // nothing
}

void MailboxSystem::initialize( Agent &a ) 
{
  owner = &a;
  mailboxInSize = 0;
  incoming.resize( g_agents.size() );
}

Message* MailboxSystem::read( )
{
  if( mailboxInSize > 0 )
  {
    Message* cpy = incoming[ --mailboxInSize ];
    incoming[ mailboxInSize ] = 0;
    return cpy;
  }
  return 0;
}

void MailboxSystem::receive( Message& msg ) 
{
  // allocate more space if needed
  if( mailboxInSize == incoming.size() )
    incoming.resize( 2 * mailboxInSize );
  incoming[ mailboxInSize++ ] = &msg;
}

void MailboxSystem::send( Message& msg )
{
  msg.getDestination().openMailbox( msg.getType() ).receive( msg );
}
