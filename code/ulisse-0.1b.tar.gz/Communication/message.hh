#ifndef _ULISSE_MESSAGE_HH_
#define _ULISSE_MESSAGE_HH_

#include "globals.hh"

class Agent;

class Message
{
public:
  /**
   * Default Constructor.
   */
  Message();

  /**
   * Copy Constructor.
   */
  Message( const Message& other );

  /**
   * Default Destructor.
   */
  virtual ~Message();

  /**
   * Operator=.
   */
  virtual Message& operator= (const Message& other );

  /**
   * Get the message type.
   */
  virtual std::string getType() const = 0;

  /**
   * Reset message content (no touch header).
   */
  virtual void reset() = 0;

  /**
   * Dump on screen message content.
   */ 
  virtual void dump() = 0;

  /**
   * Return the source Agent.
   */
  Agent& getSource() const
  {
    return *src;
  }

  /**
   * Return the Destination Agent.
   */
  Agent& getDestination() const
  {
    return *dest;
  }

  /**
   * Set the Agent source.
   */
  void setSource (Agent& a)
  {
    src = &a;
  }
  
  /**
   * Set the Agent destination.
   */
  void setDestination (Agent& a)
  {
    dest = &a;
  }

protected:
  // Agent source
  Agent* src;
 
  // Agent destination
  Agent* dest;
   
};

#endif
