#include "search-solution.hh"

Solution::Solution() 
{
  // noting
}


Solution::~Solution() 
{
  // nothing
  values.clear();
}


Solution::Solution( const Solution& other )
{
  values = other.values;
  cost   = other.cost;
}

Solution& Solution::operator=( const Solution& other )
{
  if( this != &other )
  {
    values = other.values;
    cost   = other.cost;
  }
  return *this;
}

void Solution::initialize( int size )
{
  values.resize( size, NA_VALUE );
  cost = NA_VALUE;
}

void Solution::dump() const
{
  for( auto i : values )
    std::cout << i << " ";
  std::cout << " | " << cost << std::endl; 
}
