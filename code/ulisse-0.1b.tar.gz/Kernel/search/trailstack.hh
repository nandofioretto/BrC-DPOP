/*********************************************************************
 * Trail Stack implementation
 *********************************************************************/
#ifndef _ULISSE_SEARCH_TRAILSTACK_H_
#define _ULISSE_SEARCH_TRAILSTACK_H_

#include "globals.hh"
#include "trail-variable.hh"

class TrailVariable;

class TrailStack 
{
 public:
  /**
   * Default constructor.
   */
  TrailStack();

  /**
   * Distructor.
   */
  ~TrailStack();
  
  /**
   * Restores the states of the variables inserted in the trailstack 
   * up to the "continuation" instant.
   * 
   * todo: Integrate Constraint Fixpoint treatment
   */ 
  void backtrack (size_t continuation);

  /**
   * Checks wheter the trail-stack is empty.
   */
  bool isEmpty() const
  {
    return varStack.empty();
  }

  /**
   * Returns the trail-stack size.
   */
  size_t size() const
  {
    return varStack.size();
    // + constrFix_trailstack.size();
  }

  /** 
   * Resets the trail-stack.
   */
  void reset ();
  
  /**
   * Inserts a variable in the trail stack, saving its current state.
   *
   * @todo: IMPROVE EFFICIENCY
   */
  void trailVariable (var_int& v);
  
  /**
   * Inserts a constraint ID in the trail stack to indicate
   * it reached the fixpoint.
   */
  void trailConstrFixpt( int c_id ) 
  { 
    // @todo
  }

private:
  // the trail-stack for the variable state.
  std::stack < TrailVariable > varStack;
  
  // the trail-stack for the constraints which have reached the fixpoint.
  std::stack < int > constrFixStack; // @todo NOT USED NOW

};

#endif
