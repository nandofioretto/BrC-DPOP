#ifndef _ULISSE_STORE_HH_
#define _ULISSE_STORE_HH_

#include "globals.hh"

template<class T> 
class Store
{

public:
  Store()
  {
    size = 0; 
    capacity = 0;
  }

  ~Store() {}
  
  void init( std::vector< T > elems )
  {
    for( int i=0; i<elems.size(); i++ ) {
      store.push_back( elems[ i ] );
      container.push_back( elems[ i ] );
    }
    capacity = elems.size();
    
    inStore.resize( capacity, false );
    size = 0;
    
    ID2storePos.reserve( capacity );
    for( int i=0; i<capacity; i++ ) {
      ID2storePos[ elems[ i ] ] = i;
    }
  }

  /**
   * @complexity: O(1)
   */
  void consume( T id )
  {
    inStore[ ID2storePos[ id ] ] = false;
  }

  /**
   * @complexity: O(1)
   */
  bool contains( T id )
  {
    return inStore[ ID2storePos[ id ] ];
  }

  /**
   * @complexity: O(1)
   */
  bool belongsTo( T id )
  {
    return( ID2storePos.find( id ) != ID2storePos.end() );
  }

  /**
   * @complexity: O(1)
   */
  void push( T id )
  {
    // check whether the element belongs to the store and 
    // it is not already in it
    if( belongsTo( id ) and (not contains( id )) )
    {
      store[ size++ ] = id;
      inStore[ ID2storePos[ id ] ] = true;
    }
  }

  /**
   * @complexity: O(1)
   */
  void pop( )
  {
    inStore[ ID2storePos[ store[ --size ] ] ] = false;
  }

  /**
   * @complexity: O(1)
   */
  T top( )
  {
    return store[ size-1 ];
  }

  /**
   * @complexity: O(1)
   */
  T ttop( )
  {
    T id = top();
    pop();
    return id;
  }

  /**
   * @complexity: O(size)
   */
  void flush()
  {
    while( size > 0 )
      pop();
   }

  size_t getSize() const
  {
    return size;
  }

  size_t getCapacity() const
  {
    return capacity;
  }

  T& at( int pos ) 
  {
    return container[ pos ]; 
  }

  std::vector< T >& getStoreContent()
  {
    return container;
  }

  private:
  // all the elements listed here
  std::vector< T > container;
  // the queue of elements
  std::vector< T > store;
  // Marks the presence of each element in the vector store.
  std::vector< bool > inStore;
  // current size (marked elements) of the store
  size_t size;
  // actual capacity of the queue.
  size_t capacity;
  // key   = the item ID of the store
  // value = its position in the array "store"
  std::unordered_map<T, int> ID2storePos;

};

#endif
