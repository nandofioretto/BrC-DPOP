#ifndef _ULISSE_SEARCH_DOMAIN_HH_
#define _ULISSE_SEARCH_DOMAIN_HH_

#include "globals.hh"

class var_int;

enum event_type { NULL_EVENT=0,
		  NOT_CHANGED_EVENT=1,
		  FIX_EVENT=2,
		  NB_STATIC_EVENTS=3,
		  FAILED_EVENT=4, 
		  SING_EVENT=5, 
		  BC_EVENT=6, 
		  DC_EVENT=7, 
		  NB_EVENTS };

class SearchDomain 
{ 
 public:
  
  SearchDomain ();
  SearchDomain ( std::vector<int> elements );
  SearchDomain ( const SearchDomain& other );
  SearchDomain& operator= ( const SearchDomain& other );
  ~SearchDomain ();

  // Domain Operations
  int operator [] ( int pos ) const
  {
    return _values[ pos ];
  }

  void init( std::vector<int> elements );

  void add( int elem );

  void set_vptr( var_int* v )
  {
    _var_ptr = v;
  }

  var_int* var_ptr()
  {
    return _var_ptr;
  }

  std::vector<bool> state ()
  {
    return _state;
  }

  void set_state ( std::vector<bool> other_state );

  // quick, no checks, no updates
  void copy_state( std::vector<bool> other_state )
  {
    _state = other_state;
  }
  
  void set_singleton ( int pos )
  {
    for( int i=0; i<_size; i++)
      _state[ i ] = false;
    
    _state[ pos ] = true;
    _min = _max = pos;
    _nactive = 1;
    _event = SING_EVENT;
  }

  void set ();
  void set ( int pos );
  void unset ();
  void unset ( int pos );
  void set_lb( int pos );
  void set_ub( int pos );

  // assumes val is an element of domain
  int get_pos( int val )
  {
    if( val < _values[ 0 ]) return -1;
    if( val > _values[ _size-1 ] ) return -2;
    return value2pos[ val ];
  }

  // int getPosFromValue( int val )
  // {
  //   if( val < _values[ 0 ] ) return -1;
  //   if( val > _values[ _size-1 ] ) return -2;
  //   return map_value2pos[ val + d_min ];
  // }

  bool is_valid () const
  {
    return ( _nactive > 0 ); 
  }

  bool is_failed () const
  {
    return ( !is_valid() );
  }

  bool is_valid ( int pos )
  {
    if( pos < _min || pos > _max ) return false;
    return ( _state[ pos ] );
  }

  bool is_singleton( ) const
  {
    return ( _nactive == 1 );
  }

  bool is_active( int pos )
  {
    return _state[ pos ];
  }
  
  bool is_active_val( int val )
  {
    return is_valid( value2pos[ val ] ); //map_value2pos[ val + d_min ] );
  }
  
  bool isInBounds( int pos ) const
  {
    return ( pos >= _min and pos <= _max );
  }

  // min val in domain 
  int min() const
  {
    return _values[ 0 ];
  }

  // max val in domain
  int max() const
  {
    return _values[ _size ];
  }

  // min active val in domain
  int lb() const
  {
    return _values[ _min ];
  }
  
  // max active val in domain
  int ub() const
  {
    return _values[ _max ];
  }
  
  // index of lb
  int lb_pos() const
  {
    return _min;
  }
  
  // index of ub
  int ub_pos() const
  {
    return _max;
  }
  
  // for fast bound propagation
  // Note: _nactive can by < 0 ! to check??
  // Note: we always assume the bound won't be > max
  void move_ub( short u )
  {
    _nactive -= ( _max - u );
    _max = u;
    _event = BC_EVENT;
    //  if( _nactive == 1 ) _event = SING_EVENT;
  }

  void move_ub_val( int val )
  {
    move_ub( value2pos[ val ] ); // map_value2pos[ val + d_min ] );
  }

  // for fast bound propagation
  // Note: _nactive can by < 0 ! to check??
  // Note: we always assume the bound won't be < min
  void move_lb( short l )
  {
    _nactive -= ( l - _min );    
    _min = l;
    _event = BC_EVENT;
  }

  void move_lb_val( int val )
  {
    move_lb( value2pos[ val ] );//map_value2pos[ val + d_min ]);
  }

  // used to restore var state
  void copy_bounds( short l, short u )
  {
    _min = l; _max = u;
  }
  
  int n_active() const
  {
    return _nactive;
  }

  // used to restore var state
  void copy_n_active( short n )
  {
    _nactive = n;
  }

  void copy_singleton( int pos )
  {
    _min = _max = pos;
    _nactive = 1;
    _event = SING_EVENT;
  }

  void copy_singleton_val( int val )
  {
    copy_singleton( value2pos[ val ] ); //map_value2pos[ val + d_min ] );
  }

  void set_event( event_type event )
  {
    _event = event;
  }

  event_type event() const
  {
    return _event;
  }
  
  int size()
  {
    return _size;
  }

  void dump () const;

 private:
  std::vector< int > _values;
  std::vector< bool > _state;
  // int* map_value2pos;
  // int d_min; int d_max;
  std::unordered_map<int, int> value2pos;
  short _size;
  short _min; // min active state
  short _max; // max active state
  short _nactive; // num of active elements
  event_type _event; // 
  var_int* _var_ptr;
 
};

#endif
