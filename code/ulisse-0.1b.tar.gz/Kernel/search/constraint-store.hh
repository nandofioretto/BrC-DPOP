#ifndef _ULISSE_CONSTRAINT_STORE_HH_
#define _ULISSE_CONSTRAINT_STORE_HH_

#include "globals.hh"
#include "store.hh"
#include "propagator.hh"
#include "cvm-propagator.hh"
#include "var_int.hh"

class var_int;
class Constraint;
class TrailStack;
class Propagator;
class IntHardConstraint;
class CVMPropagator;


class ConstraintStore 
{  
public:
  /**
   * Default Constructor
   */
  ConstraintStore();

  /**
   * Default Destructor
   */
  ~ConstraintStore();

  /**
   * Initializes the constraint store. 
   * - cons: all the constraints that can be possibly stored in the queue.
   * - vars: all the variables which can wake up constraints in 'cons'.
   * - t     the trailstack used in the search to be linked to the propagator.
   */ 
  void initialize( std::vector<IntHardConstraint*> cons, std::vector<var_int*> vars,
		   TrailStack* t  );

  /**
   * Constraints added to the queue during variable selection.
   * Add an event only if the variable has been touched by the
   * labeling step or by the propagation of another variable.
   *
   * @complexity: O( n ) 
   *   with n = num of constraints whose scope contains v. 
   */
  void signalVarChanged( var_int& v )
  {
    if ( v.getDomain().event() == NOT_CHANGED_EVENT ) { 
      return;
    }
    varchangedQueue.push( &v );
  }

  /**
   * Constraints involving variable v are added to the queue.
   *
   * @complexity: O( n ) 
   *   with n = num of constraints whose scope contains v. 
   */
  void enqueueVarChanged( var_int& v )
  {
    varchangedQueue.push( &v );
  }

  /**
   *
   */
  void addConstraintsToQueue( var_int& v );

  /**
   * Flushes the constraint and the variable queues.
   */
  void flush();
  
  /**
   * Flushes the constraint and the variable queuees and restores the 
   * constraints fixpoint information.
   */
  void reset();

  /**
   * Call the specific propagator for the woken up constraint.
   * @todo: change name in AC6-event-based 
   */
  bool iSolveFix ();

  /**
   * Call the specific propagator for the woken up constraint.
   * Modifies the constraint value matrices associated to the 
   * revising arcs and changes the variables domains via propagation. 
   */
  bool AC4_CVM ();

  bool initCVM();

 private:
  // The store of constraints.
  Store<IntHardConstraint*> constraintQueue;

  // variable changed by constraint propagation.
  Store<var_int*> varchangedQueue;

  // An instance of the propagator class
  Propagator propagator;

  // An instance of the propagator class
  CVMPropagator cvm_propagator;

};//-

#endif
