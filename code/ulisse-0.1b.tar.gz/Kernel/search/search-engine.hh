#ifndef _ULISSE_DCOP_SEARCH_ENGINE_HH_
#define _ULISSE_DCOP_SEARCH_ENGINE_HH_

#include "globals.hh"
#include "search-solution.hh"

class Agent;
class VariableOrdering;
class Solution;
class ExtSoftConstraint;
class IntHardConstraint;

/**
 * The DCOP Search Engine.
 * This class implements a search engine used to explore the value assignemnts
 * for the boundary variables of a given Agent.
 */
class SearchEngine
{
public:

  /**
   * Default constructor.
   */
  SearchEngine();

  /**
   * Default destructor.
   */
  virtual ~SearchEngine();

  /**
   * Initializes the agent associated to this search engine, 
   * the variables over which perform the search and 
   */
  virtual void initialize( Agent& a ) = 0;
  
  /**
   * Init search settings, as scope of the search, solutions, etc.
   */
  virtual void initSearchSettings() = 0;
  
  /**
   * Popolate the hard constraints involved in the search.
   */
  virtual void initHardConstraints() = 0;
  
  /**
   * Popolate the soft constraints involved in the search.
   */
  virtual void initSoftConstraints() = 0;
  
  /**
   * Reset search state.
   */
  virtual void reset() = 0;

  /**
   * Finds the next satisfiable solution in the given enumeration 
   * of the solution space.
   */
  virtual bool nextSolution() = 0;
  
  /**
   * Finds the assignment to the variables in scope which optimizes
   * the local cost.
   */
  virtual bool bestSolution() = 0;
  
  /**
   * Finds all possible satisfiable solutions.
   */
  virtual bool allSolutions() = 0;

  /**
   * Simplify the CSP by calling the Consistency function 
   * proper of the search engine.
   */
  virtual bool reduce() 
  { 
    return true;
  };

  // Creates the Reachability Value Matrices associated to each 
  // constraint of the search.
  virtual bool initCVM() { return true; };
  
  /**
   * Returns the last found. 
   */
  virtual Solution& getSolution()
  {
    return curr_solution;
  }
  
  /**
   * Returns the best found. 
   */
  virtual Solution& getBestSolution()
  {
    return best_solution;
  }

  /**
   * Initialize Map varID -> scopePos
   */ 
  void initMapScope2Vars();

  /**
   * Returns whether the search is terminated. 
   */
  bool isTerminated() 
  {
    return searchEnded;
  }

  /**
   * Returns all the solutions found.
   */
  std::vector<Solution>& getAllSolutions()
  { 
    return solutions; 
  }
  
  /**
   * Returns the scope of the search.
   */
   std::vector<var_int*>& getScope()
  {
    return scope;
  }
 
  std::vector<var_int*>& getScopeInHardConstr()
  {
    return varsIn_hardConstraints;
  }

  std::vector<var_int*>& getScopeInSoftConstr()
  {
    return varsIn_softConstraints;
  }
  
  /**
   * Returns the scope size.
   */
  size_t getScopeSize() const
  {
    return scope.size();
  }

  /**
   * Returns the map scope to variable ID
   */
  int* getScope2varID()
  {
    return scopePos2varID;
  } 
  
  /**
   * Returns the map scope to variable ID
   */
  int* getVarID2scope()
  {
    return varID2scopePos;
  }

  /**
   * Copies the current solution to the best solution if the former
   * cost is better than the current best.
   */
  void updateBestSolution()
  {
    if( best_solution.getCost() == NA_VALUE 
	or
	isBetter( curr_solution.getCost(),
		  best_solution.getCost() ) )
      {
	best_solution = curr_solution;
      }
  }


  virtual void dump() const = 0;
  
protected:
  // Link to the agent executing this search.
  Agent* owner;
  
  // The scope of the search.
  std::vector<var_int*> scope;

  // The set of solutions found, when all_solution is chosen as a search option.
  std::vector< Solution > solutions;
  
  // The current solution found. 
  Solution curr_solution;
  
  // The best solution found.
  Solution best_solution;

  // boolean flag which is activated if the search has ended
  bool searchEnded;

  // Contains all soft constraints (intensional and extensional representation)
  // involved in this search engine. 
  std::vector< ExtSoftConstraint* > softConstraints;
  // The variables involved in some hard constraint stored in the vector above. 
  std::vector< var_int* > varsIn_softConstraints; // not used now

  // Contains all hard constraints (intensional and extensional representation)
  // involved in this search engine. 
  std::vector< IntHardConstraint* > hardConstraints;
  std::vector< var_int* > varsIn_hardConstraints;
  
  // The query to be used to retrieve the cost of a soft constraint.
  // @note: this is a temporary solution.
  int* query; 

  // TODO: check if this should be here or not...
  // Maps the i-th element in scope to the varialbe ID it represent.
  int* scopePos2varID;  	// scope position -> variableID
  int* varID2scopePos;		// variableID -> scope position  
  
};

#endif
