#ifndef _ULISSE_EXT_SOFT_CONSTRAINT_7_HH_
#define _ULISSE_EXT_SOFT_CONSTRAINT_7_HH_

#include "globals.hh"
#include "ext-soft-constraint.hh"
#include <rapidxml.hpp>
#include <boost/functional/hash.hpp>

using namespace rapidxml;


class ExtSoftConstraint7 : public ExtSoftConstraint 
{
 public:
 
  ExtSoftConstraint7( xml_node<>* relation )
  {
    initialize( relation, this );
  }

  void setCost( int* K, cost_type cost )
  {
    utilities[ {K[0], K[1], K[2], K[3], K[4], K[5],
	        K[6]} ] = cost;
  }
    
  /**
   * Return the cost associated to the tuple.
   * K *must* have size 3.
   */
  cost_type getCost ( int* K )
  {

    got = utilities.find ({K[0], K[1], K[2], K[3], K[4], K[5], 
	                  K[6]});
    if( got == utilities.end() ) return defaultCost;

    return utilities[ {K[0], K[1], K[2], K[3], K[4], K[5],
	               K[6]} ];
  }
  
  void dump()
  {
    std::cout << "Extensional Soft Constraint (7)\n";
  }

 private:

  struct Key
  {
    int a; int b; int c;
    int d; int e; int f;
    int g;
    
    bool operator==(const Key &other) const
    { return (a == other.a && b == other.b && c == other.c &&
	      d == other.d && e == other.e && f == other.f &&
	      g == other.g); }
  };
  
  struct KeyHasher
  {
    std::size_t operator()(const Key& k) const
    {
      using boost::hash_value;
      using boost::hash_combine;
      std::size_t seed = 0;
      
      hash_combine(seed,hash_value(k.a));
      hash_combine(seed,hash_value(k.b));
      hash_combine(seed,hash_value(k.c));
      hash_combine(seed,hash_value(k.d));
      hash_combine(seed,hash_value(k.e));
      hash_combine(seed,hash_value(k.f));
      hash_combine(seed,hash_value(k.g));
      
      return seed;
    }
  };
  
  // The list of utilities
  std::unordered_map<Key,cost_type,KeyHasher> utilities;
  std::unordered_map<Key,cost_type,KeyHasher>::const_iterator got;

};


#endif
