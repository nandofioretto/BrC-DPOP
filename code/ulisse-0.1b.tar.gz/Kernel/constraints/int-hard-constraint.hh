#ifndef _ULISSE_INT_HARD_CONSTRAINT_HH_
#define _ULISSE_INT_HARD_CONSTRAINT_HH_

#include "globals.hh"
#include "constraint.hh"
#include <rapidxml.hpp>

using namespace rapidxml;


class IntHardConstraint : public Constraint 
{
public:
  /**
   * Default Constructor.
   */
  IntHardConstraint (rapidxml::xml_node<>* relation);

  /**
   * Copy Constructor.
   */
  IntHardConstraint (const IntHardConstraint& other);

  /**
   * Default Distructor.
   */
  ~IntHardConstraint();

  /**
   * Operators
   */
  virtual IntHardConstraint& operator= (const IntHardConstraint& other);

  /**
   * 
   */
  virtual void dump();


  std::string getConstrType() const
  {
    return constrType;
  }

  size_t numofIntCoef() const
  {
    return intCoefficients.size();
  }

  size_t numofRealCoef() const
  {
    return realCoefficients.size();
  }

  int getIntCoef( int pos ) const
  {
    return intCoefficients[ pos ];
  }

  int getRealCoef( int pos ) const
  {
    return realCoefficients[ pos ];
  }

  void setFixpoint() 
  {
    atFixpoint = true;
  }

  void unsetFixpoint() 
  {
    atFixpoint = false;
  }
  
  bool isAtFixpoint() const
  {
    return atFixpoint;
  }

 private:  
  // The relation name
  std::string constrType;
  
  // A vector of integer coefficients
  std::vector<int> intCoefficients;

  // A vector of real coefficients
  std::vector<double> realCoefficients;

  // Fixpoint reached -- do not propagate during same cycle of AC
  bool atFixpoint;
  
  // Fixpoint reached -- never propagate the constraint anymore
  // (unless problem restars)
  bool atPermFixPoint;		// not used

};


#endif
