#ifndef _ULISSE_RELATION_HH_
#define _ULISSE_RELATION_HH_

#include "globals.hh"

class var_int;

class Relation 
{
 public:

  Relation();
  /**
   * Default Distructor.
   */
  virtual ~Relation();

  /**
   * Operator=
   */
  virtual Relation& operator= (const Relation& other);

  /**
   * Print relation on screen
   */
  virtual void dump() { };

  /**
   * Operator==
   */
  bool operator== (const Relation& other)
  {
    return relID == other.relID;
  }

  /**
   * Operator<
   */
  bool operator< (const Relation& other)
  {
    return relID < other.relID;
  }
    
  /**
   * Returns the relation name.
   */
  std::string getName()
  {
    return relationName;
  }

  /**
   * Returns the realtion ID.
   */
  size_t getID()
  {
    return relID; 
  }
  
  /**
   * Returns the arity of the constraint associated with this relation.
   */
  int getArity()
  {
    return arity; 
  }

  /**
   * The scope as given from the constraint definition associated to 
   * this relation.
   */
  void setScope( std::vector<var_int*> c_scope )
  {
    scope = c_scope;
  }
  
  var_int& getScopeVar( int pos )
  {
    return *scope[ pos ];
  }

protected:
  // The relation ID.
  size_t relID;
  
  // The relation name
  std::string relationName;
  
  // The arity of the relation
  int arity;

  // Semantic of relation 
  std::string semantics;

  // The scope of the constraint (copied)
  std::vector<var_int*> scope; 
  
};


#endif
