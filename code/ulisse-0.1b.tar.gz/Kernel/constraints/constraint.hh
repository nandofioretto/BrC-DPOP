#ifndef _ULISSE_CONSTRAINT_HH_
#define _ULISSE_CONSTRAINT_HH_

#include "globals.hh"
#include <rapidxml.hpp>

class var_int;

enum constraint_type { extHard, extSoft, intHard, intSoft };


class Constraint
{
public:

  /**
   * Default constructor
   */
  Constraint();

  /**
   * Copy constructor
   */
  Constraint (const Constraint& other);

  /**
   * Destructor.
   */
  virtual ~Constraint() = 0;

  /**
   * Assignment operator
   */
  virtual Constraint& operator= (const Constraint& other);

  /**
   * Summary Print.
   */
  virtual void dump() const;

  /**
   * @note:used by search function
   */
  bool operator== (const Constraint& other)
  {
    return (constrID == other.constrID);
  }

  /**
   * Ordering criteria.
   */
  bool operator< (const Constraint& other)
  {
    return constrID < other.constrID;
  }  

  /**
   * Returns the constraint ID.
   */
  size_t getID() const
  {
    return constrID; 
  }

  /**
   * Returs the constraint name.
   */
  std::string getName() const
  {
    return constraintName;
  }
  
  /**
   * Returns the constraint arity.
   */
  int getArity() const
  {
    return arity; 
  }

  /**
   * Returns the constraint scope.
   * TO AVIOD
   */
  std::vector< var_int* > getScope() const
  {
    return scope;
  }

  /**
   * Get the pos-th variable in the constraint scope.
   */
  var_int& getScopeVar( size_t pos ) const
  {
    return *scope[ pos ];
  }

  /**
   * Returns the vector of the variable's IDs.
   * DEPRECATED?
   */
  std::vector<int> getVars() const;

  /**
   * Checks whether the variable v is involved in the constraint.
   */
  bool hasInScope( const var_int& v);

  /**
   * Returns the constraint type.
   */
  constraint_type getType()
  {
    return type; 
  }

  /**
   * Set the constraint type.
   */
  void setType( constraint_type t )
  {
    type = t;
  }


protected:
  // The constraint_typeaint id (1...nconstr)
  size_t constrID;

  // The constraint name, which is a unique id
  std::string constraintName;

  // The constraint type
  constraint_type type;

  // The constraint arity
  int arity;
  
  // The scope of the constraint
  std::vector< var_int* > scope; 

};


#endif
