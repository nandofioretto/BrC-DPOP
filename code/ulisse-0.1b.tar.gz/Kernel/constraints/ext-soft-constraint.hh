#ifndef _ULISSE_EXT_SOFT_CONSTRAINT_HH_
#define _ULISSE_EXT_SOFT_CONSTRAINT_HH_

#include "globals.hh"
#include "constraint.hh"
#include <rapidxml.hpp>

using namespace rapidxml;


class ExtSoftConstraint : public Constraint 
{
 public:
  /**
   * Default Constructor.
   */
  ExtSoftConstraint ();

  /**
   * Copy Constructor.
   */
  ExtSoftConstraint (const ExtSoftConstraint& other);

  /**
   * Default Distructor.
   */
  ~ExtSoftConstraint();
    
  /**
   * Initializes the Constraint for efficient handling.
   */
  void initialize(rapidxml::xml_node<>* constraint, ExtSoftConstraint* Rptr );

  /**
   * Assignment Operator
   */
  virtual ExtSoftConstraint& operator= (const ExtSoftConstraint& other );

  /**
   *
   */
  virtual void dump();
  
  
  virtual void setCost( int* K, cost_type cost ) = 0;


  virtual cost_type getCost( int* K ) = 0;


 protected:
  // The number of value combinations in the relation
  size_t nb_tuples;
  
  // Default cost, that is the cost associated to any value combination
  // that is not present in _uit
  cost_type defaultCost;
};


#endif
