#include "int-hard-constraint.hh"
#include "constraint.hh"
#include "var_int.hh"
#include <rapidxml.hpp>

using namespace std;
using namespace rapidxml;


// @todo
IntHardConstraint::IntHardConstraint( xml_node<>* relation ) 
  : atFixpoint( false )
{
  // constraint parameters:
  type = intHard;

  // Read Constraint Properties
  constraintName  = relation->first_attribute("name")->value();
  arity = atoi( relation->first_attribute("arity")->value() );
  constrType = relation->first_attribute("ctype")->value();
  int n_int_coef = atoi( relation->first_attribute("nintcoef")->value() );
  int n_real_coef = atoi( relation->first_attribute("nrealcoef")->value() );
  
  string p_scope = relation->first_attribute("scope")->value();
  scope.resize( arity );
  stringstream ss( p_scope);
  int c = 0; string var;
  while( c < arity ) 
  {
    ss >> var;
    scope[ c++ ] = g_variables[ var ];
    g_variables[ var ]->addConstraint( *this );
  }
  
  string i_coef = relation->first_attribute("intcoef")->value();
  stringstream ss_ic( i_coef);
  intCoefficients.resize( n_int_coef ); 
  int ic;
  for( int i=0; i< n_int_coef; i++ )
  {
    ss_ic >> ic;
    intCoefficients[ i ] = ic;
  }
  
  string r_coef = relation->first_attribute("realcoef")->value();
  stringstream ss_rc( r_coef);
  realCoefficients.resize( n_real_coef ); 
  double rc;
  for( int i=0; i< n_real_coef; i++ )
  {
    ss_rc >> rc;
    realCoefficients[ i ] = rc;
  }
  
  //g_constraints[ constraintName ] = this;
 
}


IntHardConstraint::IntHardConstraint (const IntHardConstraint& other)
{
  constrID   = other.constrID;
  constraintName   = other.constraintName; 
  type  = other.type;
  arity = other.arity;
  scope = other.scope;

  constrType = other.constrType;
  intCoefficients  = other.intCoefficients;
  realCoefficients = other.realCoefficients;
  atFixpoint = other.atFixpoint;
}


IntHardConstraint& IntHardConstraint::operator= (const IntHardConstraint& other)
{
  if( this != &other )
  {
    constrID   = other.constrID;
    constraintName   = other.constraintName; 
    type  = other.type;
    arity = other.arity;
    scope = other.scope;
    
    constrType = other.constrType;
    intCoefficients  = other.intCoefficients;
    realCoefficients = other.realCoefficients;
    atFixpoint = other.atFixpoint;
  }
  return *this;
}


IntHardConstraint::~IntHardConstraint()
{
  //nothing
}


void IntHardConstraint::dump() 
{ 
  cout << "IntHardConstraint: " << constraintName << " arity: " << arity 
       << " constr-type: (" << constrType << ") fixpt: " << atFixpoint << endl;
  cout << "Scope: ";
  for( auto s : scope )
    cout << s->getName() << " " ;
  cout << endl;
  cout << "Int Coefficients: ";
  for( int i=0; i<intCoefficients.size(); i++ )
    cout << intCoefficients[ i ] << " ";
  cout << "\nReal Coefficients:  ";
  for( int i=0; i<realCoefficients.size(); i++ )
    cout << realCoefficients[ i ] << " ";
  cout << endl;
}
