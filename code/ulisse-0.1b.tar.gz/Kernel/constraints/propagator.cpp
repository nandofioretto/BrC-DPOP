#include "propagator.hh"
#include "search-domain.hh" // contains enum events
#include "constraint.hh" // contains constr_type
#include "int-hard-constraint.hh"
#include "var_int.hh"
#include "trailstack.hh"
#include "constraint-store.hh"

using namespace std;

//#define DBG
#define BOUND_CONSISTENCY


Propagator::Propagator()
{
  // nothing
}

Propagator::~Propagator() 
{
  // nothing
}

void Propagator::initialize( TrailStack* t, ConstraintStore* s )
{
  trailstack = t;
  constraintStore = s;
}


bool Propagator::consistency( var_int& v )
{
  int event = v.getDomain().event();

  // PROPAGATOR ACTING ON BOUNDS ONLY
  switch( event )
  {
    case BC_EVENT:
    case DC_EVENT:
      if( v.getDomain().n_active() <= 0 or
	  v.getDomain().lb_pos() > v.getDomain().ub_pos() ) {
	return false;
      }
      break;
    case FAILED_EVENT: 
      return false;
    case SING_EVENT:
      break;
    case NULL_EVENT:
      // This was the first time this variable was touched by 
      // propagation and its domain did not change.
      v.getDomain().set_event( NOT_CHANGED_EVENT );
      break;
    case NOT_CHANGED_EVENT:
      break;	// no need to check 
    }
  return true; 
}


bool Propagator::propagate( IntHardConstraint &r )
{
  // propagator p = select( r );
  // if( p == NULL) return false;

  // return (  p( r ) );

  if( r.isAtFixpoint() )
    return true; // do not propagate if it is at fixpoint

  std::string c_name = r.getConstrType();
  if( c_name == "int_NE" )
    return c_int_NE( r );
  else if( c_name == "int_EQ")
    return c_int_EQ( r );
  else if( c_name == "int_LT")
    return c_int_LT( r );
  else if( c_name == "int_LEQ")
    return c_int_LEQ( r );
  else if( c_name == "int_GT")
    return c_int_GT( r );
  else if( c_name == "int_GEQ")
    return c_int_GEQ( r );
  else if( c_name == "int_PLUS_EQ")
    return c_int_PlusEQconst( r );
  else if( c_name == "int_LIN_EQ")
    return c_int_lin_EQ( r );
  else if( c_name == "int_LIN_LEQ")
    return c_int_lin_LEQ( r );
  else if( c_name == "int_LIN_GEQ") 
    return c_int_lin_GEQ( r );
  else if( c_name == "int_within_iff")
    return c_int_within_iff( r );
  else if( c_name == "abs_int_sub_int_gt_int")
    return c_abs_int_sub_int_gt_int( r );
  else
    return true;
}


// @note: only bound consistency implemented.
// @note: Once the constraint has been propagated, 
//        a AC fixpoint is reached---no need to propagate this constraint
//        during the same AC loop.
bool Propagator::c_int_EQ( IntHardConstraint &r )
{
  var_int& var_x = r.getScopeVar( 0 ); // @todo
  var_int& var_y = r.getScopeVar( 1 ); // @todo
  int x_lb = var_x.getDomain().lb();
  int y_lb = var_y.getDomain().lb();

  // case A and B singletons.
  if( var_x.getDomain().is_singleton() and 
      var_y.getDomain().is_singleton() )
    {
      r.setFixpoint();
      // Fails if both domains contain different element
      if( x_lb != y_lb ) return false;
    }
  else if( var_x.getDomain().is_singleton() ) 
    {
      // propagate on var_y (set singleton)
      if( not var_y.getDomain().is_active_val( x_lb ) )
	return false;

      // propagate on var_y (set singleton)
      trailstack->trailVariable( var_y );
      var_y.getDomain().copy_singleton_val( x_lb );
      // signal change of variable in the constraint store
      r.setFixpoint();
      constraintStore->signalVarChanged( var_y );
    }
  else if( var_y.getDomain().is_singleton() )
    {
      if( not var_x.getDomain().is_active_val( y_lb ) )
	return false;
     
      // propagate on var_x (set singleton)
      trailstack->trailVariable( var_x );
      var_x.getDomain().copy_singleton_val( y_lb );
      // signal change of variable in the constraint store
      r.setFixpoint();		// set this constarint at Fixpoint
      constraintStore->signalVarChanged( var_x );
    }
  else 
    { // if both are ground domain consistency.
      // Here Fixpoint is not valid
#ifdef BOUND_CONSISTENCY
      // @todo: signal var changed here
      // Lower Bound
      trailstack->trailVariable( var_x );
      trailstack->trailVariable( var_y );

      if( var_x.getDomain().lb() < var_y.getDomain().lb() ) 
	var_x.getDomain().move_lb( var_y.getDomain().lb_pos() );
      else if( var_y.getDomain().lb() < var_x.getDomain().lb() )
	var_y.getDomain().move_lb( var_x.getDomain().lb_pos() );
      
      // Upper Bound
      if( var_x.getDomain().ub() > var_y.getDomain().ub() ) 
	var_x.getDomain().move_ub( var_y.getDomain().ub_pos() );
      else if( var_y.getDomain().ub() > var_x.getDomain().ub() )
	var_y.getDomain().move_ub( var_x.getDomain().ub_pos() );
#endif
    }
  return true;

}


// var_x != var_y
// int_ne( a, b )
// @todo: Manage AUX variables
bool Propagator::c_int_NE( IntHardConstraint &r )
{
  return true;
  printWarningMessage( "c_int_NE: only bound consistency implemented" );

  var_int& var_x = r.getScopeVar( 0 );
  var_int& var_y = r.getScopeVar( 1 ); 
  //cout << "NE constr: " << var_x.getName() << " " << var_y.getName() << endl;

  // case A and B singletons.
  // var_x.getDomain().event() == SING_EVENT 
  if( var_x.getDomain().is_singleton()
      and 
      var_y.getDomain().is_singleton() )
    {
      r.setFixpoint();
      // Fails if both domains contain the same element
      if( var_x.getDomain().lb() == var_y.getDomain().lb() )
	return false;
    }
  else if( var_x.getDomain().is_singleton() ) 
    {
#ifdef DBG
      cout << "NE: A singleton\n";
#endif
      // propagate on var_y
      trailstack->trailVariable( var_y );
      // domain events are updated within the function
      var_y.getDomain().unset( var_x.getDomain().lb_pos() );
      // signal change of variable in the constraint store
      r.setFixpoint();
      constraintStore->signalVarChanged( var_y );
    }
  else if( var_y.getDomain().is_singleton() )
    {
#ifdef DBG
      cout << "NE: B singleton\n";
#endif
      // propagate on var_x
      trailstack->trailVariable( var_x );
      // domain events are updated within the function.
      var_x.getDomain().unset( var_y.getDomain().lb_pos() );
      // signal change of variable in the constraint store
      r.setFixpoint();
      constraintStore->signalVarChanged( var_x );
    }
  else
    {
      // nothing
    }
  return true;
}


// a < b 
// @note: only bound consistency implemented.
// @note: Once the constraint has been propagated, 
//        a AC fixpoint is reached---no need to propagate this constraint
//        during the same AC loop.
// @Note: assumes no holes in the variable domains
bool Propagator::c_int_LT( IntHardConstraint &r )
{
  var_int& var_x = r.getScopeVar( 0 ); // @todo
  var_int& var_y = r.getScopeVar( 1 ); // @todo
  int x_lb = var_x.getDomain().lb();
  int x_ub = var_x.getDomain().ub();
  int y_lb = var_y.getDomain().lb();
  int y_ub = var_y.getDomain().ub();

  if( var_x.getDomain().is_singleton() and 
      var_y.getDomain().is_singleton() )
    {
      r.setFixpoint();
      // Fails if both domains contain different element
      if( not (x_lb < y_lb) ) return false;
    }
  else if( var_x.getDomain().is_singleton() ) 
    {
      if( y_ub <= x_lb ) return false;

      // propagate on var_y
      trailstack->trailVariable( var_y );
      var_y.getDomain().move_lb_val( x_lb + 1 );
      r.setFixpoint();		// set this constarint at Fixpoint
      constraintStore->signalVarChanged( var_y );
    }
  else if( var_y.getDomain().is_singleton() )
    {
      if( x_lb >= y_lb ) return false;
     
      // propagate on var_x
      trailstack->trailVariable( var_x );
      var_x.getDomain().move_ub_val( y_lb - 1 );
      r.setFixpoint();		// set this constarint at Fixpoint
      constraintStore->signalVarChanged( var_x );
    }
  else 
    { // if both are ground domain consistency.
      // Here Fixpoint is not valid
#ifdef BOUND_CONSISTENCY
      // @todo: signal var changed here
#endif
    }
  return true;
}


// a <= b 
// @note: only bound consistency implemented.
// @note: Once the constraint has been propagated, 
//        a AC fixpoint is reached---no need to propagate this constraint
//        during the same AC loop.
bool Propagator::c_int_LEQ( IntHardConstraint &r )
{
  var_int& var_x = r.getScopeVar( 0 );
  var_int& var_y = r.getScopeVar( 1 );
  int x_lb = var_x.getDomain().lb();
  int x_ub = var_x.getDomain().ub();
  int y_lb = var_y.getDomain().lb();
  int y_ub = var_y.getDomain().ub();

  if( var_x.getDomain().is_singleton() and
      var_y.getDomain().is_singleton() )
    {
      r.setFixpoint();
      // Fails if both domains contain different element
      if( not (x_lb <= y_lb) ) return false;
    }
  else if( var_x.getDomain().is_singleton() )
    {
      if( y_ub < x_lb ) return false;

      // propagate on var_y
      trailstack->trailVariable( var_y );
      var_y.getDomain().move_lb_val( x_lb );
      r.setFixpoint();		// set this constarint at Fixpoint
      constraintStore->signalVarChanged( var_y );
    }
  else if( var_y.getDomain().is_singleton() )
    {
      if( x_lb > y_lb ) return false;     

      // propagate on var_x
      trailstack->trailVariable( var_x );
      var_x.getDomain().move_ub_val( y_lb );
      r.setFixpoint();		// set this constarint at Fixpoint
      constraintStore->signalVarChanged( var_x );
    }
  else 
    { // if both are ground domain consistency.
      // Here Fixpoint is not valid
#ifdef BOUND_CONSISTENCY
      // @todo: signal var changed here
#endif
    }
  return true;
}


// a > b 
// @note: only bound consistency implemented.
// @note: Once the constraint has been propagated, 
//        a AC fixpoint is reached---no need to propagate this constraint
//        during the same AC loop.
bool Propagator::c_int_GT( IntHardConstraint &r )
{
  var_int& var_x = r.getScopeVar( 0 ); // @todo
  var_int& var_y = r.getScopeVar( 1 ); // @todo
  int x_lb = var_x.getDomain().lb();
  int x_ub = var_x.getDomain().ub();
  int y_lb = var_y.getDomain().lb();
  int y_ub = var_y.getDomain().ub();

  if( var_x.getDomain().is_singleton() and 
      var_y.getDomain().is_singleton() )
    {
      r.setFixpoint();
      // Fails if both domains contain different element
      if( not (x_lb > y_lb) ) return false;
    }
  else if( var_x.getDomain().is_singleton() ) 
    {
      if( y_lb >= x_lb ) return false;

      // propagate on var_y
      trailstack->trailVariable( var_y );
      var_y.getDomain().move_ub_val( x_lb - 1 );
      // signal change of variable in the constraint store
      r.setFixpoint();
      constraintStore->signalVarChanged( var_y );
    }
  else if( var_y.getDomain().is_singleton() )
    {
      if( x_ub <= y_lb ) return false;
     
      // propagate on var_x
      trailstack->trailVariable( var_x );
      var_x.getDomain().move_lb_val( y_lb + 1 );
      // signal change of variable in the constraint store
      r.setFixpoint();
      constraintStore->signalVarChanged( var_x );
    }
  else 
    { // if both are ground domain consistency.
      // Here Fixpoint is not valid
#ifdef BOUND_CONSISTENCY
      // @todo: signal var changed here
#endif
    }
  return true;
}


// a >= b 
// @note: only bound consistency implemented.
// @note: Once the constraint has been propagated, 
//        a AC fixpoint is reached---no need to propagate this constraint
//        during the same AC loop.
bool Propagator::c_int_GEQ( IntHardConstraint &r )
{
  var_int& var_x = r.getScopeVar( 0 );
  var_int& var_y = r.getScopeVar( 1 );
  int x_lb = var_x.getDomain().lb();
  int x_ub = var_x.getDomain().ub();
  int y_lb = var_y.getDomain().lb();
  int y_ub = var_y.getDomain().ub();

  if( var_x.getDomain().is_singleton() and
      var_y.getDomain().is_singleton() )
    {
      r.setFixpoint();
      // Fails if both domains contain different element
      if( not (x_lb >= y_lb) ) return false;
    }
  else if( var_x.getDomain().is_singleton() )
    {
      if( y_lb > x_lb ) return false;

      // propagate on var_y
      trailstack->trailVariable( var_y );
      var_y.getDomain().move_ub_val( x_lb );
      r.setFixpoint();		// set this constarint at Fixpoint
      constraintStore->signalVarChanged( var_y );
    }
  else if( var_y.getDomain().is_singleton() )
    {
      if( x_ub < y_lb ) return false;     

      // propagate on var_x
      trailstack->trailVariable( var_x );
      var_x.getDomain().move_lb( y_lb );
      r.setFixpoint();		// set this constarint at Fixpoint
      constraintStore->signalVarChanged( var_x );
    }
  else 
    { // if both are ground domain consistency.
      // Here Fixpoint is not valid
#ifdef BOUND_CONSISTENCY
      // @todo: signal var changed here
#endif
    }
  return true;
}


// x + y = c
// int_plus(var int: x, var int: y, int: c)
bool Propagator::c_int_PlusEQconst( IntHardConstraint& r )
{
  var_int& var_x = r.getScopeVar( 0 );
  var_int& var_y = r.getScopeVar( 1 );
  int x_lb = var_x.getDomain().lb();
  int x_ub = var_x.getDomain().ub();
  int y_lb = var_y.getDomain().lb();
  int y_ub = var_y.getDomain().ub();
  int c = r.getIntCoef( 0 );

  // Both x and y singleton
  if( var_x.getDomain().is_singleton() and 
      var_y.getDomain().is_singleton() )
    {
      r.setFixpoint();
      // check consistency:
      return ( x_lb + y_lb == c );
    }
  else if( var_x.getDomain().is_singleton() )
    {
      // y = c - x
      if( not var_y.getDomain().is_active_val( c - x_lb ) )
	return false;

      trailstack->trailVariable( var_y );
      var_y.getDomain().copy_singleton_val( c - x_lb );
      // signal change of variable in the constraint store
      r.setFixpoint();
      constraintStore->signalVarChanged( var_y );
    }
  else if( var_y.getDomain().is_singleton() )
    {
      if( not var_x.getDomain().is_active_val( c - y_lb ) )
	return false;

      trailstack->trailVariable( var_x );
      var_x.getDomain().copy_singleton_val( c - y_lb );
      // signal change of variable in the constraint store
      r.setFixpoint();
      constraintStore->signalVarChanged( var_x );
    }
  else
    {
      // no bound consistency defined.
    }
  return true;
}


// Creates holes
bool Propagator::c_abs_int_sub_int_gt_int( IntHardConstraint& r )
{
  
  return true;
}


/**
 * Linear Inequality Constraint.
 * Following K. Apt - Principles of Constraint Programming 
 *
 * \sum_i a_i* x_i <= b
 * 
 *  with a_i, real coefficients 
 *       x_i, variables 
 *         b, an integer constant
 * @note: can be slightly more efficiently by not computing the summation twice.
 */
double POS_lb_x[100];
double POS_ub_x[100];
double NEG_lb_x[100];
double NEG_ub_x[100];
double POS_a[100]; // positive integers
double NEG_a[100]; // positive integers
unsigned int POS_x[100];
unsigned int NEG_x[100];

bool Propagator::c_int_lin_LEQ( IntHardConstraint& r )
{  
  double a_j, sum_pos, sum_neg, b;
  double alpha_j, beta_j;
  int alpha_pos, beta_pos;
  int nPos = 0, nNeg = 0, nSingletons = 0;

  // Last Coefficient is the constant 'c'
  b = r.getIntCoef(0);
  // Store Positive and Negative coefficients togheter with 
  // the variables lower and upper bounds
  sum_pos = sum_neg = 0;
  for( int i=0; i<r.numofRealCoef(); i++) 
  {
    if( r.getRealCoef( i ) < 0 ) 
    {
      NEG_a[ nNeg ] = -r.getRealCoef( i );
      NEG_lb_x[ nNeg ] = r.getScopeVar( i ).getDomain().lb();
      NEG_ub_x[ nNeg ] = r.getScopeVar( i ).getDomain().ub();
      // sum_neg += NEG_a[ nPos ] * NEG_ub_x[ nPos ];
      NEG_x[ nNeg++ ] = i;
    }
    else if ( r.getRealCoef( i ) > 0 )
    {
      POS_a[ nPos ] = r.getRealCoef( i );
      POS_lb_x[ nPos ] = r.getScopeVar( i ).getDomain().lb();
      POS_ub_x[ nPos ] = r.getScopeVar( i ).getDomain().ub();
      // sum_pos += POS_a[ nPos ] * POS_lb_x[ nPos ];
      POS_x[ nPos++ ] = i;
    }
  }

  // compute the max expression for the 
  // x_j <= b - \sum_POS_i a_i*lb(x_i) + \sum_NEG_i a_i*ub(x_i) / a_j  
  // For each x_j in POS 
  for( int j=0; j<nPos; j++ )
  {
    var_int& x_j = r.getScopeVar( POS_x[ j ] );
    if( x_j.getDomain().is_singleton() ) { nSingletons++; continue; }

    a_j = POS_a[ j ];
    sum_pos = sum_neg = 0;
    for(int i=0; i<nPos; i++)
    {
      if( i != j) sum_pos += POS_a[ i ] * POS_lb_x[ i ];
    }
    for(int i=0; i<nNeg; i++)
    {
      sum_neg += NEG_a[ i ] * NEG_ub_x[ i ];
    }

    alpha_j = std::floor( (b - sum_pos + sum_neg 
			   /*- (POS_a[ j ] * POS_lb_x[ j ])*/) / (double)a_j ); 
    alpha_pos = x_j.getDomain().get_pos( alpha_j ); // new ub
    
    if( alpha_pos == -1 ) return false;

    // if a new bound is found propagate on xj
    if( alpha_j < POS_ub_x[ j ] )
    {
      trailstack->trailVariable( x_j );
      x_j.getDomain().move_ub( alpha_pos );
      constraintStore->signalVarChanged( x_j );
      nSingletons += x_j.getDomain().is_singleton();
    }
  }

  // For each x_j in POS 
  for( int j=0; j<nNeg; j++ )
  {
    var_int& x_j = r.getScopeVar( NEG_x[ j ] );
    
    if( x_j.getDomain().is_singleton() ) { nSingletons++; continue; }

    a_j = NEG_a[ j ];
    
    sum_pos = sum_neg = 0;
    for(int i=0; i<nPos; i++)
    {
      sum_pos += POS_a[ i ] * POS_lb_x[ i ];
    }
    for(int i=0; i<nNeg; i++)
    {
      if( i != j) sum_neg += NEG_a[ i ] * NEG_ub_x[ i ];
    }

    beta_j = std::ceil( ( -b + sum_pos - sum_neg 
			  /*- (NEG_a[ j ] * NEG_ub_x[ j ])*/) / (double)a_j ); 
    beta_pos = x_j.getDomain().get_pos( beta_j ); // new lb

    if( beta_pos == -2 ) return false;

    // if a new bound is found propagate on xj
    if( beta_j > NEG_lb_x[ j ] )
    {
      trailstack->trailVariable( x_j );
      x_j.getDomain().move_lb( beta_pos );
      constraintStore->signalVarChanged( x_j );
      nSingletons += x_j.getDomain().is_singleton();
    }
  }

  //if( nSingletons >= r.getArity() ){
    // This fixpoint is permanent on this sub-tree and 
    // needs to be trailed!
    r.setFixpoint();
    //  }

  return true;
}


/**
 * Linear Inequality Constraint.
 * Following K. Apt - Principles of Constraint Programming 
 *
 * \sum_i a_i* x_i >= b
 * 
 *  with a_i, real coefficients 
 *       x_i, variables 
 *         b, a real constant
 * @note: can be slightly more efficiently by not computing the summation twice.
 */
bool Propagator::c_int_lin_GEQ( IntHardConstraint& r )
{
  printWarningMessage( "Propagator::c_int_lin_GEQ()");
  return true;
}


/**
 * Linear Inequality Constraint.
 * Following K. Apt - Principles of Constraint Programming 
 *
 * \sum_i a_i* x_i = b
 * 
 *  with a_i, real coefficients 
 *       x_i, variables 
 *         b, a real constant
 * @note: can be slightly more efficiently by not computing the summation twice.
 */
bool Propagator::c_int_lin_EQ( IntHardConstraint& r )
{
  double a_j, sum_pos_l, sum_pos_u, sum_neg_l, sum_neg_u, b;
  double alpha_j, beta_j, gamma_j, delta_j;
  int alpha_pos, beta_pos, gamma_pos, delta_pos;
  int nPos = 0, nNeg = 0;
  int nSingletons = 0;

  // Last Coefficient is the constant 'c'
  b = r.getIntCoef( 0 );

  // Store Positive and Negative coefficients togheter with 
  // the variables lower and upper bounds
  for( int i=0; i<r.numofRealCoef(); i++) 
  {
    if( r.getRealCoef( i ) < 0 ) {
      NEG_a[ nNeg ] = -r.getRealCoef( i );
      NEG_lb_x[ nNeg ] = r.getScopeVar( i ).getDomain().lb();
      NEG_ub_x[ nNeg ] = r.getScopeVar( i ).getDomain().ub();
      NEG_x[ nNeg++ ] = i;
    }
    else {
      POS_a[ nPos ] = r.getRealCoef( i );
      POS_lb_x[ nPos ] = r.getScopeVar( i ).getDomain().lb();
      POS_ub_x[ nPos ] = r.getScopeVar( i ).getDomain().ub();
      POS_x[ nPos++ ] = i;
    }
  }


  // compute the max expression for the 
  // x_j <= b - \sum_POS_i a_i*lb(x_i) + \sum_NEG_i a_i*ub(x_i) / a_j  
  // For each x_j in POS 
  for( int j=0; j<nPos; j++ )
  {
    var_int& x_j = r.getScopeVar( POS_x[ j ] );
    if( x_j.getDomain().is_singleton() ) { nSingletons++; continue; }

    a_j = POS_a[ j ];
    sum_pos_u = sum_neg_u = sum_pos_l = sum_neg_l = 0;
    for(int i=0; i<nPos; i++)
    {
      if( i != j) sum_pos_l += POS_a[ i ] * POS_lb_x[ i ]; 
      if( i != j) sum_pos_u += POS_a[ i ] * POS_ub_x[ i ];
    }
    for(int i=0; i<nNeg; i++)
    {
      sum_neg_u += NEG_a[ i ] * NEG_ub_x[ i ];
      sum_neg_l += NEG_a[ i ] * NEG_lb_x[ i ];
    }
    alpha_j = std::floor( (b - sum_pos_l + sum_neg_u ) / (double)a_j ); 
    gamma_j = std::ceil( (b - sum_pos_u + sum_neg_l ) / (double)a_j ); 
    alpha_pos = x_j.getDomain().get_pos( alpha_j ); // new ub
    gamma_pos = x_j.getDomain().get_pos( gamma_j ); // new lb

    // HACK!! need to differentiate these cases!!
    //if( alpha_pos == -1 || gamma_pos == -1 ) return false;
  
    // if a new bound is found propagate on xj
    if( alpha_j < POS_ub_x[ j ] or gamma_j > POS_lb_x[ j ] )
    {
      trailstack->trailVariable( x_j );

      if( alpha_j < POS_ub_x[ j ] )
	x_j.getDomain().move_ub( alpha_pos );
      if( gamma_j > POS_lb_x[ j ] )
	x_j.getDomain().move_lb( gamma_pos );

      constraintStore->signalVarChanged( x_j );      
      nSingletons += x_j.getDomain().is_singleton();
    }
  }

  // For each x_j in NEG 
  for( int j=0; j<nNeg; j++ )
  {
    var_int& x_j = r.getScopeVar( NEG_x[ j ] );
    if( x_j.getDomain().is_singleton() ) 
    { 
      nSingletons++;
      continue;
    }

    a_j = NEG_a[ j ];
    sum_pos_u = sum_neg_u = sum_pos_l = sum_neg_l = 0;
    for(int i=0; i<nPos; i++)
    {
      sum_pos_l += POS_a[ i ] * POS_lb_x[ i ];
      sum_pos_u += POS_a[ i ] * POS_ub_x[ i ];
    }
    for(int i=0; i<nNeg; i++)
    {
      if( i != j) sum_neg_u += NEG_a[ i ] * NEG_ub_x[ i ];
      if( i != j) sum_neg_l += NEG_a[ i ] * NEG_lb_x[ i ];
    }
    beta_j = std::ceil( ( -b + sum_pos_l - sum_neg_u ) / (double)a_j );
    delta_j = std::floor( ( -b + sum_pos_u - sum_neg_l ) / (double)a_j ); 
    beta_pos = x_j.getDomain().get_pos( beta_j ); // new lb
    delta_pos = x_j.getDomain().get_pos( delta_j ); // new ub

    // HACK!! need to differentiate these cases!!
    // if( beta_pos == -1 || delta_pos == -1 ) return false;

    // if a new bound is found propagate on xj
    if( beta_j > NEG_lb_x[ j ] or delta_j < NEG_ub_x[ j ] )
    {
      trailstack->trailVariable( x_j );

      if( beta_j > NEG_lb_x[ j ] )
	x_j.getDomain().move_lb( beta_pos );
      if( delta_j < NEG_ub_x[ j ] )
	x_j.getDomain().move_ub( delta_pos );

      constraintStore->signalVarChanged( x_j );
      nSingletons +=  x_j.getDomain().is_singleton();
    }
  }

  r.setFixpoint();
  
  return true;
}


/**
 * x < a < y <-> b
 * where x : var_int
 *       y : var_int
 *       b : var_bool (0,1)
 *       a : integer parameter       
 */
bool Propagator::c_int_within_iff( IntHardConstraint& r )
{
  int a = r.getIntCoef( 0 );
  var_int& x = r.getScopeVar( 0 );
  var_int& y = r.getScopeVar( 1 );
  var_int& b = r.getScopeVar( 2 ); // should be a bool_var

  bool x_sing = x.getDomain().is_singleton();
  int x_lb    = x.getDomain().lb();
  int x_ub    = x.getDomain().ub();
  bool y_sing = y.getDomain().is_singleton();
  int y_lb    = y.getDomain().lb();
  int y_ub    = y.getDomain().ub();
  bool b_sing = b.getDomain().is_singleton();
  int b_lb    = b.getDomain().lb();
  int b_ub    = b.getDomain().ub();

  // only b assigned
  if( b_sing and (not x_sing) and (not y_sing) )
  {
    cout << "INT_WITHIN_IFF:: B assigned\n";
    if( b_lb == 0 ) { r.setFixpoint(); return true; }
    else// b == 1
    {
      if( x_lb >= a or y_ub <= a ) return false;
      // propagate over x < a
      if( x_ub >= a ) 
      {
	trailstack->trailVariable( x );
	x.getDomain().move_ub( a-1 ); 
	constraintStore->signalVarChanged( x );
      }
      // propagate over y > a
      if( y_lb <= a ) 
      {
	trailstack->trailVariable( y );
	y.getDomain().move_lb( a+1 ); 
	constraintStore->signalVarChanged( y );
      }
      r.setFixpoint(); 
      return true;
    }
  }

  // x  assigned, y and b not assigned
  if( x_sing and (not y_sing) and (not b_sing) )
  {
    cout << "INT_WITHIN_IFF::X assigned\n";
    // if x does not satisies the condition
    if( x_lb >= a )
    {
      // propagate over b ( shoul be 0 )
      trailstack->trailVariable( b );
      b.getDomain().copy_singleton( 0 );
      constraintStore->signalVarChanged( b );
      return true;
    }

    // if x satisfies the condition:
    if( x_lb < a )
    {
      // and y satisies the condition:
      if( y_lb > a )
      {
	// propagate over b ( shoul be 1 )
	trailstack->trailVariable( b );
	b.getDomain().copy_singleton( 1 );
	constraintStore->signalVarChanged( b );
	return true;
      }
      // if y does not satisifes the condition:
      else if ( y_ub <= a ) 
      {
	trailstack->trailVariable( b );
      	b.getDomain().copy_singleton( 0 );
	constraintStore->signalVarChanged( b );
	return true;
      }
    }
  }

  // y  assigned, x and b not assigned
  if( y_sing and (not x_sing) and (not b_sing) )
  {
    cout << "INT_WITHIN_IFF::Y assigned\n";
    // if x does not satisies the condition
    if( y_ub <= a )
    {
      // propagate over b ( shoul be 0 )
      trailstack->trailVariable( b );
      b.getDomain().copy_singleton( 0 );
      constraintStore->signalVarChanged( b );
      return true;
    }

    // if y satisfies the condition:
    if( y_lb > a )
    {
      // and x satisies the condition:
      if( x_ub < a )
      {
	// propagate over b ( shoul be 1 )
	trailstack->trailVariable( b );
	b.getDomain().copy_singleton( 1 );
	constraintStore->signalVarChanged( b );
	return true;
      }
      // if x does not satisifes the condition:
      else if ( x_lb >= a ) 
      {
	trailstack->trailVariable( b );
      	b.getDomain().copy_singleton( 0 );
	constraintStore->signalVarChanged( b );
	return true;
      }
    }
  }

  // x and y assigned
  if( x_sing and y_sing and (not b_sing) )
  {
    cout << "INT_WITHIN_IFF::X and Y assigned\n";
    trailstack->trailVariable( b );
    if( x_lb < a and a < y_lb ) {
      b.getDomain().copy_singleton( 1 );
    }
    else {
      b.getDomain().copy_singleton( 0 );
    }
    constraintStore->signalVarChanged( b );
    r.setFixpoint();
    return true;
  }

  // x and b assigned
  if( x_sing  and b_sing and (not y_sing))
  {
    cout << "INT_WITHIN_IFF::X and B assigned\n";

    if( b_lb == 1 and x_lb < a )
    {
      //propagate over y:
      if( y_lb <= a )
      {
	trailstack->trailVariable( y );
	y.getDomain().move_lb( a+1 ); 
	constraintStore->signalVarChanged( y );
      }
      r.setFixpoint(); 
      return true;
    }
    else if( b_lb == 1 and x_lb >= a )
    {
      return false;
    }
    else if( b_lb == 0 and x_lb < a)
    {
      if( a < y_lb ) return false;
      else { 
	//propagate on y
	trailstack->trailVariable( y );
	y.getDomain().move_ub( a ); 
	constraintStore->signalVarChanged( y );
	r.setFixpoint(); 
	return true; 
      }
    }
  }

  // y and b assigned
  if( y_sing  and b_sing and (not x_sing))
  {
    cout << "INT_WITHIN_IFF::Y and B assigned\n";

    if( b_lb == 1 and y_lb > a )
    {
      //propagate over x:
      if( x_ub >= a )
      {
	trailstack->trailVariable( x );
	x.getDomain().move_ub( a-1 ); 
	constraintStore->signalVarChanged( x );
      }
      r.setFixpoint(); 
      return true;
    }
    else if( b_lb == 1 and y_lb <= a )
    {
      return false;
    }
    else if( b_lb == 0 and y_lb > a)
    {
      if( x_ub < a ) return false;
      else { 
	//propagate on x
	trailstack->trailVariable( x );
	x.getDomain().move_lb( a ); 
	constraintStore->signalVarChanged( x );
	r.setFixpoint(); 
	return true; 
      }
    }
  }

  // x,y,b assigned
  if( x_sing and y_sing and b_sing )
  {
    cout << "INT_WITHIN_IFF::X and Y and B assigned\n";
    // check consistency:
    if( b_lb == 1 and x_lb < a and a < y_lb )
    {
      r.setFixpoint();
      return true;
    }
    else if( b_lb == 0 and (x_lb >=a or y_lb <= a ) )
    {
      r.setFixpoint();
      return true;
    }
    else
      return false;
  }

  return true;
}
