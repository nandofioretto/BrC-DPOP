#ifndef _ULISSE_GLOBALS_HH_
#define _ULISSE_GLOBALS_HH_

/* Common dependencies */
#include <stdlib.h> // for atoi
#include <stdio.h>
#include <sys/time.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

/* Input/Output */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <sstream>

/* Arithmetic and Assertions */
#include <cassert>
#include <cmath>
#include <limits>

/* STL dependencies */
#include <algorithm>
#include <iterator>
#include <map>
#include <unordered_map>
#include <queue>
#include <stack>
#include <set>
#include <string>
#include <vector>
#include <utility>
#include <functional> 
#include <cctype>
#include <locale>

class Agent;
class Domain;
class var_int;
class Relation;
class ExtSoftRelation;
class ExtHardRelation;
class IntSoftRelation;
class IntHardRelation;
class Constraint;
class Statistics;
class AgentQueue;
class Scheduler;
class CVMatrix;


extern size_t g_numof_solutions;
extern size_t g_numof_nodes_explored;
              
#define INFTY 2147483647 // LONG_MAX (2^31-1)
#define UNSAT 2147483647 // LONG_MAX-1 (2^31-2)
#define SAT   2147483646 // LONG_MAX-1 (2^31-2)

#define INFTY_STR "2147483647"
#define NA_VALUE  32766 // MAX_INT-1 (2^15)

typedef long cost_type;
//typedef double cost_type;

enum optimization_type { maximize, minimize };

// The Problem optimization type
extern optimization_type g_optimizationType;
extern size_t g_maxDomainSize;

static bool isFinite( cost_type cost )
{
  return (cost < 2147483647 and cost > -2147483647);
}

static bool isSat( cost_type cost )
{
  return (cost == SAT );
}

static bool isNotNA( cost_type cost )
{
  return (cost != NA_VALUE);
}

static bool isBetter( cost_type cost1, cost_type cost2, 
		      optimization_type t=g_optimizationType )
{
  return (( t == maximize and cost1 > cost2 )
	  or (t == minimize and cost1 < cost2 ));
}

static cost_type worstValue( optimization_type t=g_optimizationType )
{
  if (t  == maximize ) return -INFTY;
  else return INFTY;
}

static cost_type getBestValue( cost_type cost1, cost_type cost2, 
			  optimization_type t=g_optimizationType )
{
  if (( t == maximize and cost1 > cost2 )
      or (t == minimize and cost1 < cost2 ))
    return cost1;
  else 
    return cost2;
}


static std::string itos( int i )
{
    std::stringstream ss;
    std::string s;
    ss << i;
    ss >> s;
    return s;
}

static int stoi( std::string s )
{
    std::stringstream ss;
    int i;
    ss << s;
    ss >> i;
    return i;
}

// trim from start
static inline std::string &ltrim(std::string &s) {
  s.erase(s.begin(), std::find_if(s.begin(), s.end(), std::not1(std::ptr_fun<int, int>(std::isspace))));
  return s;
}

// trim from end
static inline std::string &rtrim(std::string &s) {
  s.erase(std::find_if(s.rbegin(), s.rend(), std::not1(std::ptr_fun<int, int>(std::isspace))).base(), s.end());
  return s;
}

// trim from both ends
static inline std::string &trim(std::string &s) {
  return ltrim(rtrim(s));
}

static void printWarningMessage( std::string foo )
{
  std::cout <<" Warning: Function " << foo << " is not implemented!\n";
  exit(-1);
}


extern std::map< std::string, Agent* >   g_agents;
extern std::map< std::string, Domain* >  g_domains;
extern std::map< std::string, var_int* > g_variables;
extern std::map< std::string, Constraint* >        g_constraints;

extern std::map< size_t, Agent* >      g_Agents;
extern std::map< size_t, var_int* >    g_Variables;
extern std::map< size_t, Constraint* > g_Constraints;

// used as aux for pseudo-tree construction
extern std::map<Agent*, std::vector<Agent*> > g_agent_neighbours;
// Used in R-DPOP
extern std::map<size_t, CVMatrix*> g_constraint2cvm;

#include "statistics.hh"
extern Statistics g_stats;
//#include "scheduler.hh"
extern Scheduler* g_scheduler;

// CP 14
extern bool g_BC;
extern bool g_BCDPOP;


#endif
