#include "globals.hh"
#include "agent.hh"
#include "domain.hh"
#include "var_int.hh"
#include "constraint.hh"
#include "relation.hh"

#include "internal-search-engine.hh"
#include "external-search-engine.hh"
#include "protocol.hh"
#include "variable-ordering.hh"

#include <rapidxml.hpp>
using namespace rapidxml;
using namespace std;

bool orderVarDes (var_int* LHS, var_int* RHS) 
{
  return ( LHS->getID() < RHS->getID() );
}


Agent::Agent(xml_node<>* agent)
  : agentName(""), extSearchEngine( 0 ), intSearchEngine( 0 ),
    nBoundaryConstraints( 0 ), behavior( 0 )
{
  static size_t _g_ULISSE_AGENT_COUNTER = 0;
  agentID = _g_ULISSE_AGENT_COUNTER++;
  agentName  = agent->first_attribute("name")->value();
}


Agent::~Agent()
{ 
  if( extSearchEngine ) delete extSearchEngine;
  if( intSearchEngine ) delete intSearchEngine;
  if( behavior ) delete behavior;
}


void Agent::setLocalConstraints()
{
  bool tosave;
  // Save boundary constraints first:
  for( int i=0; i<nBoundaryVars; i++ )
  {
    var_int& vi = getBoundaryVariable( i );
    int nconstr = vi.numofConstraints();

    // scan all constraints involving vi, and check if their scope
    // has only boundary variables owned by current agent.
    for( int k = 0; k < nconstr; k++ )
    {
      tosave = true;
      Constraint& con = vi.getConstraint( k );
      // scan all variables occurring in scope of 'con', and check 
      // whether they are also owned by current agent
      for( int j=0; j<con.getArity(); j++)
      {
	var_int& vj = con.getScopeVar( j );
	if(con.getArity() > 1 and vj == vi ) continue;
	if( !this->hasInBoundaryVariables( vj ) )
	{
	  tosave = false;
	  break;
	}
      }
      if( tosave && // check not already present
	  find( localConstraints.begin(), localConstraints.end(), &con )
	  == localConstraints.end() )
	localConstraints.push_back( &con );
      
    }// forall constraints in boundary var vi
  }// forall boundary variables vi of Ai
  nBoundaryConstraints = localConstraints.size();

  // Save Local constraints (i.e., constraints whose scope is in the local 
  // variables, excluding the one previously saved).
  for (int i=0; i<localVariables.size(); i++)
  {
    var_int& vi = *localVariables[ i ];

    int nconstr = vi.numofConstraints();

    // scan all constraints involving vi, and check if their scope
    // has only variables owned by current agent.
    for( int k = 0; k < nconstr; k++ )
    {
      bool tosave = true;
      Constraint& con = vi.getConstraint( k );

      // scan all variables occurring in scope of 'con', and check 
      // whether they are also owned by current agent
      for( int j=0; j<con.getArity(); j++)
      {
	var_int& vj = con.getScopeVar( j );
	if( con.getArity() > 1 and  vj == vi ) continue;
	if( vi.getOwner() != vj.getOwner() )
	{
	  tosave = false;
	  break;
	}
	
	if( tosave and 
	    find( localConstraints.begin(), localConstraints.end(), &con ) 
	    == localConstraints.end() )
	  localConstraints.push_back( &con );
      }

    }// forall constraints in local var vi
  }// forall local variables vi of Ai

}


bool Agent::hasInLocalVariables( var_int& v ) const
{
  return ( find( localVariables.begin(), localVariables.end(), &v )
	   != localVariables.end() );
}


bool Agent::hasInBoundaryVariables( var_int& v ) const
{
  for (int i=0; i<nBoundaryVars; i++)
    if ( getBoundaryVariable( i ) == v )
      return true;
  return false;
}


// vector< var_int* > Agent::getBoundaryVariablesIn( vector< Constraint* > con )
// {
//   vector< var_int* > res;
//   for (int c=0; c<con.size(); c++) 
//   {
//     for (int i=0; i<nBsize; i++) 
//     {
//       var_int& v = getBoundaryVariable( i );
//       if (con[ c ]->hasInScope( v ) &&
// 	  find( res.begin(), res.end(), &v) == res.end() )
//     	res.push_back( &v );
//     }
//   }
//   return res;
// }


void Agent::addLocalVariable( var_int& v )
{
  if ( find( localVariables.begin(), localVariables.end(), &v) 
       == localVariables.end() )
    localVariables.push_back( &v );
}


void Agent::addBoundaryVariables()
{
  vector< var_int* > boundaryVariables;
  vector< var_int* > nonBoundaryVariables;

  // Look into constraint graph of this agent to determine the 
  // boundary variabels
  for (int i=0; i<localVariables.size(); i++)
  {
    var_int& vi = *localVariables[ i ];

    int nconstr = vi.numofConstraints();
    for( int k = 0; k < nconstr; k++ )
    {
      bool pushed = false;
      Constraint& con = vi.getConstraint( k );
      
      for (int j=0; j<con.getArity(); j++)
      {
	var_int& vj = con.getScopeVar( j );
	if ( vi != vj and vj.getOwner() != *this )
	{
	  boundaryVariables.push_back( &vi );
	  pushed = true;
	  break;
	}
      }
      if (pushed) break;
    }
  }

  // fill local-non boundary variables
  for( int l=0; l<localVariables.size(); l++ )
  {
    if( find( boundaryVariables.begin(), boundaryVariables.end(),
	      localVariables[ l ] )
	== boundaryVariables.end() ) // not found
      nonBoundaryVariables.push_back( localVariables[ l ] );
  }

  // Order the local variables in lexicographic order and so that the 
  // boundary variables are listed first (also in lex order) 
  sort( boundaryVariables.begin(), boundaryVariables.end(), orderVarDes );
  sort( nonBoundaryVariables.begin(), nonBoundaryVariables.end(), orderVarDes );
  
  nBoundaryVars  = boundaryVariables.size();
  nNonBoundaryVars = nonBoundaryVariables.size();

  for( int i=0; i<nBoundaryVars; i++ )
  {
    localVariables[ i ] = boundaryVariables[ i ];
  }
  for( int i=0; i<nNonBoundaryVars; i++ )
  {
    localVariables[ nBoundaryVars+i ] = nonBoundaryVariables[ i ];
  }
}


void Agent::setExternalSearchEngine( SearchEngine* se )
{
  extSearchEngine = se;
  se->initialize( *this );
}


void Agent::setInternalSearchEngine( SearchEngine* se )
{
  intSearchEngine = se;
  se->initialize( *this );
}


void Agent::setProtocol( Protocol* p, VariableOrdering& O )
{
  setAncestorsConstraints( O.getAncestors( *this ) );
  behavior = p;
  p->initialize( *this, O );
}


void Agent::setAncestorsConstraints( vector<Agent*> ancestors )
{
  vector< var_int* > ancestors_vars;
  // Retrieve all boundary variables of all ancestors
  for( auto a : ancestors )
  {
    for( int i=0; i<a->numofBoundaryVariables(); i++ )
    {
      ancestors_vars.push_back( &a->getBoundaryVariable( i ) );
    }
  }

  set<Constraint*> setAC;
  // scan all variables occurring in scope of 'con', and check 
  // whether at least one is owned by the ancestors
  for( auto va : ancestors_vars )
  {
    int nconstr = va->numofConstraints();
    for( int k = 0; k < nconstr; k++ )
    {
      Constraint& con = va->getConstraint( k );

      // scan all boundary variables of current agent
      for( int i=0; i<nBoundaryVars; i++ )
      {
	var_int& vb = getBoundaryVariable( i );

	if( con.hasInScope( vb ) )
	{
	  setAC.insert( &con );
	  break; 
	}
      }
    }
  }
  
  for( auto c : setAC ) {
    ancestorsConstraints.push_back( c );
  }

  ancestors_vars.clear();
  setAC.clear();
}


void Agent::dump() 
{
  cout << "Agent " << agentName << endl;
  
  cout << "Local Variables ([";
  for( int i=0; i<localVariables.size(); i++ )
    {
      cout << localVariables[i]->getName();
      if( i==nBoundaryVars-1) cout<<"]";
      cout << " ";
    }
  cout <<")\n";

  cout << "Local Constraints: ";
  for( int i=0; i<numofLocalConstraints(); i++ )
    {
      if( i == 0 ) cout << "[";
      cout << getLocalConstraint( i ).getName();
      if( i==numofBoundaryConstraints()-1) cout << "]";
      cout << " ";
    }
  cout <<endl;

  cout << "Ancestor Constraints: ";
  for( int i=0; i<numofAncestorsConstraints(); i++ )
    {
      cout << getAncestorsConstraint( i ).getName() << " ";
    }
  cout <<endl;
 
  if ( optimization == maximize ) cout << " Maximize\n";
  else cout << "Minimize\n";
  cout << endl;
}
