#include "search-domain.hh"
#include "var_int.hh"
#include <cassert> 

using namespace std;

SearchDomain::SearchDomain () 
  : _size ( 0 ), _min ( -1 ), _max ( 0 ), 
    _var_ptr ( 0 ) , _nactive( 0 ), _event( EMPTY_EVENT )
{ }

SearchDomain::SearchDomain ( vector< int > elements ) 
  : _size( elements.size() ),
    _var_ptr( 0 ),
    _min( 0 ),
    _max( _size - 1 ),
    _nactive( _size ),
    _event( EMPTY_EVENT )
{
  _values = elements;
  std::sort( _values.begin(), _values.end() );
  _state.resize( _size, true );
}

SearchDomain::SearchDomain ( const SearchDomain& other ) 
{
  _size = other._size;
  _min = other._min;
  _max = other._max;
  _var_ptr = other._var_ptr;
  _nactive = other._nactive;
  _event = other._event;
  _values = other._values;
  _state = other._state;
}

SearchDomain& SearchDomain::operator= (const SearchDomain& other) 
{
  if (this != &other) 
  {
    _size = other._size;
    _min = other._min;
    _max = other._max;
    _var_ptr = other._var_ptr;
    _nactive = other._nactive;
    _event = other._event;
    _values = other._values;
    _state = other._state;
  }
  return *this;
}

SearchDomain::~SearchDomain () 
{ }

int SearchDomain::operator [] (int i) const 
{
  return _values[ i ];
}

void SearchDomain::init( std::vector<int> elements )
{
  _size( elements.size() );
  _var_ptr( 0 );
  _min( 0 );
  _max( _size - 1 );
  _nactive( _size );
  _event( EMPTY_EVENT );
  _values = elements;
  std::sort( _values.begin(), _values.end() );
  _state.resize( _size, true );
}


void SearchDomain::add( int elem )
{
  if( std::find( _values.begin(), _values.end(), elem ) != _values.end() )
    return;
  
  int _lb = lb(), _ub = ub();

  int i = 0;
  while( _values[ i ] < elem && i < _size ) {i++; }
  std::vector<int>::iterator dt = _values.begin();
  std::vector<bool>::iterator bt = _state.begin();
  
  std::advance( dt, i ); 
  std::advance( bt, i ); 
  _values.insert( dt, elem );
  _state.insert( bt, true );

  if( elem < _lb ) {_min = i; _max++; } 
  else if( elem > _ub ) { _max = i; }
  else if( elem > _lb && elem < _ub ) { _max++; }
  _size++;  _nactive++;
}

void SearchDomain::set_vptr( var_int* v ) 
{
  _var_ptr = v;
}

var_int* SearchDomain::var_ptr()
{
  return _var_ptr;
}

std::vector< bool > SearchDomain::state () 
{
  return _state;
}

void SearchDomain::set_state ( std::vector<bool> other_state ) 
{
  _state = other_state;
  _min = -1; _max = _size+1;
  _event = DC_EVENT;
  // update _min _max active elements
  int i = -1;
  while( i++ < _size ) { if ( _state[ i ] ){ _min = i; break; } }
  int j = _size;
  while( j-- > i ) { if ( _state[ j ] ) _max = i; }

  // update the number of active elements
  if ( _min == -1 || _max == _size+1 ) 
  {
    _nactive = 0;
    _event = FAILED_EVENT;
  }
  else 
  {
    _nactive=0;
    for( i = _min; i <= _max; i++ )
      _nactive += _state[ i ];
    // check sing event
    if( _nactive == 1 ) _event = SING_EVENT; 
  }
}

void SearchDomain::set()
{
  // update domain changed event
  if( _nactive < _size ) _event = DC_EVENT;

  for( int i=0; i<_size; i++) 
    _state[ i ] = true;

  // update bounds changed event
  if( _min > 0 || _max < _size-1 ) _event = BC_EVENT;

  _min = 0; _max = _size-1;
  _nactive = _size;
}

void SearchDomain::set( int pos ) 
{
  if( !_state[ pos ] ) 
  {
    _state[ pos ] = true;
    _nactive++;
    // update domain changend event
    _event = DC_EVENT;
    // update bounds and events
    if( pos < _min ) { _min = pos; _event = BC_EVENT; }
    else if( pos > _max ) { _max = pos; _event = BC_EVENT; }
    // check sing event
    if( _nactive == 1 ) _event = SING_EVENT;
  }
}

void SearchDomain::set_singleton( int pos ) 
{
  for( int i=0; i<_size; i++)
    _state[ i ] = false;

  _state[ pos ] = true;
  _min = _max = pos;
  _nactive = 1;
  _event = SING_EVENT;
}

void SearchDomain::unset () 
{
  for( int i=0; i<_size; i++)
    _state[ i ] = false;  
  _nactive = 0;
  _event = FAILED_EVENT;
}

void SearchDomain::unset ( int pos ) 
{
  if( _state[ pos ] )
  {
    _state[ pos ] = false;
    _nactive--;
    _event = DC_EVENT;		// domain changed
    if( pos == _min ) 
    {
      while( pos++ <= std::max((short)0, _max) )
	{ if( _state[ pos ] ) {_min = pos; _event = BC_EVENT; break;} }
    }
    else if( pos == _max )
    {
      while( pos-- >= std::min(_min, _size) ) 
	{ if( _state[ pos ] ) {_max = pos; _event = BC_EVENT; break;} }
    }
    if( _nactive == 1 ) _event = SING_EVENT;
  }
}

void SearchDomain::set_lb( int pos ) 
{
  if( pos > _max ) { unset(); return; }
  if( pos == _min ) return;
  //if( pos == _max ) set_singleton( pos );
  if( pos < _min )
  {
    for( int i = pos+1; i < _min; i++ ) 
      set( i );
  }
  else if ( pos > _min ) 
  {
    for( int i = _min; i < pos; i++ )
      unset( i );
  }
  set( pos );
}

void SearchDomain::set_ub( int pos ) 
{
  if( pos < _min ) { unset(); return; }
  if( pos == _max ) return;
  //if( pos == _min ) set_singleton( pos );
  if( pos < _max )
  {
    for( int i = pos+1; i <= _max; i++ )
      unset( i );
  }
  else if ( pos > _max ) 
  {
    for( int i = _max+1; i < pos; i++ )
      set( i );
  }
  set( pos );
}

bool SearchDomain::is_valid () const 
{
  return ( _nactive > 0 ); 
}

bool SearchDomain::is_failed () const 
{
  return ( !is_valid() );
}

bool SearchDomain::is_valid (int pos) const 
{
  return ( _state[ pos ] );
}

bool SearchDomain::is_singleton( ) const
{
  return ( _nactive == 1 );
}

int
SearchDomain::size()
{
  return _size;
}

int SearchDomain::n_active() const
{
  return _nactive;
}

int SearchDomain::lb() const
{
  return _values[ _min ];
}

int SearchDomain::ub() const
{
  return _values[ _max ];
}

int SearchDomain::lb_pos() const
{
  return _min;
}

int SearchDomain::ub_pos() const
{
  return _max;
}

int SearchDomain::min() const
{
  return _values[ 0 ];
}

int SearchDomain::max() const
{
  return _values[ _size ];
}

void SearchDomain::copy_state( std::vector<bool> other_state )
{
  _state = other_state;
}

void SearchDomain::copy_bounds( short l, short u )
{
  _min = l; _max = u;
}

void SearchDomain::copy_n_active( short n )
{
  _nactive = n;
}

void SearchDomain::set_event( int event )
{
  _event = event;
}

int SearchDomain::event() const
{
  return _event;
}

void SearchDomain::dump() 
{
  assert( _var_ptr );
  int i=0;
  int l = _var_ptr->label();
  cout << "{";
  for (; i < _size; i++) 
  {
    if ( i == _min ) printf("<");
    if (_values[ i ]==l) printf("[%.6f] ", _values[i]);
    else if ( _state[ i ] ) printf( "%.6f ", _values[i]);
    if ( i == _max ) printf(">");
  }
  cout << "}  lb: " << _min << " ub: " << _max; 
  cout << "  event: " << _event << endl; 
  
}
