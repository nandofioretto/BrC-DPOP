#include "var_int.hh"
#include "agent.hh"
#include "domain.hh"
#include "constraint.hh"
#include "trail-variable.hh"
#include <rapidxml.hpp>

using namespace std;
using namespace rapidxml;

var_int::var_int( xml_node<>* var ) 
  : varName( "" ), varOwner ( "" ),
    label( -1 ),  assigned( false ),
    nIntHard_c( 0 ), nIntSoft_c( 0 ), nExtHard_c( 0 ), nExtSoft_c( 0 )
{
  static size_t _g_CP_VARIABLE_COUNTER = 0;
  varID = _g_CP_VARIABLE_COUNTER++;
  varName   = var->first_attribute("name")->value();
  varOwner  = var->first_attribute("agent")->value();
  string p_dom = var->first_attribute("domain")->value();
  
  domain.init( g_domains[ p_dom ]->getValues() );
  domain.set_vptr( this );

  // Add reference to the agent owning this variable
  g_agents[ varOwner ]->addLocalVariable( *this );

  // Add reference to Set of CP Variables
  // g_variables[ varName ] = this;
}//-


var_int::var_int( const var_int& other )
{
  varID       = other.varID;
  varName  = other.varName;
  varOwner = other.varOwner;
  label    = other.label;
  assigned = other.assigned;
  // constraint_dependencies  = 
  //   other.constraint_dependencies;

  domain = other.domain;
  domain.set_vptr( this );
}


var_int& var_int::operator=( const var_int& other )
{
  if ( this != &other )
  {
    varID       = other.varID;
    varName  = other.varName;
    varOwner = other.varOwner;
    label    = other.label;
    assigned = other.assigned;
        // constraint_dependencies  = 
    //   other.constraint_dependencies;
    
    domain = other.domain;
    domain.set_vptr( this );
  }
  return *this;
}


var_int::~var_int () 
{
  // nothing
}


void var_int::reset () 
{
  label  = -1;
  assigned = false;
  domain.set();
}

// 1. intensional hard constraints
// 2. intensional soft constraints
// 3. extensional hard constraints
// 4. extensional soft constraints
void var_int::addConstraint( Constraint& c )
{
  std::vector<Constraint*>::iterator it = constraints.begin();

  int off = 0;
  switch( c.getType() )
  {
  case intHard:
    off = nIntHard_c;
    constraints.insert( it + off, &c );
    nIntHard_c++;
    break;
  case intSoft:
    off = nIntHard_c + nIntSoft_c;
    constraints.insert( it + off, &c );
    nIntSoft_c++;
    break;
  case extHard:
    off = nIntHard_c + nIntSoft_c + nExtHard_c;
    constraints.insert( it + off, &c );
    nExtHard_c++;
    break;
  case extSoft:
    off = nIntHard_c + nIntSoft_c + nExtHard_c + nExtSoft_c;
    constraints.insert( it + off, &c );
    nExtSoft_c++;
    break;
  }

}


bool var_int::labeling()
{
  label++;
  if ( label < domain.lb_pos() ) 
    label = domain.lb_pos();
    
  while ( ( label <= domain.ub_pos() ) &&
	  ( !domain.is_valid( label ) ) ) 
  {
    label++;
  }
  if ( label > domain.ub_pos() ) { 
    label = -1; // reset label for next assignment
    return false;
  }
  return true;
}


//  O(1) if copy state is removed,
//  O(n) otherwise.
void var_int::trailBack( TrailVariable& tv )
{
  /// domain.copy_state( tv.getState() );// comment this out
  domain.copy_bounds( tv.getLowerBound(), tv.getUpperBound() ); // O(1)
  domain.copy_n_active( tv.getNactive() );			// O(1)
  domain.set_event( tv.getEvent() );				// O(1)
  unsetAssigned();						// O(1)

}


void 
var_int::dump () const
{
  std::cout << "var_int_" << varID << " ";
  std::cout << varName << " (" << varOwner << ")  ";
  cout << " constraints: ";
  
  for( auto c : constraints )
    cout << c->getName() << " ";
  cout << endl;

  // std::cout << "Label: " << label << "\t";
  // if( isAssigned() ) std::cout << " ASSIGNED ";
  std::cout << "\tDom: ";
  domain.dump();
}
