#include "globals.hh"
#include "agent.hh"
#include "domain.hh"
#include "var_int.hh"
#include "constraint.hh"
#include "relation.hh"
#include "ext-soft-constraint.hh"
#include "int-hard-constraint.hh"

std::map< std::string, Agent* >   g_agents;
std::map< std::string, Domain* >  g_domains;
std::map< std::string, var_int* > g_variables;
std::map< std::string, Constraint* > g_constraints;

std::map< size_t, Agent* >   g_Agents;
std::map< size_t, var_int* > g_Variables;
std::map< size_t, Constraint* > g_Constraints;

// used as aux for pseudo-tree construction
std::map<Agent*, std::vector<Agent*> > g_agent_neighbours;

#include "cv-matrix.hh"
// Used in R-DPOP
std::map<size_t, CVMatrix*> g_constraint2cvm;

optimization_type g_optimizationType;
size_t g_maxDomainSize;

#include "scheduler.hh"
#include "statistics.hh"
Statistics g_stats;
Scheduler*  g_scheduler;

size_t g_numof_solutions=0;
size_t g_numof_nodes_explored=0;


// CP14
bool g_BC;
bool g_BCDPOP;

