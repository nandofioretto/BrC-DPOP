#ifndef _ULISSE_PARSER_HH_
#define _ULISSE_PARSER_HH_

#include "globals.hh"

namespace Parser
{
  void parseXML ( std::string xml_file );
  void postParseInitializations();
  void dumpHelp();
};

#endif
