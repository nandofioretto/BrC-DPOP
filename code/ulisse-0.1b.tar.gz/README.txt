
ULISSE depend on Boost library
  Copy the boost folder in 
  .\Extras\

ULISSE Execution Instructions:
ulisse -i <input_file> [-es <local-search> -lx <external-search> ]

 -es options:
    <protocol>:  SBB | DPOP (external search and communication schema) 
 -ls options:
    <algorithm>: CP_DFS | DFS (internal search engine) 
