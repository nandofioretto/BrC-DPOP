#ifndef _ULISSE_INTERNAL_SEARCH_ENGINE_HH_
#define _ULISSE_INTERNAL_SEARCH_ENGINE_HH_

#include "globals.hh"
#include "search-engine.hh"

class Agent;
class ExtSoftConstraint;

  /**
   * Internal Search Engine.
   * Implements the search for values on the boundary variables of an agent.
   */
  class InternalSearchEngine : public SearchEngine
  {
  public:
    /**
     * Default constructor.
     */
    InternalSearchEngine( );
    
    /**
     * Default distructor.
     */
    ~InternalSearchEngine( );
    
    /**
     * Initializes the agent associated to this search engine, 
     * the variables over which perform the search and 
     */
    virtual void initialize( Agent& a ) = 0;

    /**
     * Init search settings, as scope of the search, solutions, etc.
     */
    virtual void initSearchSettings();

    /**
     * Popolate the hard constraints involved in the search.
     */
    virtual void initHardConstraints();

    /**
     * Popolate the soft constraints involved in the search.
     */
    virtual void initSoftConstraints();

    /**
     * Reset search state.
     */
    virtual void reset() = 0;
    
    /**
     * Finds the next satisfiable solution in the given enumeration 
     * of the solution space.
     */
    virtual bool nextSolution() = 0;
    
    /**
     * Finds the assignment to the variables in scope which optimizes
     * the local cost.
     */
    virtual bool bestSolution() = 0;
    
    /**
     * Finds all possible satisfiable solutions.
     */
    virtual bool allSolutions() = 0;
        
    /**
     * Dump the search engine specifics.
     */
    virtual void dump() const = 0;
    
    /**
     * Computes the cost related to the ext soft constraint
     */
    virtual cost_type getCost( ExtSoftConstraint& Ci );
    
    /**
     * Computes the cost of the constraints which involve boundary variables 
     * and save the solution found in curr_sol.
     */
    virtual bool processSolution();

  protected:
  };

#endif
