#include "prop-rdfs.hh"
#include "agent.hh"
#include "var_int.hh"
#include "constraint.hh"
#include "ext-soft-constraint.hh"
#include "int-hard-constraint.hh"
#include "trailstack.hh"

using namespace std;
using namespace IntSearch;

//#define DBG

PropDFS::PropDFS( )
  : continuation( -1 ), currLevel( 0 )
{ }


PropDFS::~PropDFS( )
{ }

void PropDFS::initialize( Agent& a )
{ 
  owner = &a;
  // Initializes the scope and solutions of the search
  initSearchSettings();
  // popolate the SoftConstraint vector
  initSoftConstraints();
  // popolate the HardConstraint vector
  initHardConstraints();
  
  // Init Constraint Store
  constraintStore.initialize( hardConstraints, varsIn_hardConstraints, &trailstack );

  // Init current level and continuation
  zeroLevel = a.numofBoundaryVariables();
  currLevel = zeroLevel;
  continuation = 0;
}


// @todo
bool PropDFS::nextSolution()
{
  printWarningMessage( "Internal-PropDFS::nextSolution()" );
  return false;
}


// @note:
//   for the initial propagation phase to be effective we need to ensure 
//   that the Boundary-search triggers an event on the domain of the boundary 
//   variables which is different from EMPTY and FAILED. 
bool PropDFS::bestSolution() 
{
  searchEnded = false;
  // check wheter the scope of the search is empty
  if( scope.size() == zeroLevel ) { searchEnded = true; return true; } 

  for( int i=0; i<zeroLevel; i++)
  {
    // curr_solution[ i ] = getVariable( i ).getValue();
    // best_solution[ i ] = getVariable( i ).getValue();
    curr_solution[ i ] = getVariable( i ).getLabel();
    best_solution[ i ] = getVariable( i ).getLabel();

    // Insert Variables that have been touched by the Boundary search
    // into Constraint store.
    constraintStore.signalVarChanged( getVariable( i ) );
  }
  currLevel = zeroLevel;
  best_solution.reset();
  
  // propoagate all HARD constraints listed in the ancestors
  if( not constraintStore.iSolveFix() ) {
    trailstack.backtrack( 0 );
    searchEnded = true;
    return false;
  }

  // Search Best Solution
  search();
  trailstack.backtrack( 0 );
  searchEnded = true;

  cost_type u = best_solution.getCost();
  return ( isNotNA( u ) and isFinite( u ) );
  
}


// @todo
bool PropDFS::allSolutions()
{
  printWarningMessage( "Internal-PropDFS::allSolution()" );
  return false;
}


bool PropDFS::search( )
{
  if( currLevel == scope.size() ) { 
    copySolution();   
    return processSolution();
  }

  size_t cont = trailstack.size();
  while( labeling() )
  {
    if( constraintStore.iSolveFix() )
    {
      // @todo -  Compute partial cost and check bounds. 
      nextLevel();
      search();
      prevLevel();
    }
    trailstack.backtrack( cont );
  }

  searchEnded = true;		// Flag search termination
  return true; 		     
}


bool PropDFS::labeling()
{
  var_int& v = getVariable( currLevel );

  if( v.labeling() ) 
  {
    g_numof_nodes_explored++;
    // all the changes in the var states need to be done after this statement.
    trailstack.trailVariable( v );
    // Set domain of v as singleton (FAST - acting on bounds only)
    v.setAssigned();
    constraintStore.signalVarChanged( v );
    return true;
  } 
  return false;
}


void PropDFS::copySolution( )
{
  for( int i=zeroLevel; i<scope.size(); i++ )
  {
    //curr_solution[ i ] = getVariable( i ).getValue();
    curr_solution[ i ] = getVariable( i ).getLabel();
  }
}


void PropDFS::dump() const
{
  cout << "Internal-PropDFS::scope of the Search: "
       << " scope size: " << scope.size() << endl;
  for( auto i : scope )
  {
    i->dump();
  }
}
