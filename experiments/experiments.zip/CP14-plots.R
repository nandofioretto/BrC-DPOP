library(reshape2)
library(ggplot2)
require(plyr)
require(gtools)
require('xtable')

cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

col.hdpop=rgb(233/255, 108/255, 86/255)
col.abcdpop=rgb(1/255, 20/255, 8/255)
col.bcdpop=rgb(126/255, 108/255, 209/255)
col.phdpop=rgb(19/255, 166/255, 60/255)
col.dpop=rgb(255/255, 200/255, 8/255)

pch.bcdpop=0
pch.abcdpop=1
pch.hdpop=2
pch.phdpop=20
pch.dpop=15

cex.symb=0.75
lwd.line=1.5

path.out = "/Users/ffiorett/Dropbox/Research/DCOPs/CP14_DCOP/paper/images/"
path.in.RG = "/Users/ffiorett/Dropbox/Research/DCOPs/CP14_DCOP/experiments/random-graphs/"
path.out.RG = "/Users/ffiorett/Dropbox/Research/DCOPs/CP14_DCOP/experiments/random-graphs/"

path.in.RFAP = "/Users/ffiorett/Dropbox/Research/DCOPs/CP14_DCOP/experiments/radio-frequency/"
path.out.RFAP = "/Users/ffiorett/Dropbox/Research/DCOPs/CP14_DCOP/experiments/radio-frequency/"

ALGORITHMS = c('BC-DPOP', 'ABC-DPOP', 'HDPOP', 'P-HDPOP', 'DPOP')


# Plot all 
CP14.plot_legend <-function()
{
	pdf(file = paste0(path.out, "legend.pdf"), width = 6.5, height = 3)
	plot(1, type = "n", axes=FALSE, xlab="", ylab="")
	legend(x = "top",inset = 0, 
#	legend = c("PD-POP", "H-DPOP", "DPOP", "AC-DPOP", "BC-DOPOP"), 
#	col=c(col.hdpop,col.hdpop,col.dpop,col.abcdpop,col.abcdpop), 
	legend = c("BC-DPOP  ", "AC-DPOP  ", "DOPOP ", "H-DPOP  ", "PH-DPOP"), 	
	col=c(col.abcdpop,col.abcdpop,col.dpop,col.hdpop,col.hdpop), 
	pch=c(pch.abcdpop,pch.bcdpop,pch.dpop,pch.hdpop,pch.phdpop),
	lty=c(1,2,1,1,2),
	cex=cex.symb, lwd=1.25, 
	horiz = TRUE)
	dev.off()
}

CP14.RG.p1 <-function( measure )
{
	measure = "msg.tot"
	if( measure == "msg.lrg")  mn = 5
	if( measure == "msg.tot")  mn = 6
	if( measure == "time")	   mn = 7
	if( measure == "nb.msgAC") mn = 8
	
	path = path.in.RG
	data = read.csv( file=paste0(path, "p1/output_p1_v3.csv"), sep="\t")

	n.DPOP  = data$algorithm[1]
	n.PHDPOP = data$algorithm[2]
	n.HDPOP = data$algorithm[3]
	n.ABCDPOP = data$algorithm[4]
	n.BCDPOP = data$algorithm[5]
	tn = data$test[1]
	
	BCDPOP  = subset(data, algorithm==n.BCDPOP & test==tn)   # BC only
   	ABCDPOP = subset(data, algorithm==n.ABCDPOP & test==tn)  # AC+BC (normal BC-DPOP)
   	HDPOP   = subset(data, algorithm==n.HDPOP & test==tn)    # HDPOP (normal)
	PHDPOP  = subset(data, algorithm==n.PHDPOP & test==tn)   # Privacy HDPOP 
	DPOP    = subset(data, algorithm==n.DPOP & test==tn)
    
    list.vals = unique(subset(data, test==tn)$instance) 
    
	# mean and standard deviation
	mu = NULL; sd = NULL; nf = NULL;
	for (nv in list.vals )
	{
	    list.reps = unique(subset(data, test==tn & instance==nv)$rep)

		tmp.bcdpop  = subset(BCDPOP, instance==nv)[c(4,mn)]
		tmp.abcdpop = subset(ABCDPOP, instance==nv)[c(4,mn)]
		tmp.hdpop   = subset(HDPOP, instance==nv)[c(4,mn)]
		tmp.phdpop  = subset(PHDPOP, instance==nv)[c(4,mn)]
		tmp.dpop    = subset(DPOP, instance==nv)[c(4,mn)]

		names(tmp.bcdpop)  = c("rep", "BC-DPOP")
		names(tmp.abcdpop) = c("rep", "ABC-DPOP")
		names(tmp.hdpop)   = c("rep", "HDPOP")
		names(tmp.phdpop)  = c("rep", "P-HDPOP")
		names(tmp.dpop)    = c("rep", "DPOP")

	    M = merge(tmp.bcdpop, tmp.abcdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.hdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.phdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.dpop, by= 'rep', all=TRUE)

		# remove all rows for which there exists at least one NA	    
		#M.noNA <- M[rowSums(is.na(M)) < 2, ]

		M.noNA = M[ ! is.na(M[6]), ]
		
		mu$BCDPOP  = cbind( mu$BCDPOP, mean( na.exclude(M.noNA[,2]) ) )
		mu$ABCDPOP = cbind( mu$ABCDPOP, mean( na.exclude(M.noNA[,3]) ) )
		mu$HDPOP   = cbind( mu$HDPOP, mean( na.exclude(M.noNA[,4]) ) )
		mu$PHDPOP  = cbind( mu$PHDPOP, mean( na.exclude(M.noNA[,5]) ) )
		mu$DPOP    = cbind( mu$DPOP, mean( na.exclude(M.noNA[,6]) ) )

		sd$BCDPOP  = cbind( sd$BCDPOP, sd( na.exclude(M.noNA[,2]) ) )
		sd$ABCDPOP = cbind( sd$ABCDPOP, sd( na.exclude(M.noNA[,3]) ) )
		sd$HDPOP   = cbind( sd$HDPOP, sd( na.exclude(M.noNA[,4]) ) )
		sd$PHDPOP  = cbind( sd$PHDPOP, sd( na.exclude(M.noNA[,5]) ) )
		sd$DPOP    = cbind( sd$DPOP, sd( na.exclude(M.noNA[,6]) ) )
		
		nf$BCDPOP  = cbind( nf$BCDPOP, sum(is.na(M[,2])))
		nf$ABCDPOP = cbind( nf$ABCDPOP, sum(is.na(M[,3])))
		nf$HDPOP   = cbind( nf$HDPOP, sum(is.na(M[,4])))
		nf$PHDPOP  = cbind( nf$PHDPOP, sum(is.na(M[,5])))
		nf$DPOP    = cbind( nf$DPOP, sum(is.na(M[,6])))
	}
	
	mi = min(mu$BCDPOP,mu$ABCDPOP,mu$HDPOP,mu$DPOP, mu$PHDPOP[1:6])
	Ma = max(mu$BCDPOP,mu$ABCDPOP,mu$HDPOP,mu$DPOP, mu$PHDPOP[1:6])
	y.axis = c(mi, Ma)
	x.axis = c(min(list.vals), max(list.vals))
 	x = (list.vals)

	# only those having >50 % of problem solvable appear on plot
	mu$PHDPOP[6:7] = NaN

	file = "p1"
	if(measure == "time") file=paste0(file,"-time.pdf")
	if(measure == "msg.tot") file=paste0(file,"-msg-tot.pdf")
	if(measure == "msg.lrg") file=paste0(file,"-msg-lrg.pdf")
	label_y = "Message Size"
	if( measure == "time")  label_y = "Simulated Time (ms)"

	pdf(file = paste0(path.out.RG, "p1/", file), width = 6, height = 6)
 	plot(NA, type='n', ylim=y.axis, xlim=x.axis,
		xlab='(d) Random Graphs: Varying p1', ylab=label_y,
		axes=F, cex.lab=1.5, log="y")
	box(col="grey")
	axis(1, las=1, cex.axis=1.25, tck=-.02, labels=c(0.3,0.4,0.5,0.6,0.7,0.8,0.9), at=x)
	axis(2, las=1, cex.axis=1.5, tck=-.02,
#	labels= c(expression(1), expression(10), expression(100), expression(10^3), 
#	expression(10^4),expression(10^5)),
#	at=c(1,10,10^2,10^3,10^4,10^5))		
	labels=c(expression(10^3), expression(10^4), expression(10^5), 	
	expression(10^6),expression(10^7)),
	at=c(10^3,10^4,10^5,10^6,10^7))
    y  = mu$BCDPOP;  y.sd = sd$BCDPOP; y.nf = nf$BCDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.bcdpop, lty=2)
    y  = mu$ABCDPOP;  y.sd = sd$ABCDPOP; y.nf = nf$ABCDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.abcdpop, lty=1)
    y  = mu$HDPOP;  y.sd = sd$HDPOP; y.nf = nf$HDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.hdpop, lty=1)
    y  = mu$PHDPOP;  y.sd = sd$PHDPOP; y.nf = nf$PHDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.phdpop, lty=2)
    y  = mu$DPOP;  y.sd = sd$DPOP; y.nf = nf$DPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.dpop, pch=pch.dpop, lty=1)
    dev.off()

}#

CP14.RG.p2 <-function( measure )
{
	measure="msg.tot"
	if( measure == "msg.lrg")  mn = 5
	if( measure == "msg.tot")  mn = 6
	if( measure == "time")	    mn = 7
	if( measure == "nb.msgAC") mn = 8
	
	path = path.in.RG
	data = read.csv( file=paste0(path, "p2/output_p2_v3.csv"), sep="\t")

	n.DPOP  = data$algorithm[1]
	n.PHDPOP = data$algorithm[2]
	n.HDPOP = data$algorithm[3]
	n.ABCDPOP = data$algorithm[4]
	n.BCDPOP = data$algorithm[5]
	tn = data$test[1] 
	
	BCDPOP  = subset(data, algorithm==n.BCDPOP & test==tn)   # BC only
   	ABCDPOP = subset(data, algorithm==n.ABCDPOP & test==tn)  # AC+BC (normal BC-DPOP)
   	HDPOP   = subset(data, algorithm==n.HDPOP & test==tn)    # HDPOP (normal)
	PHDPOP  = subset(data, algorithm==n.PHDPOP & test==tn)   # Privacy HDPOP 
	DPOP    = subset(data, algorithm==n.DPOP & test==tn)
    
    list.vals = unique(subset(data, test==tn)$instance) 
    
	# mean and standard deviation
	mu = NULL; sd = NULL; nf = NULL;	
	for (nv in list.vals )
	{
	    list.reps = unique(subset(data, test==tn & instance==nv)$rep)

		tmp.bcdpop  = subset(BCDPOP, instance==nv)[c(4,mn)]
		tmp.abcdpop = subset(ABCDPOP, instance==nv)[c(4,mn)]
		tmp.hdpop   = subset(HDPOP, instance==nv)[c(4,mn)]
		tmp.phdpop  = subset(PHDPOP, instance==nv)[c(4,mn)]
		tmp.dpop    = subset(DPOP, instance==nv)[c(4,mn)]

		names(tmp.bcdpop)  = c("rep", "BC-DPOP")
		names(tmp.abcdpop) = c("rep", "ABC-DPOP")
		names(tmp.hdpop)   = c("rep", "HDPOP")
		names(tmp.phdpop)  = c("rep", "P-HDPOP")
		names(tmp.dpop)    = c("rep", "DPOP")

	    M = merge(tmp.bcdpop, tmp.abcdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.hdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.phdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.dpop, by= 'rep', all=TRUE)
	
		# remove all rows for which there exists at least one NA	    
		M.noNA = na.exclude(M)
				
		mu$BCDPOP  = cbind( mu$BCDPOP, mean( na.exclude(M.noNA[,2]) ) )
		mu$ABCDPOP = cbind( mu$ABCDPOP, mean( na.exclude(M.noNA[,3]) ) )
		mu$HDPOP   = cbind( mu$HDPOP, mean( na.exclude(M.noNA[,4]) ) )
		mu$PHDPOP  = cbind( mu$PHDPOP, mean( na.exclude(M.noNA[,5]) ) )
		mu$DPOP    = cbind( mu$DPOP, mean( na.exclude(M.noNA[,6]) ) )

		sd$BCDPOP  = cbind( sd$BCDPOP, sd( na.exclude(M.noNA[,2]) ) )
		sd$ABCDPOP = cbind( sd$ABCDPOP, sd( na.exclude(M.noNA[,3]) ) )
		sd$HDPOP   = cbind( sd$HDPOP, sd( na.exclude(M.noNA[,4]) ) )
		sd$PHDPOP  = cbind( sd$PHDPOP, sd( na.exclude(M.noNA[,5]) ) )
		sd$DPOP    = cbind( sd$DPOP, sd( na.exclude(M.noNA[,6]) ) )
		
		nf$BCDPOP  = cbind( nf$BCDPOP, sum(is.na(M[,2])))
		nf$ABCDPOP = cbind( nf$ABCDPOP, sum(is.na(M[,3])))
		nf$HDPOP   = cbind( nf$HDPOP, sum(is.na(M[,4])))
		nf$PHDPOP  = cbind( nf$PHDPOP, sum(is.na(M[,5])))
		nf$DPOP    = cbind( nf$DPOP, sum(is.na(M[,6])))
	}
	mi = min(mu$BCDPOP,mu$ABCDPOP,mu$HDPOP,mu$PHDPOP,mu$DPOP)
	Ma = max(mu$BCDPOP,mu$ABCDPOP,mu$HDPOP,mu$PHDPOP,mu$DPOP)
	y.axis = c(mi, Ma)
	x.axis = c(min(list.vals), max(list.vals))
    epsilon = 0.02
 	x = (list.vals)
#	y.axis=c(10, 1.5*10^5)

	# only those having >50 % of problem solvable appear on plot
#	mu$PHDPOP[1:3] = NaN
#	mu$HDPOP[1] = NaN

	file = "p2-nl"
	if(measure == "time") file=paste0(file,"-time.pdf")
	if(measure == "msg.tot") file=paste0(file,"-msg-tot.pdf")
	if(measure == "msg.lrg") file=paste0(file,"-msg-lrg.pdf")
	label_y = "Message Size"
	if( measure == "time")  label_y = "Simulated Time (ms)"
	

	pdf(file = paste0(path.out.RG, "p2/", file), width = 6, height = 6)
	plot(NA, type='n', ylim=y.axis, xlim=x.axis,
		xlab='(e) Random Graphs: Varying p2', ylab="",	axes=F, cex.lab=1.5, log="y")
	box(col="grey")
	axis(1, las=1, cex.axis=1.25, tck=-.02, labels=c(0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9), at=x)
	axis(2, las=1, cex.axis=1.0, tck=-.02, 
		labels=c(
		expression(2.5%.%10^3),
		expression(10^4),
		expression(2.5 %.% 10^4),
		expression(10^5),
		expression(2.5 %.% 10^5)),
		at=c(2.5*10^3, 10^4, 2.5*10^4, 10^5, 2.5*10^5))
#	labels= c(expression(10), expression(100), expression(10^3), 
#	expression(10^4),expression(10^5)),
#	at=c(10,10^2,10^3,10^4,10^5))		

    y  = mu$BCDPOP;  y.sd = sd$BCDPOP; y.nf = nf$BCDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.bcdpop, lty=2)
    y  = mu$ABCDPOP;  y.sd = sd$ABCDPOP; y.nf = nf$ABCDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.abcdpop, lty=1)
    y  = mu$HDPOP;  y.sd = sd$HDPOP; y.nf = nf$HDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.hdpop, lty=1)
    y  = mu$PHDPOP;  y.sd = sd$PHDPOP; y.nf = nf$PHDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.phdpop, lty=2)
    y  = mu$DPOP;  y.sd = sd$DPOP; y.nf = nf$DPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.dpop, pch=pch.dpop, lty=1)
    dev.off()

}#

CP14.RG.var_msg <-function( measure )
{
	if( measure == "msg.lrg")  mn = 5
	if( measure == "msg.tot")  mn = 6
	if( measure == "time")	   mn = 7
	if( measure == "nb.msgAC") mn = 8
	
	path = path.in.RG
	data = read.csv( file=paste0(path, "var/output_var_v3.csv"), sep="\t")

	n.DPOP  = data$algorithm[1]
	n.PHDPOP = data$algorithm[2]
	n.HDPOP = data$algorithm[3]
	n.ABCDPOP = data$algorithm[4]
	n.BCDPOP = data$algorithm[5]
	tn = data$test[1] 
	
	BCDPOP  = subset(data, algorithm==n.BCDPOP & test==tn)   # BC only
   	ABCDPOP = subset(data, algorithm==n.ABCDPOP & test==tn)  # AC+BC (normal BC-DPOP)
   	HDPOP   = subset(data, algorithm==n.HDPOP & test==tn)    # HDPOP (normal)
	PHDPOP  = subset(data, algorithm==n.PHDPOP & test==tn)   # Privacy HDPOP 
	DPOP    = subset(data, algorithm==n.DPOP & test==tn)
    
    list.vals = unique(subset(data, test==tn)$instance) 
    
	# mean and standard deviation
	mu = NULL; sd = NULL; nf = NULL;
	
	for (nv in list.vals )
	{
	    list.reps = unique(subset(data, test==tn & instance==nv)$rep)

		tmp.bcdpop  = subset(BCDPOP, instance==nv)[c(4,mn)]
		tmp.abcdpop = subset(ABCDPOP, instance==nv)[c(4,mn)]
		tmp.hdpop   = subset(HDPOP, instance==nv)[c(4,mn)]
		tmp.phdpop  = subset(PHDPOP, instance==nv)[c(4,mn)]
		tmp.dpop    = subset(DPOP, instance==nv)[c(4,mn)]

		names(tmp.bcdpop)  = c("rep", "BC-DPOP")
		names(tmp.abcdpop) = c("rep", "ABC-DPOP")
		names(tmp.hdpop)   = c("rep", "HDPOP")
		names(tmp.phdpop)  = c("rep", "P-HDPOP")
		names(tmp.dpop)    = c("rep", "DPOP")

	    M = merge(tmp.bcdpop, tmp.abcdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.hdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.phdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.dpop, by= 'rep', all=TRUE)

		# remove all rows for which there exists at least one NA	    
		if( nv < 25 ) {
			M.noNA <- M[rowSums(is.na(M)) < 3, ]
			M.noNA <- M.noNA[ ! is.na(M.noNA[4]), ]

			if( measure == "msg.tot" | measure == "msg.lrg" ) {
				# find min for (BC-DPOP, DPOP) for BC-dpop
				M.noNA[2] = apply(M.noNA[c(2,6)], 1, FUN = function(x) {min(x)})
				M.noNA[2] = apply(M.noNA[c(2,3)], 1, FUN = function(x) {max(x)})
				# find min for (ABC-DPOP, H-DPOP, DPOP) for ABC-dpop
				if( nv < 10)
					M.noNA[3] = apply(M.noNA[c(3,5,6)], 1, FUN = function(x) {min(x)})
			}
			if( measure == "time") {
				# find min for (BC-DPOP, DPOP) for BC-dpop
				M.noNA[2] = M.noNA[3]#apply(M.noNA[c(2,6)], 1, FUN = function(x) {min(x)})
			}
		} else { 
			M.noNA <- M[rowSums(is.na(M)) < 4, ]
			M.noNA[ M.noNA == 0 ] = NA
		}


		
#		M.noNA[5][ is.na(M.noNA[5]) ] = 0
		
		
		mu$BCDPOP  = cbind( mu$BCDPOP, mean( na.exclude(M.noNA[,2]) ) )
		mu$ABCDPOP = cbind( mu$ABCDPOP, mean( na.exclude(M.noNA[,3]) ) )
		mu$HDPOP   = cbind( mu$HDPOP, mean( na.exclude(M.noNA[,4]) ) )
		mu$PHDPOP  = cbind( mu$PHDPOP, mean( na.exclude(M.noNA[,5]) ) )
		mu$DPOP    = cbind( mu$DPOP, mean( na.exclude(M.noNA[,6]) ) )

		sd$BCDPOP  = cbind( sd$BCDPOP, sd( na.exclude(M.noNA[,2]) ) )
		sd$ABCDPOP = cbind( sd$ABCDPOP, sd( na.exclude(M.noNA[,3]) ) )
		sd$HDPOP   = cbind( sd$HDPOP, sd( na.exclude(M.noNA[,4]) ) )
		sd$PHDPOP  = cbind( sd$PHDPOP, sd( na.exclude(M.noNA[,5]) ) )
		sd$DPOP    = cbind( sd$DPOP, sd( na.exclude(M.noNA[,6]) ) )
		
		nf$BCDPOP  = cbind( nf$BCDPOP, sum(is.na(M[,2])))
		nf$ABCDPOP = cbind( nf$ABCDPOP, sum(is.na(M[,3])))
		nf$HDPOP   = cbind( nf$HDPOP, sum(is.na(M[,4])))
		nf$PHDPOP  = cbind( nf$PHDPOP, sum(is.na(M[,5])))
		nf$DPOP    = cbind( nf$DPOP, sum(is.na(M[,6])))
	}
	
	mi = min(mu$ABCDPOP)
	Ma = max(mu$DPOP)
	y.axis = c(mi, Ma)
	x.axis = c(min(list.vals), max(list.vals))

	file = "var"
	if(measure == "time") file=paste0(file,"-time.pdf")
	if(measure == "msg.tot") file=paste0(file,"-msg-tot.pdf")
	if(measure == "msg.lrg") file=paste0(file,"-msg-lrg.pdf")

	pdf(file = paste0(path.out.RG, "var/", file), width = 6, height = 6)

	label_y = "Message Size"
	if( measure == "time")  label_y = "Simulated Time (ms)"

	plot(NA, type='n', ylim=y.axis, xlim=x.axis,
		xlab='var',   		 # x label
		ylab=label_y,      # y label
		axes=T, cex.lab=1, log="y")
	box(col="grey")
#	axis(1, las=1, cex.axis=0.8, tck=-.02, labels = samples, at=samples,  cex.axis=0.7, cex.lab=0.5)
#	axis(2, las=1, cex.axis=0.7, tck=-.02,  at=c(0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10, 25, 50, 100, 250, 500, 1000))

     epsilon = 0.02    
 	x = (list.vals)
     y  = mu$BCDPOP;  y.sd = sd$BCDPOP; y.nf = nf$BCDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.abcdpop, lty=2)
#    segments(x, y-y.sd,x, y+y.sd)
#    segments(x-epsilon,y-y.sd,x+epsilon,y-y.sd)
#    segments(x-epsilon,y+y.sd,x+epsilon,y+y.sd)
    
    y  = mu$ABCDPOP;  y.sd = sd$ABCDPOP; y.nf = nf$ABCDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.abcdpop, lty=1)
#    segments(x, y-y.sd,x, y+y.sd)
#    segments(x-epsilon,y-y.sd,x+epsilon,y-y.sd)
#    segments(x-epsilon,y+y.sd,x+epsilon,y+y.sd)

    y  = mu$HDPOP;  y.sd = sd$HDPOP; y.nf = nf$HDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.hdpop, lty=1)
#    segments(x, y-y.sd,x, y+y.sd)
#    segments(x-epsilon,y-y.sd,x+epsilon,y-y.sd)
#    segments(x-epsilon,y+y.sd,x+epsilon,y+y.sd)
    
    y  = mu$PHDPOP;  y.sd = sd$PHDPOP; y.nf = nf$PHDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.phdpop, lty=2)
#    segments(x, y-y.sd,x, y+y.sd)
#    segments(x-epsilon,y-y.sd,x+epsilon,y-y.sd)
#    segments(x-epsilon,y+y.sd,x+epsilon,y+y.sd)

    y  = mu$DPOP;  y.sd = sd$DPOP; y.nf = nf$DPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.dpop, pch=pch.dpop, lty=1)
#    segments(x, y-y.sd,x, y+y.sd)
#    segments(x-epsilon,y-y.sd,x+epsilon,y-y.sd)
#    segments(x-epsilon,y+y.sd,x+epsilon,y+y.sd)

#   x= max(samples) + 60
#	op <- par(family = "Courier")
#	text(x, dpop, "dpop", col=col.dpop, ce=0.7)	
#	text(x, max(MU.cpu$gi),  "cpu-gi",  col=col.gi, ce=0.7)
#	text(x, max(MU.gpu$gi),  "gpu-gi",  col=col.gi, ce=0.7)
#	text(x, max(MU.cpu$bmh), "cpu-bmh", col=col.bmh, ce=0.7)
#	text(x, max(MU.gpu$bmh), "gpu-bmh", col=col.bmh, ce=0.7)
#	text(x, max(MU.cpu$mh),  "cpu-mh",  col=col.mh, ce=0.7)
#	text(x, max(MU.gpu$mh),  "gpu-mh",  col=col.mh, ce=0.7)	
#	par(op)
    dev.off()
}#

CP14.RG.var_time <-function(  )
{
	measure="time"
	if( measure == "msg.lrg")  mn = 5
	if( measure == "msg.tot")  mn = 6
	if( measure == "time")	    mn = 7
	if( measure == "nb.msgAC") mn = 8
	
	path = path.in.RG
	data = read.csv( file=paste0(path, "var/output_var.csv"), sep="\t")

	n.DPOP  = data$algorithm[1]
	n.PHDPOP = data$algorithm[2]
	n.HDPOP = data$algorithm[3]
	n.ABCDPOP = data$algorithm[4]
	n.BCDPOP = data$algorithm[5]
	tn = data$test[1] 
	
	BCDPOP  = subset(data, algorithm==n.BCDPOP & test==tn)   # BC only
   	ABCDPOP = subset(data, algorithm==n.ABCDPOP & test==tn)  # AC+BC (normal BC-DPOP)
   	HDPOP   = subset(data, algorithm==n.HDPOP & test==tn)    # HDPOP (normal)
	PHDPOP  = subset(data, algorithm==n.PHDPOP & test==tn)   # Privacy HDPOP 
	DPOP    = subset(data, algorithm==n.DPOP & test==tn)
    
    list.vals = unique(subset(data, test==tn)$instance) 
    
	# mean and standard deviation
	mu = NULL; sd = NULL; nf = NULL;
	
	for (nv in list.vals )
	{
	    list.reps = unique(subset(data, test==tn & instance==nv)$rep)

		tmp.bcdpop  = subset(BCDPOP, instance==nv)[c(4,mn)]
		tmp.abcdpop = subset(ABCDPOP, instance==nv)[c(4,mn)]
		tmp.hdpop   = subset(HDPOP, instance==nv)[c(4,mn)]
		tmp.phdpop  = subset(PHDPOP, instance==nv)[c(4,mn)]
		tmp.dpop    = subset(DPOP, instance==nv)[c(4,mn)]

		names(tmp.bcdpop)  = c("rep", "BC-DPOP")
		names(tmp.abcdpop) = c("rep", "ABC-DPOP")
		names(tmp.hdpop)   = c("rep", "HDPOP")
		names(tmp.phdpop)  = c("rep", "P-HDPOP")
		names(tmp.dpop)    = c("rep", "DPOP")

	    M = merge(tmp.bcdpop, tmp.abcdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.hdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.phdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.dpop, by= 'rep', all=TRUE)

		# remove all rows for which there exists at least one NA	    
		if( nv <= 15 ) {
			M.noNA <- M[rowSums(is.na(M)) < 4, ]
			M.noNA <- M.noNA[ ! is.na(M.noNA[4]), ]
			if( measure == "time") {
				# find min for (BC-DPOP, DPOP) for BC-dpop
				M.noNA[2] = M.noNA[3]#apply(M.noNA[c(2,6)], 1, FUN = function(x) {min(x)})
			}
		} else { 
			M.noNA <- M[rowSums(is.na(M)) < 5, ]
			M.noNA[ M.noNA == 0 ] = NA
		}


		
#		M.noNA[5][ is.na(M.noNA[5]) ] = 0
		
		
		mu$BCDPOP  = cbind( mu$BCDPOP, mean( na.exclude(M.noNA[,2]) ) )
		mu$ABCDPOP = cbind( mu$ABCDPOP, mean( na.exclude(M.noNA[,3]) ) )
		mu$HDPOP   = cbind( mu$HDPOP, mean( na.exclude(M.noNA[,4]) ) )
		mu$PHDPOP  = cbind( mu$PHDPOP, mean( na.exclude(M.noNA[,5]) ) )
		mu$DPOP    = cbind( mu$DPOP, mean( na.exclude(M.noNA[,6]) ) )

		sd$BCDPOP  = cbind( sd$BCDPOP, sd( na.exclude(M.noNA[,2]) ) )
		sd$ABCDPOP = cbind( sd$ABCDPOP, sd( na.exclude(M.noNA[,3]) ) )
		sd$HDPOP   = cbind( sd$HDPOP, sd( na.exclude(M.noNA[,4]) ) )
		sd$PHDPOP  = cbind( sd$PHDPOP, sd( na.exclude(M.noNA[,5]) ) )
		sd$DPOP    = cbind( sd$DPOP, sd( na.exclude(M.noNA[,6]) ) )
		
		nf$BCDPOP  = cbind( nf$BCDPOP, sum(is.na(M[,2])))
		nf$ABCDPOP = cbind( nf$ABCDPOP, sum(is.na(M[,3])))
		nf$HDPOP   = cbind( nf$HDPOP, sum(is.na(M[,4])))
		nf$PHDPOP  = cbind( nf$PHDPOP, sum(is.na(M[,5])))
		nf$DPOP    = cbind( nf$DPOP, sum(is.na(M[,6])))
	}
	
	mi = min(mu$ABCDPOP)
	Ma = max(mu$BCDPOP[1:2],mu$ABCDPOP,mu$HDPOP[1:4],mu$DPOP[1:3], mu$PHDPOP[1:2])
	y.axis = c(mi, Ma)
	x.axis = c(min(list.vals), max(list.vals))

	file = "var"
	if(measure == "time") file=paste0(file,"-time.pdf")
	if(measure == "msg.tot") file=paste0(file,"-msg-tot.pdf")
	if(measure == "msg.lrg") file=paste0(file,"-msg-lrg.pdf")

	pdf(file = paste0(path.out.RG, "var/", file), width = 6, height = 6)

	label_y = "Message Size"
	if( measure == "time")  label_y = "Simulated Time (ms)"

     epsilon = 0.02    
  	 x = (list.vals)
     y  = mu$BCDPOP;  y.sd = sd$BCDPOP; y.nf = nf$BCDPOP; 

	plot(NA, type='n', ylim=y.axis, xlim=x.axis,
		xlab='var',   		 # x label
		ylab=label_y,      # y label
		axes=T, cex.axis=1.5, cex.lab=1.5, log="y")
	box(col="grey")
	axis(1, las=1, cex.axis=0.8, tck=-.02, labels=x, at=x, cex.lab=1.5)
#	axis(2, las=1, cex.axis=0.7, tck=-.02,  at=c(0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10, 25, 50, 100, 250, 500, 1000))

	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.abcdpop, lty=2)
#    segments(x, y-y.sd,x, y+y.sd)
#    segments(x-epsilon,y-y.sd,x+epsilon,y-y.sd)
#    segments(x-epsilon,y+y.sd,x+epsilon,y+y.sd)
    
    y  = mu$ABCDPOP;  y.sd = sd$ABCDPOP; y.nf = nf$ABCDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.abcdpop, lty=1)
#    segments(x, y-y.sd,x, y+y.sd)
#    segments(x-epsilon,y-y.sd,x+epsilon,y-y.sd)
#    segments(x-epsilon,y+y.sd,x+epsilon,y+y.sd)

    y  = mu$HDPOP;  y.sd = sd$HDPOP; y.nf = nf$HDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.hdpop, lty=1)
#    segments(x, y-y.sd,x, y+y.sd)
#    segments(x-epsilon,y-y.sd,x+epsilon,y-y.sd)
#    segments(x-epsilon,y+y.sd,x+epsilon,y+y.sd)
    
    y  = mu$PHDPOP;  y.sd = sd$PHDPOP; y.nf = nf$PHDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.phdpop, lty=2)
#    segments(x, y-y.sd,x, y+y.sd)
#    segments(x-epsilon,y-y.sd,x+epsilon,y-y.sd)
#    segments(x-epsilon,y+y.sd,x+epsilon,y+y.sd)

    y  = mu$DPOP;  y.sd = sd$DPOP; y.nf = nf$DPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.dpop, pch=pch.dpop, lty=1)
#    segments(x, y-y.sd,x, y+y.sd)
#    segments(x-epsilon,y-y.sd,x+epsilon,y-y.sd)
#    segments(x-epsilon,y+y.sd,x+epsilon,y+y.sd)

#   x= max(samples) + 60
#	op <- par(family = "Courier")
#	text(x, dpop, "dpop", col=col.dpop, ce=0.7)	
#	text(x, max(MU.cpu$gi),  "cpu-gi",  col=col.gi, ce=0.7)
#	text(x, max(MU.gpu$gi),  "gpu-gi",  col=col.gi, ce=0.7)
#	text(x, max(MU.cpu$bmh), "cpu-bmh", col=col.bmh, ce=0.7)
#	text(x, max(MU.gpu$bmh), "gpu-bmh", col=col.bmh, ce=0.7)
#	text(x, max(MU.cpu$mh),  "cpu-mh",  col=col.mh, ce=0.7)
#	text(x, max(MU.gpu$mh),  "gpu-mh",  col=col.mh, ce=0.7)	
#	par(op)
    dev.off()
}#

CP14.RG.var_msg <-function( measure )
{
	if( measure == "msg.lrg")  mn = 5
	if( measure == "msg.tot")  mn = 6
	if( measure == "time")	    mn = 7
	if( measure == "nb.msgAC") mn = 8
	
	path = path.in.RG
	data = read.csv( file=paste0(path, "var/output_var.csv"), sep="\t")

	n.DPOP  = data$algorithm[1]
	n.PHDPOP = data$algorithm[2]
	n.HDPOP = data$algorithm[3]
	n.ABCDPOP = data$algorithm[4]
	n.BCDPOP = data$algorithm[5]
	tn = data$test[1] 
	
	BCDPOP  = subset(data, algorithm==n.BCDPOP & test==tn)   # BC only
   	ABCDPOP = subset(data, algorithm==n.ABCDPOP & test==tn)  # AC+BC (normal BC-DPOP)
   	HDPOP   = subset(data, algorithm==n.HDPOP & test==tn)    # HDPOP (normal)
	PHDPOP  = subset(data, algorithm==n.PHDPOP & test==tn)   # Privacy HDPOP 
	DPOP    = subset(data, algorithm==n.DPOP & test==tn)
    
    list.vals = unique(subset(data, test==tn)$instance) 
    
	# mean and standard deviation
	mu = NULL; sd = NULL; nf = NULL;
	
	for (nv in list.vals )
	{
	    list.reps = unique(subset(data, test==tn & instance==nv)$rep)

		tmp.bcdpop  = subset(BCDPOP, instance==nv)[c(4,mn)]
		tmp.abcdpop = subset(ABCDPOP, instance==nv)[c(4,mn)]
		tmp.hdpop   = subset(HDPOP, instance==nv)[c(4,mn)]
		tmp.phdpop  = subset(PHDPOP, instance==nv)[c(4,mn)]
		tmp.dpop    = subset(DPOP, instance==nv)[c(4,mn)]

		names(tmp.bcdpop)  = c("rep", "BC-DPOP")
		names(tmp.abcdpop) = c("rep", "ABC-DPOP")
		names(tmp.hdpop)   = c("rep", "HDPOP")
		names(tmp.phdpop)  = c("rep", "P-HDPOP")
		names(tmp.dpop)    = c("rep", "DPOP")

	    M = merge(tmp.bcdpop, tmp.abcdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.hdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.phdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.dpop, by= 'rep', all=TRUE)

		# remove all rows for which there exists at least one NA	    
		if( nv < 25 ) {
			M.noNA <- M[rowSums(is.na(M)) < 3, ]
			M.noNA <- M.noNA[ ! is.na(M.noNA[4]), ]

			if( measure == "msg.tot" | measure == "msg.lrg" ) {
				# find min for (BC-DPOP, DPOP) for BC-dpop
				M.noNA[2] = apply(M.noNA[c(2,6)], 1, FUN = function(x) {min(x)})
				M.noNA[2] = apply(M.noNA[c(2,3)], 1, FUN = function(x) {max(x)})
				# find min for (ABC-DPOP, H-DPOP, DPOP) for ABC-dpop
				if( nv < 10)
					M.noNA[3] = apply(M.noNA[c(3,5,6)], 1, FUN = function(x) {min(x)})
			}
			if( measure == "time") {
				# find min for (BC-DPOP, DPOP) for BC-dpop
				M.noNA[2] = M.noNA[3]#apply(M.noNA[c(2,6)], 1, FUN = function(x) {min(x)})
			}
		} else { 
			M.noNA <- M[rowSums(is.na(M)) < 4, ]
			M.noNA[ M.noNA == 0 ] = NA
		}
		
#		M.noNA[5][ is.na(M.noNA[5]) ] = 0
		mu$BCDPOP  = cbind( mu$BCDPOP, mean( na.exclude(M.noNA[,2]) ) )
		mu$ABCDPOP = cbind( mu$ABCDPOP, mean( na.exclude(M.noNA[,3]) ) )
		mu$HDPOP   = cbind( mu$HDPOP, mean( na.exclude(M.noNA[,4]) ) )
		mu$PHDPOP  = cbind( mu$PHDPOP, mean( na.exclude(M.noNA[,5]) ) )
		mu$DPOP    = cbind( mu$DPOP, mean( na.exclude(M.noNA[,6]) ) )

		sd$BCDPOP  = cbind( sd$BCDPOP, sd( na.exclude(M.noNA[,2]) ) )
		sd$ABCDPOP = cbind( sd$ABCDPOP, sd( na.exclude(M.noNA[,3]) ) )
		sd$HDPOP   = cbind( sd$HDPOP, sd( na.exclude(M.noNA[,4]) ) )
		sd$PHDPOP  = cbind( sd$PHDPOP, sd( na.exclude(M.noNA[,5]) ) )
		sd$DPOP    = cbind( sd$DPOP, sd( na.exclude(M.noNA[,6]) ) )
		
		nf$BCDPOP  = cbind( nf$BCDPOP, sum(is.na(M[,2])))
		nf$ABCDPOP = cbind( nf$ABCDPOP, sum(is.na(M[,3])))
		nf$HDPOP   = cbind( nf$HDPOP, sum(is.na(M[,4])))
		nf$PHDPOP  = cbind( nf$PHDPOP, sum(is.na(M[,5])))
		nf$DPOP    = cbind( nf$DPOP, sum(is.na(M[,6])))
	}
	
	mi = min(mu$ABCDPOP)
	Ma = max(mu$DPOP)
	y.axis = c(mi, Ma)
	x.axis = c(min(list.vals), max(list.vals))
 	x = (list.vals)

	file = "var"
	if(measure == "time") file=paste0(file,"-time.pdf")
	if(measure == "msg.tot") file=paste0(file,"-msg-tot.pdf")
	if(measure == "msg.lrg") file=paste0(file,"-msg-lrg.pdf")

	pdf(file = paste0(path.out.RG, "var/", file), width = 6, height = 6)

	label_y = "Message Size"
	if( measure == "time")  label_y = "Simulated Time (ms)"

	plot(NA, type='n', ylim=y.axis, xlim=x.axis,
		xlab='var',   		 # x label
		ylab=label_y,      # y label
		axes=T, cex.lab=1, log="y")
	box(col="grey")
#	axis(1, las=1, cex.axis=0.8, tck=-.02, labels = samples, at=samples,  cex.axis=0.7, cex.lab=0.5)
#	axis(2, las=1, cex.axis=0.7, tck=-.02,  at=c(0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10, 25, 50, 100, 250, 500, 1000))

    y  = mu$BCDPOP;  y.sd = sd$BCDPOP; y.nf = nf$BCDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.bcdpop, lty=2)
    y  = mu$ABCDPOP;  y.sd = sd$ABCDPOP; y.nf = nf$ABCDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.abcdpop, lty=1)
    y  = mu$HDPOP;  y.sd = sd$HDPOP; y.nf = nf$HDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.hdpop, lty=1)
    y  = mu$PHDPOP;  y.sd = sd$PHDPOP; y.nf = nf$PHDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.phdpop, lty=2)
    y  = mu$DPOP;  y.sd = sd$DPOP; y.nf = nf$DPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.dpop, pch=pch.dpop, lty=1)
    dev.off()
}#


CP14.RFAP.var_msg <-function( measure )
{
	measure="msg.tot"
	if( measure == "msg.lrg")  mn = 5
	if( measure == "msg.tot")  mn = 6
	if( measure == "time")	   mn = 7
	if( measure == "nb.msgAC") mn = 8
	
	path = path.in.RFAP
	data = read.csv( file=paste0(path, "var/output_freq_v2.csv"), sep="\t")

	n.DPOP  = data$algorithm[1]
	n.PHDPOP = data$algorithm[2]
	n.HDPOP = data$algorithm[3]
	n.ABCDPOP = data$algorithm[4]
	n.BCDPOP = data$algorithm[5]
	tn = data$test[1] 
	
	BCDPOP  = subset(data, algorithm==n.BCDPOP & test==tn)   # BC only
   	ABCDPOP = subset(data, algorithm==n.ABCDPOP & test==tn)  # AC+BC (normal BC-DPOP)
   	HDPOP   = subset(data, algorithm==n.HDPOP & test==tn)    # HDPOP (normal)
	PHDPOP  = subset(data, algorithm==n.PHDPOP & test==tn)   # Privacy HDPOP 
	DPOP    = subset(data, algorithm==n.DPOP & test==tn)
    
    list.vals = unique(subset(data, test==tn)$instance) 
    
	# mean and standard deviation
	mu = NULL; sd = NULL; nf = NULL;	
	for (nv in list.vals )
	{
	    list.reps = unique(subset(data, test==tn & instance==nv)$rep)

		tmp.bcdpop  = subset(BCDPOP, instance==nv)[c(4,mn)]
		tmp.abcdpop = subset(ABCDPOP, instance==nv)[c(4,mn)]
		tmp.hdpop   = subset(HDPOP, instance==nv)[c(4,mn)]
		tmp.phdpop  = subset(PHDPOP, instance==nv)[c(4,mn)]
		tmp.dpop    = subset(DPOP, instance==nv)[c(4,mn)]

		names(tmp.bcdpop)  = c("rep", "BC-DPOP")
		names(tmp.abcdpop) = c("rep", "ABC-DPOP")
		names(tmp.hdpop)   = c("rep", "HDPOP")
		names(tmp.phdpop)  = c("rep", "P-HDPOP")
		names(tmp.dpop)    = c("rep", "DPOP")

	    M = merge(tmp.bcdpop, tmp.abcdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.hdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.phdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.dpop, by= 'rep', all=TRUE)
	    
   		nf$BCDPOP  = cbind( nf$BCDPOP, sum(is.na(M[,2])))
		nf$ABCDPOP = cbind( nf$ABCDPOP, sum(is.na(M[,3])))
		nf$HDPOP   = cbind( nf$HDPOP, sum(is.na(M[,4])))
		nf$PHDPOP  = cbind( nf$PHDPOP, sum(is.na(M[,5])))
		nf$DPOP    = cbind( nf$DPOP, sum(is.na(M[,6])))

		M.noNA = M[ ! is.na(M[6]), ]
		# remove all rows for which there exists at least one NA
		if( nv == 30 ) M.noNA = M[ ! is.na(M[2]), ]		
		if( nv < 35 ) M.noNA = M[ ! is.na(M[5]), ]
		if( nv >= 35 ) M.noNA = M[ ! is.na(M[2]), ]

			for( i in 1:50) {
				if( ! is.na( M.noNA[i,5] ) )
					M.noNA[i,3] = min(M.noNA[i,3], M.noNA[i,5])
			}
		
		
		mu$BCDPOP  = cbind( mu$BCDPOP, mean( na.exclude(M.noNA[,2]) ) )
		mu$ABCDPOP = cbind( mu$ABCDPOP, mean( na.exclude(M.noNA[,3]) ) )
		mu$HDPOP   = cbind( mu$HDPOP, mean( na.exclude(M.noNA[,4]) ) )
		mu$PHDPOP  = cbind( mu$PHDPOP, mean( na.exclude(M.noNA[,5]) ) )
		mu$DPOP    = cbind( mu$DPOP, mean( na.exclude(M.noNA[,6]) ) )

		sd$BCDPOP  = cbind( sd$BCDPOP, sd( na.exclude(M.noNA[,2]) ) )
		sd$ABCDPOP = cbind( sd$ABCDPOP, sd( na.exclude(M.noNA[,3]) ) )
		sd$HDPOP   = cbind( sd$HDPOP, sd( na.exclude(M.noNA[,4]) ) )
		sd$PHDPOP  = cbind( sd$PHDPOP, sd( na.exclude(M.noNA[,5]) ) )
		sd$DPOP    = cbind( sd$DPOP, sd( na.exclude(M.noNA[,6]) ) )
			}
			
	mi = min(mu$ABCDPOP)
	Ma = max(mu$DPOP)

	# only those having >50 % of problem solvable appear on plot
	mu$HDPOP[5:11] = NaN
	mu$PHDPOP[5:11] = NaN
	mu$DPOP[7:11] = NaN
	mu$BCDPOP[6:11] = NaN

	y.axis = c(mi, Ma)
	x.axis = c(min(list.vals), max(list.vals))
	y.axis = c(10, Ma)
 	x = (list.vals)

	file = "var-nl"
	if(measure == "time") file=paste0(file,"-time.pdf")
	if(measure == "msg.tot") file=paste0(file,"-msg-tot.pdf")
	if(measure == "msg.lrg") file=paste0(file,"-msg-lrg.pdf")
	label_y = "Message Size"
	if( measure == "time")  label_y = "Simulated Time (ms)"
	
	pdf(file = paste0(path.in.RFAP, "var/", file), width = 6, height = 6)
 	plot(NA, type='n', ylim=y.axis, xlim=x.axis,
		xlab='(f) RLFA: Varying Number of Agents', ylab="",
		axes=F, cex.lab=1.5, log="y")
	box(col="grey")
	axis(1, las=1, cex.axis=1.25, tck=-.02, labels=x, at=x)
	axis(2, las=1, cex.axis=1.2, tck=-.02,
#	labels= c(expression(1), expression(10), expression(100), expression(10^3), 
#	expression(10^4),expression(10^5)),
#	at=c(1,10,10^2,10^3,10^4,10^5))		
	labels=c(10, expression(10^2), expression(10^3), expression(10^4), expression(10^5), 	
	expression(10^6),expression(10^7)),
	at=c(10,10^2,10^3,10^4,10^5,10^6,10^7))

    y  = mu$BCDPOP;  y.sd = sd$BCDPOP; y.nf = nf$BCDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.bcdpop, lty=2)
    y  = mu$ABCDPOP;  y.sd = sd$ABCDPOP; y.nf = nf$ABCDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.abcdpop, lty=1)
    y  = mu$HDPOP;  y.sd = sd$HDPOP; y.nf = nf$HDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.hdpop, lty=1)
    y  = mu$PHDPOP;  y.sd = sd$PHDPOP; y.nf = nf$PHDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.phdpop, lty=2)
    y  = mu$DPOP;  y.sd = sd$DPOP; y.nf = nf$DPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.dpop, pch=pch.dpop, lty=1)
    dev.off()


}#


CP14.RFAP.var_time <-function( measure )
{
	measure="time"
	if( measure == "msg.lrg")  mn = 5
	if( measure == "msg.tot")  mn = 6
	if( measure == "time")	   mn = 7
	if( measure == "nb.msgAC") mn = 8
	
	path = path.in.RFAP
	data = read.csv( file=paste0(path, "var/output_freq_v2.csv"), sep="\t")

	n.DPOP  = data$algorithm[1]
	n.PHDPOP = data$algorithm[2]
	n.HDPOP = data$algorithm[3]
	n.ABCDPOP = data$algorithm[4]
	n.BCDPOP = data$algorithm[5]
	tn = data$test[1] 
	
	BCDPOP  = subset(data, algorithm==n.BCDPOP & test==tn)   # BC only
   	ABCDPOP = subset(data, algorithm==n.ABCDPOP & test==tn)  # AC+BC (normal BC-DPOP)
   	HDPOP   = subset(data, algorithm==n.HDPOP & test==tn)    # HDPOP (normal)
	PHDPOP  = subset(data, algorithm==n.PHDPOP & test==tn)   # Privacy HDPOP 
	DPOP    = subset(data, algorithm==n.DPOP & test==tn)
    
    list.vals = unique(subset(data, test==tn)$instance) 
    
	# mean and standard deviation
	mu = NULL; sd = NULL; nf = NULL;	
	for (nv in list.vals )
	{
	    list.reps = unique(subset(data, test==tn & instance==nv)$rep)

		tmp.bcdpop  = subset(BCDPOP, instance==nv)[c(4,mn)]
		tmp.abcdpop = subset(ABCDPOP, instance==nv)[c(4,mn)]
		tmp.hdpop   = subset(HDPOP, instance==nv)[c(4,mn)]
		tmp.phdpop  = subset(PHDPOP, instance==nv)[c(4,mn)]
		tmp.dpop    = subset(DPOP, instance==nv)[c(4,mn)]

		names(tmp.bcdpop)  = c("rep", "BC-DPOP")
		names(tmp.abcdpop) = c("rep", "ABC-DPOP")
		names(tmp.hdpop)   = c("rep", "HDPOP")
		names(tmp.phdpop)  = c("rep", "P-HDPOP")
		names(tmp.dpop)    = c("rep", "DPOP")

	    M = merge(tmp.bcdpop, tmp.abcdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.hdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.phdpop, by= 'rep', all=TRUE)
	    M = merge(M, tmp.dpop, by= 'rep', all=TRUE)
		M.noNA = M[ ! is.na(M[6]), ]
		M.noNA = M[ M[6] > 0, ]
		# remove all rows for which there exists at least one NA	    

		if( nv < 35 ) M.noNA = M[ ! is.na(M[5]), ]
		if( nv > 30 ) M.noNA = M[ ! is.na(M[3]), ]
#		M.noNA[2] = M.noNA[3]
		
		mu$BCDPOP  = cbind( mu$BCDPOP, mean( na.exclude(M.noNA[,2]) ) )
		mu$ABCDPOP = cbind( mu$ABCDPOP, mean( na.exclude(M.noNA[,3]) ) )
		mu$HDPOP   = cbind( mu$HDPOP, mean( na.exclude(M.noNA[,4]) ) )
		mu$PHDPOP  = cbind( mu$PHDPOP, mean( na.exclude(M.noNA[,5]) ) )
		mu$DPOP    = cbind( mu$DPOP, mean( na.exclude(M.noNA[,6]) ) )

		sd$BCDPOP  = cbind( sd$BCDPOP, sd( na.exclude(M.noNA[,2]) ) )
		sd$ABCDPOP = cbind( sd$ABCDPOP, sd( na.exclude(M.noNA[,3]) ) )
		sd$HDPOP   = cbind( sd$HDPOP, sd( na.exclude(M.noNA[,4]) ) )
		sd$PHDPOP  = cbind( sd$PHDPOP, sd( na.exclude(M.noNA[,5]) ) )
		sd$DPOP    = cbind( sd$DPOP, sd( na.exclude(M.noNA[,6]) ) )
		
		nf$BCDPOP  = cbind( nf$BCDPOP, sum(is.na(M[,2])))
		nf$ABCDPOP = cbind( nf$ABCDPOP, sum(is.na(M[,3])))
		nf$HDPOP   = cbind( nf$HDPOP, sum(is.na(M[,4])))
		nf$PHDPOP  = cbind( nf$PHDPOP, sum(is.na(M[,5])))
		nf$DPOP    = cbind( nf$DPOP, sum(is.na(M[,6])))
	}
	mi = min(mu$ABCDPOP)
	Ma = max(mu$ABCDPOP, mu$PHDPOP[1:5], mu$HDPOP[1:5])

	# only those having >50 % of problem solvable appear on plot
	# only those having >50 % of problem solvable appear on plot
	mu$HDPOP[5:11] = NaN
	mu$PHDPOP[5:11] = NaN
	mu$DPOP[7:11] = NaN
	mu$BCDPOP[6:11] = NaN

	# Flat curve ? - bad shape random tests! few sat here 
	# mu$ABCDPOP[7] = (mu$ABCDPOP[8]+mu$ABCDPOP[6])/2 + mu$ABCDPOP[6]

	y.axis = c(mi, Ma)
	x.axis = c(min(list.vals), max(list.vals))
#	y.axis = c(10, Ma)
 	x = (list.vals)

	file = "var-nl"
	if(measure == "time") file=paste0(file,"-time.pdf")
	if(measure == "msg.tot") file=paste0(file,"-msg-tot.pdf")
	if(measure == "msg.lrg") file=paste0(file,"-msg-lrg.pdf")
	label_y = "Message Size"
	if( measure == "time")  label_y = "Simulated Time (ms)"
	
	pdf(file = paste0(path.in.RFAP, "var/", file), width = 6, height = 6)
 	plot(NA, type='n', ylim=y.axis, xlim=x.axis,
		xlab='(c) RLFA: Varying Number of Agents', ylab="",
		axes=F, cex.lab=1.5, log="y")
	box(col="grey")
	axis(1, las=1, cex.axis=1.25, tck=-.02, labels=x, at=x)
	axis(2, las=1, cex.axis=1.2, tck=-.02,
	labels= c(0.1, expression(1), expression(10), expression(100), expression(10^3), 
	expression(10^4),expression(10^5)),
	at=c(0.1,1,10,10^2,10^3,10^4,10^5))		
#	labels=c(10, expression(10^2), expression(10^3), expression(10^4), expression(10^5), 	
#	expression(10^6),expression(10^7)),
#	at=c(10,10^2,10^3,10^4,10^5,10^6,10^7))

    y  = mu$BCDPOP;  y.sd = sd$BCDPOP; y.nf = nf$BCDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.bcdpop, lty=2)
    y  = mu$ABCDPOP;  y.sd = sd$ABCDPOP; y.nf = nf$ABCDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.abcdpop, pch=pch.abcdpop, lty=1)
    y  = mu$HDPOP;  y.sd = sd$HDPOP; y.nf = nf$HDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.hdpop, lty=1)
    y  = mu$PHDPOP;  y.sd = sd$PHDPOP; y.nf = nf$PHDPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.hdpop, pch=pch.phdpop, lty=2)
    y  = mu$DPOP;  y.sd = sd$DPOP; y.nf = nf$DPOP; 
	lines(x, y, type='o', cex=cex.symb, lwd=lwd.line, col=col.dpop, pch=pch.dpop, lty=1)
    dev.off()

}#
